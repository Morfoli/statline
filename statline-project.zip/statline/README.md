# Statline

A scouting desk for men's and women's sports (baseball/softball, hockey, football, soccer, golf, basketball,
tennis, volleyball, lacrosse, rugby) with a fantasy lab: import a roster and get a review of what is good,
what is bad, and what needs to change.

## Just open it

Run `npm run build`, then double-click **`dist/index.html`**. It is one self-contained file (code, styles and
fonts are inlined), so it works from your desktop, a USB stick, or any static host. No server needed.

## Develop

    npm install
    npm run dev      # http://localhost:5173
    npm run build    # type-check + build dist/index.html

Note: the `index.html` in this folder is the dev entry. It only works through `npm run dev`.

## Fantasy lab import formats

One name per line, a CSV with the name in any column, "Last, First", numbered lists ("1. Name"),
and slot prefixes ("SP: Name") all work. Last name alone works when it is unique on the board.
Data is a sample season, not live stats.

## Live stats

Five leagues read live season stats and standings from ESPN's public JSON feeds (no API key):
MLB, NHL, NFL, NBA and WNBA. Everything else runs on the bundled sample season until a free feed is connected.

- Code: `src/live/espn.ts` (requests, parsing, per-league mapping), `src/live/LiveProvider.tsx` (loading and
  15-minute cache in localStorage), `src/live/resolve.ts` (swaps live data into a league, builds the sample clubs).
- If a feed fails, the page shows the sample season and says why. `#/status` ("Data sources" in the header) re-tests
  every feed and shows what each one returned.
- ESPN's feeds are unofficial and can change without notice. Football and goalie requests try a few parameter styles
  and remember the one that worked.
- Adding a league means adding one entry to `FEEDS` in `src/live/espn.ts`: the request plans, a mapper onto the
  site's stat keys, and the season rule.

## Admin and money features (needs the server)

A plain file or static host cannot keep a private admin account, because anything in the page is readable by
every visitor. So the admin lives in a small Node server (`server/`, no extra packages, Node 20 or newer).
Without the server the site works exactly as before and every money feature is simply off.

    npm install
    npm start          # builds the site, then starts the server on http://127.0.0.1:8787

The first time, the console prints a one-time **setup token**. Open `/#/admin`, paste the token, and choose an
email and password (12+ characters). That creates the only account. It holds every admin permission and there is
no sign-up route afterwards. Turn on two-step sign-in under Security.

Forgot the password? Stop the server and run `npm run reset-owner`. It removes the account so the next start
prints a new setup token.

What the owner can do:

- **Promotions:** affiliate, sponsor and house cards for the home, stats and fantasy pages, by sport and date, with
  an automatic label, an affiliate disclosure, and click counting through `/go/<id>`.
- **Ads:** Google AdSense units or custom code in three slots. Ads load only after the visitor accepts, never on
  admin, privacy or account pages, and custom code runs in a sandboxed frame. `/ads.txt` is served for you.
- **Plus (ad-free):** point the buy link at a Stripe Payment Link (or similar), then hand out access codes. A code
  removes ads and sponsored cards on that browser. No payment code runs on this site.
- **Support link, announcement bar, email sign-ups** (CSV export), **privacy page**, **live-data switches** per
  league, **overview** (views, clicks, sign-ups), **audit log**, **sessions**, **backup download**.

Where to run it: any host that runs Node (Render, Railway, Fly.io, a VPS). Set `DATA_DIR` to a **persistent disk**,
otherwise settings and subscribers vanish when the host restarts. Serve it over HTTPS and set `TRUST_PROXY=1` and
`SECURE_COOKIES=1` (the included Dockerfile does). `ADMIN_SETUP_TOKEN` can set the setup token instead of a random one.

Security notes: passwords are hashed with scrypt, sessions are random tokens kept hashed on the server in HttpOnly
SameSite=Strict cookies, state-changing admin calls need a custom header plus a same-origin check, logins and
code guessing are rate limited, and the data file is private to the server user. Run `npm run test:server` to see
the tests that check this.

Money and data: ESPN's feeds are unofficial and ESPN's terms limit commercial use. Before the site earns money,
switch to a licensed data provider or turn the live leagues off under Site, then Live data.
