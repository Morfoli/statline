// Run with the server stopped:  node server/cli.mjs reset-owner
// Removes the owner account and every session so a new owner can be created with a fresh setup token.
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Store } from "./store.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const command = process.argv[2];

if (command !== "reset-owner") {
  console.log("Usage: node server/cli.mjs reset-owner");
  process.exit(command ? 1 : 0);
}

const store = new Store(process.env.DATA_DIR || path.join(root, "data"));
store.data.owner = null;
store.data.sessions = [];
store.audit("owner_reset", "cli");
store.flush();
clearInterval(store.timer);
console.log("Owner account removed. Start the server to get a new setup token.");
