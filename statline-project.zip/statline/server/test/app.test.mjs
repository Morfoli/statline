import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createApp } from "../app.mjs";
import { totpNow } from "../auth.mjs";
import { csvCell } from "../validate.mjs";

const PASSWORD = "correct horse battery 42";
const TOKEN = "test-setup-token";

async function boot(extra = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "statline-test-"));
  const dist = path.join(dir, "dist");
  fs.mkdirSync(dist);
  fs.writeFileSync(path.join(dist, "index.html"), "<!doctype html><title>x</title>");
  const app = createApp({ dataDir: path.join(dir, "data"), distDir: dist, setupToken: TOKEN, ...extra });
  await new Promise((resolve) => app.server.listen(0, "127.0.0.1", resolve));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  const call = async (method, url, { body, cookie, headers = {}, raw = false, csrf = true } = {}) => {
    const h = { ...headers };
    if (cookie) h.cookie = cookie;
    if (body !== undefined) h["content-type"] = "application/json";
    if (csrf && method !== "GET") h["x-statline"] = "1";
    const res = await fetch(base + url, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body), redirect: "manual" });
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch { /* not json */ }
    const setCookie = res.headers.get("set-cookie");
    return { status: res.status, json, text, headers: res.headers, cookie: setCookie ? setCookie.split(";")[0] : null, raw: res };
  };
  const close = async () => { await app.close(); fs.rmSync(dir, { recursive: true, force: true }); };
  return { app, base, call, close, dir };
}

async function owner(ctx) {
  const res = await ctx.call("POST", "/api/admin/setup", { body: { token: TOKEN, email: "me@example.com", password: PASSWORD } });
  assert.equal(res.status, 200);
  return res.cookie;
}

test("setup: needs the console token, works once, then closes", async () => {
  const ctx = await boot();
  try {
    assert.equal((await ctx.call("GET", "/api/admin/status")).json.needsSetup, true);
    const wrong = await ctx.call("POST", "/api/admin/setup", { body: { token: "nope", email: "a@b.co", password: PASSWORD } });
    assert.equal(wrong.status, 403);
    const weak = await ctx.call("POST", "/api/admin/setup", { body: { token: TOKEN, email: "me@example.com", password: "short" } });
    assert.equal(weak.status, 400);
    const ok = await ctx.call("POST", "/api/admin/setup", { body: { token: TOKEN, email: "me@example.com", password: PASSWORD } });
    assert.equal(ok.status, 200);
    assert.match(ok.raw.headers.get("set-cookie"), /HttpOnly/);
    assert.match(ok.raw.headers.get("set-cookie"), /SameSite=Strict/);
    const again = await ctx.call("POST", "/api/admin/setup", { body: { token: TOKEN, email: "x@y.co", password: PASSWORD } });
    assert.equal(again.status, 409, "a second owner can never be created");
    assert.equal((await ctx.call("GET", "/api/admin/status")).json.needsSetup, false);
  } finally { await ctx.close(); }
});

test("setup token guessing is rate limited", async () => {
  const ctx = await boot();
  try {
    let last;
    for (let i = 0; i < 7; i += 1) last = await ctx.call("POST", "/api/admin/setup", { body: { token: `guess${i}`, email: "a@b.co", password: PASSWORD } });
    assert.equal(last.status, 429);
  } finally { await ctx.close(); }
});

test("every admin route refuses visitors who are not signed in", async () => {
  const ctx = await boot();
  try {
    await owner(ctx);
    const paths = ["/api/admin/overview", "/api/admin/settings", "/api/admin/promos", "/api/admin/codes", "/api/admin/subscribers", "/api/admin/subscribers.csv", "/api/admin/export", "/api/admin/audit", "/api/admin/sessions"];
    for (const p of paths) assert.equal((await ctx.call("GET", p)).status, 401, p);
    for (const p of ["/api/admin/password", "/api/admin/2fa/begin", "/api/admin/sessions/revoke-others"]) assert.equal((await ctx.call("POST", p, { body: {} })).status, 401, p);
    assert.equal((await ctx.call("PUT", "/api/admin/settings", { body: { siteName: "Hacked" } })).status, 401);
    assert.equal((await ctx.call("GET", "/api/admin/settings", { cookie: "statline_admin=forged-token" })).status, 401);
  } finally { await ctx.close(); }
});

test("login: wrong credentials fail generically, lockout after repeated failures, success sets a session", async () => {
  const ctx = await boot();
  try {
    await owner(ctx);
    const bad = await ctx.call("POST", "/api/admin/login", { body: { email: "me@example.com", password: "wrong wrong wrong" } });
    const unknown = await ctx.call("POST", "/api/admin/login", { body: { email: "who@example.com", password: PASSWORD } });
    assert.equal(bad.status, 401);
    assert.equal(unknown.status, 401);
    assert.equal(bad.json.error, unknown.json.error, "no hint about which part was wrong");
    const good = await ctx.call("POST", "/api/admin/login", { body: { email: "ME@example.com", password: PASSWORD } });
    assert.equal(good.status, 200);
    assert.equal((await ctx.call("GET", "/api/admin/status", { cookie: good.cookie })).json.loggedIn, true);
    let last;
    for (let i = 0; i < 9; i += 1) last = await ctx.call("POST", "/api/admin/login", { body: { email: "me@example.com", password: `wrong password ${i}` } });
    assert.equal(last.status, 429, "locked out after too many failures");
  } finally { await ctx.close(); }
}, { timeout: 30000 });

test("CSRF: state-changing admin calls need the custom header and a matching origin", async () => {
  const ctx = await boot();
  try {
    const cookie = await owner(ctx);
    const noHeader = await ctx.call("PUT", "/api/admin/settings", { cookie, body: { siteName: "X" }, csrf: false });
    assert.equal(noHeader.status, 403);
    const foreign = await ctx.call("PUT", "/api/admin/settings", { cookie, body: { siteName: "X" }, headers: { origin: "https://evil.example" } });
    assert.equal(foreign.status, 403);
    const form = await fetch(ctx.base + "/api/admin/settings", { method: "PUT", headers: { cookie, "content-type": "application/x-www-form-urlencoded", "x-statline": "1" }, body: "siteName=X" });
    assert.equal(form.status, 415, "form posts are refused");
    const fine = await ctx.call("PUT", "/api/admin/settings", { cookie, body: { siteName: "Mine" } });
    assert.equal(fine.status, 200);
    assert.equal(fine.json.settings.siteName, "Mine");
  } finally { await ctx.close(); }
});

test("settings are validated: bad links, bad IDs and HTML in ads.txt are rejected", async () => {
  const ctx = await boot();
  try {
    const cookie = await owner(ctx);
    const put = (body) => ctx.call("PUT", "/api/admin/settings", { cookie, body });
    assert.equal((await put({ announcement: { enabled: true, text: "Hi", url: "javascript:alert(1)" } })).status, 400);
    assert.equal((await put({ support: { enabled: true, label: "Tip", url: "" } })).status, 400);
    assert.equal((await put({ ads: { provider: "adsense", publisherId: "ca-pub-12" } })).status, 400);
    assert.equal((await put({ ads: { adsTxt: "<script>x</script>" } })).status, 400);
    assert.equal((await put({ ads: { provider: "adsense", publisherId: "ca-pub-1234567890123456", slots: { inline: { enabled: true, type: "adsense", adsenseSlot: "12ab" } } } })).status, 400);
    const ok = await put({ ads: { provider: "adsense", publisherId: "ca-pub-1234567890123456", adsTxt: "google.com, pub-1234567890123456, DIRECT, f08c47fec0942fa0", slots: { inline: { enabled: true, type: "adsense", adsenseSlot: "1234567890" } } } });
    assert.equal(ok.status, 200);
    assert.equal((await ctx.call("GET", "/ads.txt")).status, 200);
    assert.match((await ctx.call("GET", "/ads.txt")).text, /pub-1234567890123456/);
  } finally { await ctx.close(); }
});

test("promotions: create, schedule, hide, click-track and redirect", async () => {
  const ctx = await boot();
  try {
    const cookie = await owner(ctx);
    const bad = await ctx.call("POST", "/api/admin/promos", { cookie, body: { title: "x", url: "ftp://nope" } });
    assert.equal(bad.status, 400);
    const made = await ctx.call("POST", "/api/admin/promos", { cookie, body: { title: "Gear sale", body: "20% off", cta: "Shop", url: "https://shop.example/deal?ref=statline", kind: "affiliate", placements: ["home", "desk"], weight: 3 } });
    assert.equal(made.status, 200);
    const id = made.json.promo.id;
    const config = (await ctx.call("GET", "/api/config")).json.config;
    assert.equal(config.promos.length, 1);
    assert.equal(config.promos[0].url, undefined, "the public config never exposes the target address");
    const click = await ctx.call("GET", `/go/${id}`);
    assert.equal(click.status, 302);
    assert.equal(click.headers.get("location"), "https://shop.example/deal?ref=statline");
    await ctx.call("POST", "/api/track", { body: { type: "promo", id } });
    const stats = (await ctx.call("GET", "/api/admin/overview", { cookie })).json;
    const row = stats.promos.find((p) => p.id === id);
    assert.equal(row.clicks, 1);
    assert.equal(row.views, 1);
    // future start date hides it
    const future = await ctx.call("PUT", `/api/admin/promos/${id}`, { cookie, body: { ...made.json.promo, startsAt: "2999-01-01" } });
    assert.equal(future.status, 200);
    assert.equal((await ctx.call("GET", "/api/config")).json.config.promos.length, 0);
    await ctx.call("PUT", `/api/admin/promos/${id}`, { cookie, body: { ...made.json.promo, startsAt: "", enabled: false } });
    assert.equal((await ctx.call("GET", `/go/${id}`)).headers.get("location"), "/", "a disabled promotion no longer redirects out");
    assert.equal((await ctx.call("DELETE", `/api/admin/promos/${id}`, { cookie })).status, 200);
    assert.equal((await ctx.call("GET", "/go/aaaaaaaaaaaa")).status, 302);
  } finally { await ctx.close(); }
});

test("email sign-ups: validated, de-duplicated, honeypot, CSV export is formula-safe", async () => {
  const ctx = await boot();
  try {
    const cookie = await owner(ctx);
    assert.equal((await ctx.call("POST", "/api/subscribe", { body: { email: "not-an-email" } })).status, 400);
    assert.equal((await ctx.call("POST", "/api/subscribe", { body: { email: "fan@example.com", source: "footer" } })).status, 200);
    assert.equal((await ctx.call("POST", "/api/subscribe", { body: { email: "FAN@example.com" } })).status, 200);
    assert.equal((await ctx.call("POST", "/api/subscribe", { body: { email: "bot@example.com", website: "http://spam" } })).status, 200);
    const list = (await ctx.call("GET", "/api/admin/subscribers", { cookie })).json.subscribers;
    assert.equal(list.length, 1, "duplicate and honeypot sign-ups are not stored");
    const csv = await ctx.call("GET", "/api/admin/subscribers.csv", { cookie });
    assert.match(csv.text, /^email,signed_up,source\nfan@example.com,/);
    assert.equal(csvCell('=HYPERLINK("x")'), `"'=HYPERLINK(""x"")"`, "formula cells are neutralised and quoted");
    assert.equal(csvCell("+1@x.co"), "'+1@x.co");
    await ctx.call("PUT", "/api/admin/settings", { cookie, body: { features: { subscribe: false } } });
    assert.equal((await ctx.call("POST", "/api/subscribe", { body: { email: "late@example.com" } })).status, 403);
  } finally { await ctx.close(); }
});

test("Plus access codes: redeem, limits, expiry, revoke, ad-free config", async () => {
  const ctx = await boot();
  try {
    const cookie = await owner(ctx);
    assert.equal((await ctx.call("POST", "/api/plus/redeem", { body: { code: "ANY" } })).status, 403, "off until enabled");
    await ctx.call("PUT", "/api/admin/settings", { cookie, body: { plus: { enabled: true, name: "Plus", durationDays: 30 } } });
    await ctx.call("POST", "/api/admin/promos", { cookie, body: { title: "Ad", url: "https://a.example", placements: ["home"] } });
    const made = await ctx.call("POST", "/api/admin/codes", { cookie, body: { count: 2, maxUses: 1, label: "launch" } });
    const [a, b] = made.json.codes;
    assert.match(a.code, /^[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/);
    const redeem = await ctx.call("POST", "/api/plus/redeem", { body: { code: a.code.toLowerCase().replace(/-/g, " ") } });
    assert.equal(redeem.status, 200);
    const plusCookie = redeem.cookie;
    const config = (await ctx.call("GET", "/api/config", { cookie: plusCookie })).json.config;
    assert.equal(config.entitled, true);
    assert.equal(config.promos.length, 0, "Plus members see no sponsored cards");
    assert.equal(config.ads.provider, "none");
    assert.equal((await ctx.call("GET", "/api/config")).json.config.entitled, false);
    assert.equal((await ctx.call("GET", "/api/config", { cookie: "statline_plus=" + plusCookie.split("=")[1].replace(/.$/, "x") })).json.config.entitled, false, "a tampered cookie is rejected");
    assert.equal((await ctx.call("POST", "/api/plus/redeem", { body: { code: a.code } })).status, 400, "single-use code is spent");
    await ctx.call("DELETE", `/api/admin/codes/${b.id}`, { cookie });
    assert.equal((await ctx.call("POST", "/api/plus/redeem", { body: { code: b.code } })).status, 400, "revoked code fails");
    const guessing = [];
    for (let i = 0; i < 12; i += 1) guessing.push((await ctx.call("POST", "/api/plus/redeem", { body: { code: `GUESS-${i}` } })).status);
    assert.ok(guessing.includes(429), "code guessing is rate limited");
  } finally { await ctx.close(); }
});

test("two-step sign-in: enable, then login needs the code, replay is refused", async () => {
  const ctx = await boot();
  try {
    const cookie = await owner(ctx);
    const begin = await ctx.call("POST", "/api/admin/2fa/begin", { cookie, body: {} });
    assert.match(begin.json.uri, /^otpauth:\/\/totp\//);
    assert.equal((await ctx.call("POST", "/api/admin/2fa/enable", { cookie, body: { code: "000000" } })).status, 400);
    const code = totpNow(begin.json.secret);
    assert.equal((await ctx.call("POST", "/api/admin/2fa/enable", { cookie, body: { code } })).status, 200);
    const step1 = await ctx.call("POST", "/api/admin/login", { body: { email: "me@example.com", password: PASSWORD } });
    assert.equal(step1.json.needsCode, true);
    assert.equal(step1.cookie, null, "no session until the code is right");
    const reuse = await ctx.call("POST", "/api/admin/login", { body: { email: "me@example.com", password: PASSWORD, code } });
    assert.equal(reuse.status, 401, "the code used at setup cannot be replayed");
    const fresh = totpNow(begin.json.secret, Date.now() + 30000);
    const ok = await ctx.call("POST", "/api/admin/login", { body: { email: "me@example.com", password: PASSWORD, code: fresh } });
    assert.equal(ok.status, 200);
  } finally { await ctx.close(); }
});

test("changing the password signs out every other session and the old password stops working", async () => {
  const ctx = await boot();
  try {
    const first = await owner(ctx);
    const second = (await ctx.call("POST", "/api/admin/login", { body: { email: "me@example.com", password: PASSWORD } })).cookie;
    assert.equal((await ctx.call("GET", "/api/admin/sessions", { cookie: first })).json.sessions.length, 2);
    const weak = await ctx.call("POST", "/api/admin/password", { cookie: second, body: { current: PASSWORD, next: "me@example.com1" } });
    assert.equal(weak.status, 400);
    const wrongCurrent = await ctx.call("POST", "/api/admin/password", { cookie: second, body: { current: "nope nope nope nope", next: "a brand new passphrase 9" } });
    assert.equal(wrongCurrent.status, 403);
    const changed = await ctx.call("POST", "/api/admin/password", { cookie: second, body: { current: PASSWORD, next: "a brand new passphrase 9" } });
    assert.equal(changed.status, 200);
    assert.equal((await ctx.call("GET", "/api/admin/status", { cookie: first })).json.loggedIn, false, "the other session was ended");
    assert.equal((await ctx.call("GET", "/api/admin/status", { cookie: second })).json.loggedIn, true);
    assert.equal((await ctx.call("POST", "/api/admin/login", { body: { email: "me@example.com", password: PASSWORD } })).status, 401);
    assert.equal((await ctx.call("POST", "/api/admin/login", { body: { email: "me@example.com", password: "a brand new passphrase 9" } })).status, 200);
  } finally { await ctx.close(); }
}, { timeout: 30000 });

test("logout ends the session; audit log and export hold no secrets", async () => {
  const ctx = await boot();
  try {
    const cookie = await owner(ctx);
    const audit = (await ctx.call("GET", "/api/admin/audit", { cookie })).json.audit;
    assert.ok(audit.some((a) => a.action === "setup"));
    const exported = (await ctx.call("GET", "/api/admin/export", { cookie })).text;
    assert.ok(!/passHash|scrypt\$|secret/.test(exported), "export never contains password hashes or signing secrets");
    await ctx.call("POST", "/api/admin/logout", { cookie, body: {} });
    assert.equal((await ctx.call("GET", "/api/admin/settings", { cookie })).status, 401);
    const raw = fs.readFileSync(path.join(ctx.dir, "data", "statline-data.json"), "utf8");
    assert.ok(!raw.includes(PASSWORD), "the password is never stored");
    assert.match(raw, /scrypt\$32768\$8\$1\$/);
    assert.equal((fs.statSync(path.join(ctx.dir, "data", "statline-data.json")).mode & 0o077), 0, "data file is private to the owner");
  } finally { await ctx.close(); }
});

test("partial settings updates keep the fields they do not mention", async () => {
  const ctx = await boot();
  try {
    const cookie = await owner(ctx);
    const before = (await ctx.call("GET", "/api/admin/settings", { cookie })).json.settings;
    assert.match(before.legal.privacyText, /starting template/);
    const res = await ctx.call("PUT", "/api/admin/settings", { cookie, body: { legal: { contactEmail: "hi@example.com" }, plus: { enabled: true } } });
    assert.equal(res.status, 200);
    assert.equal(res.json.settings.legal.contactEmail, "hi@example.com");
    assert.equal(res.json.settings.legal.privacyText, before.legal.privacyText, "privacy text survives a partial update");
    assert.equal(res.json.settings.legal.affiliateNote, before.legal.affiliateNote);
    assert.equal(res.json.settings.plus.name, before.plus.name, "plan name survives too");
    assert.equal(res.json.settings.plus.durationDays, before.plus.durationDays);
  } finally { await ctx.close(); }
});

test("only real pages are counted, so stats cannot be padded", async () => {
  const ctx = await boot();
  try {
    for (const id of ["home", "basketball", "baseball/lab", "plus", "curling", "admin", "x/lab", "../../etc"]) await ctx.call("POST", "/api/track", { body: { type: "view", id } });
    const views = Object.values(ctx.app.store.data.stats.days)[0].views;
    assert.deepEqual(Object.keys(views).sort(), ["baseball/lab", "basketball", "home", "plus"]);
  } finally { await ctx.close(); }
});

test("the data folder is private to the server user", async () => {
  const ctx = await boot();
  try {
    assert.equal(fs.statSync(path.join(ctx.dir, "data")).mode & 0o077, 0);
  } finally { await ctx.close(); }
});

test("server basics: security headers, SPA served, unknown API 404, tracking is bounded", async () => {
  const ctx = await boot();
  try {
    const page = await ctx.call("GET", "/");
    assert.equal(page.status, 200);
    assert.equal(page.headers.get("x-content-type-options"), "nosniff");
    assert.equal(page.headers.get("x-frame-options"), "DENY");
    assert.equal((await ctx.call("GET", "/api/nope")).status, 404);
    assert.equal((await ctx.call("GET", "/api/admin/nope", { cookie: "x=y" })).status, 404);
    for (let i = 0; i < 80; i += 1) await ctx.call("POST", "/api/track", { body: { type: "view", id: `page-${i}` } });
    await ctx.call("POST", "/api/track", { body: { type: "view", id: "../../etc/passwd" } });
    const days = Object.values(ctx.app.store.data.stats.days)[0];
    assert.equal(Object.keys(days.views).length, 0, "unknown page names are never stored");
  } finally { await ctx.close(); }
});
