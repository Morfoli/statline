import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

export const DEFAULT_PRIVACY = `This is a starting template. Read it, edit it to match what you actually do, and have it checked before you rely on it. It is not legal advice.

What this site collects
- Page views and clicks on promotions, counted without cookies or personal details.
- Your email address, only if you choose to subscribe.
- A choice you make about advertising, saved in your browser.

Advertising and affiliate links
Some pages show ads or sponsored links. If ads are turned on, the ad provider may use cookies or similar technology, but only after you accept. Affiliate links are labelled, and the site may earn a commission if you buy through them.

Your choices
You can decline advertising, remove your subscription by contacting the site owner, and clear this site's data in your browser at any time.`;

export const DEFAULT_SETTINGS = {
  siteName: "Statline",
  announcement: { enabled: false, text: "", url: "" },
  features: {
    subscribe: true,
    liveLeagues: { mlb: true, nhl: true, nfl: true, nba: true, wnba: true },
  },
  ads: {
    provider: "none",
    publisherId: "",
    requireConsent: true,
    adsTxt: "",
    slots: {
      header: { enabled: false, type: "adsense", adsenseSlot: "", customHtml: "" },
      inline: { enabled: false, type: "adsense", adsenseSlot: "", customHtml: "" },
      footer: { enabled: false, type: "adsense", adsenseSlot: "", customHtml: "" },
    },
  },
  support: { enabled: false, label: "Support Statline", url: "" },
  plus: {
    enabled: false,
    name: "Statline Plus",
    price: "",
    pitch: "Browse without ads or sponsored cards, and help keep the site running.",
    buyUrl: "",
    durationDays: 365,
  },
  legal: {
    contactEmail: "",
    privacyText: DEFAULT_PRIVACY,
    affiliateNote:
      "Some links on this site are affiliate links. If you buy through one, the site may earn a commission at no extra cost to you.",
  },
};

function merge(base, extra) {
  if (Array.isArray(base) || typeof base !== "object" || base === null) return extra === undefined ? base : extra;
  const out = {};
  for (const key of Object.keys(base)) out[key] = merge(base[key], extra && typeof extra === "object" ? extra[key] : undefined);
  return out;
}

function fresh() {
  return {
    version: 1,
    secret: crypto.randomBytes(32).toString("base64"),
    owner: null,
    sessions: [],
    settings: structuredClone(DEFAULT_SETTINGS),
    promos: [],
    codes: [],
    subscribers: [],
    stats: { days: {} },
    audit: [],
  };
}

export class Store {
  constructor(dir) {
    this.dir = dir;
    this.file = path.join(dir, "statline-data.json");
    this.dirty = false;
    mkdirSync(dir, { recursive: true, mode: 0o700 });
    if (existsSync(this.file)) {
      const loaded = JSON.parse(readFileSync(this.file, "utf8"));
      this.data = { ...fresh(), ...loaded };
      this.data.settings = merge(DEFAULT_SETTINGS, loaded.settings);
    } else {
      this.data = fresh();
      this.flush();
    }
    this.timer = setInterval(() => this.dirty && this.flush(), 5000);
    this.timer.unref();
  }

  // Atomic write: a crash mid-write leaves the previous file intact.
  flush() {
    this.pruneStats();
    const tmp = `${this.file}.${process.pid}.tmp`;
    writeFileSync(tmp, JSON.stringify(this.data), { mode: 0o600 });
    renameSync(tmp, this.file);
    this.dirty = false;
  }

  touch() {
    this.dirty = true;
  }

  pruneStats() {
    const days = Object.keys(this.data.stats.days).sort();
    for (const day of days.slice(0, Math.max(0, days.length - 120))) delete this.data.stats.days[day];
    if (this.data.audit.length > 300) this.data.audit = this.data.audit.slice(-300);
    const now = Date.now();
    this.data.sessions = this.data.sessions.filter((s) => s.expires > now);
  }

  audit(action, detail = "") {
    this.data.audit.push({ at: Date.now(), action, detail: String(detail).slice(0, 200) });
  }

  day(now = new Date()) {
    const key = now.toISOString().slice(0, 10);
    const days = this.data.stats.days;
    days[key] ??= { views: {}, promoViews: {}, promoClicks: {}, adViews: {}, subs: 0, redeems: 0 };
    return days[key];
  }
}
