import crypto from "node:crypto";

export class Bad extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
}

export const text = (value, max, label = "Text") => {
  const s = String(value ?? "").replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "").trim();
  if (s.length > max) throw new Bad(`${label} is too long (max ${max} characters).`);
  return s;
};

export const bool = (value, fallback = false) => (typeof value === "boolean" ? value : fallback);

export const oneOf = (value, allowed, fallback) => (allowed.includes(value) ? value : fallback);

export function url(value, label = "URL") {
  const s = String(value ?? "").trim();
  if (!s) return "";
  if (s.length > 2000) throw new Bad(`${label} is too long.`);
  let parsed;
  try {
    parsed = new URL(s);
  } catch {
    throw new Bad(`${label} is not a valid address.`);
  }
  if (!/^https?:$/.test(parsed.protocol)) throw new Bad(`${label} must start with http:// or https://.`);
  return parsed.toString();
}

export function email(value) {
  const s = String(value ?? "").trim().toLowerCase();
  if (s.length > 254 || !/^[^\s@<>()"',;:]+@[^\s@<>()"',;:]+\.[a-z]{2,}$/i.test(s)) throw new Bad("Enter a valid email address.");
  return s;
}

const PUBLISHER = /^ca-pub-\d{10,20}$/;
const SLOT_ID = /^\d{6,20}$/;
const LEAGUES = ["mlb", "nhl", "nfl", "nba", "wnba"];

// Pages the site can count. Anything else a visitor sends is ignored, so the stats cannot be padded with junk.
const SPORT_IDS = ["baseball", "hockey", "football", "soccer", "golf", "basketball", "tennis", "volleyball", "lacrosse", "rugby"];
export const TRACKABLE_PAGES = new Set(["home", "status", "plus", "privacy", ...SPORT_IDS, ...SPORT_IDS.map((id) => `${id}/lab`)]);
const SLOT_NAMES = ["header", "inline", "footer"];
const PLACEMENTS = ["home", "desk", "lab"];

function cleanSlot(input, current, name) {
  const next = { ...current };
  if (!input || typeof input !== "object") return next;
  next.enabled = bool(input.enabled, current.enabled);
  next.type = oneOf(input.type, ["adsense", "custom"], current.type);
  const slotId = text(input.adsenseSlot, 20, `${name} ad slot ID`);
  if (slotId && !SLOT_ID.test(slotId)) throw new Bad(`The ${name} AdSense slot ID should be only digits.`);
  next.adsenseSlot = slotId;
  next.customHtml = text(input.customHtml, 8000, `${name} custom code`);
  return next;
}

export function cleanSettings(input, current) {
  if (!input || typeof input !== "object") throw new Bad("Settings were missing.");
  const out = structuredClone(current);

  if ("siteName" in input) out.siteName = text(input.siteName, 40, "Site name") || current.siteName;

  // A partial update (only some fields of a section) keeps the rest as they are.
  const section = (name) => ({ ...current[name], ...(input[name] && typeof input[name] === "object" ? input[name] : {}) });

  if (input.announcement) {
    const a = section("announcement");
    out.announcement = { enabled: bool(a.enabled), text: text(a.text, 200, "Announcement"), url: url(a.url, "Announcement link") };
  }

  if (input.features) {
    const f = input.features;
    out.features.subscribe = bool(f.subscribe, current.features.subscribe);
    for (const id of LEAGUES) out.features.liveLeagues[id] = bool(f.liveLeagues?.[id], current.features.liveLeagues[id]);
  }

  if (input.ads) {
    const a = input.ads;
    out.ads.provider = oneOf(a.provider, ["none", "adsense"], current.ads.provider);
    const publisher = text(a.publisherId, 40, "Publisher ID");
    if (publisher && !PUBLISHER.test(publisher)) throw new Bad("The AdSense publisher ID looks like ca-pub-1234567890123456.");
    out.ads.publisherId = publisher;
    out.ads.requireConsent = bool(a.requireConsent, current.ads.requireConsent);
    const adsTxt = text(a.adsTxt, 2000, "ads.txt");
    if (/[<>]/.test(adsTxt)) throw new Bad("ads.txt is plain text lines, not HTML.");
    out.ads.adsTxt = adsTxt;
    for (const name of SLOT_NAMES) out.ads.slots[name] = cleanSlot(a.slots?.[name], current.ads.slots[name], name);
    if (out.ads.provider === "adsense" && !out.ads.publisherId) {
      for (const name of SLOT_NAMES) if (out.ads.slots[name].enabled && out.ads.slots[name].type === "adsense") throw new Bad("Add your AdSense publisher ID before turning on an AdSense slot.");
    }
  }

  if (input.support) {
    const s = section("support");
    out.support = { enabled: bool(s.enabled), label: text(s.label, 40, "Support label") || "Support", url: url(s.url, "Support link") };
    if (out.support.enabled && !out.support.url) throw new Bad("Add a support link before turning the support button on.");
  }

  if (input.plus) {
    const p = section("plus");
    const days = Math.round(Number(p.durationDays));
    out.plus = {
      enabled: bool(p.enabled),
      name: text(p.name, 40, "Plan name") || "Plus",
      price: text(p.price, 40, "Price"),
      pitch: text(p.pitch, 300, "Pitch"),
      buyUrl: url(p.buyUrl, "Buy link"),
      durationDays: Number.isFinite(days) ? Math.min(3650, Math.max(1, days)) : current.plus.durationDays,
    };
  }

  if (input.legal) {
    const l = section("legal");
    const contact = String(l.contactEmail ?? "").trim();
    out.legal = {
      contactEmail: contact ? email(contact) : "",
      privacyText: text(l.privacyText, 20000, "Privacy text"),
      affiliateNote: text(l.affiliateNote, 500, "Affiliate note"),
    };
  }
  return out;
}

export function cleanPromo(input, existing) {
  if (!input || typeof input !== "object") throw new Bad("Promotion was missing.");
  const title = text(input.title, 80, "Title");
  if (!title) throw new Bad("Give the promotion a title.");
  const target = url(input.url, "Link");
  if (!target) throw new Bad("Add the link this promotion points to.");
  const date = (v, label) => {
    const s = String(v ?? "").trim();
    if (!s) return "";
    if (!/^\d{4}-\d{2}-\d{2}$/.test(s) || Number.isNaN(Date.parse(s))) throw new Bad(`${label} should be a date.`);
    return s;
  };
  const startsAt = date(input.startsAt, "Start date");
  const endsAt = date(input.endsAt, "End date");
  if (startsAt && endsAt && endsAt < startsAt) throw new Bad("The end date is before the start date.");
  const placements = (Array.isArray(input.placements) ? input.placements : []).filter((p) => PLACEMENTS.includes(p));
  const weight = Math.round(Number(input.weight));
  return {
    id: existing?.id ?? crypto.randomBytes(6).toString("hex"),
    title,
    body: text(input.body, 240, "Description"),
    cta: text(input.cta, 30, "Button text") || "Learn more",
    url: target,
    kind: oneOf(input.kind, ["affiliate", "sponsor", "house"], "affiliate"),
    placements: placements.length ? placements : ["home"],
    sports: (Array.isArray(input.sports) ? input.sports : []).map((s) => String(s).toLowerCase()).filter((s) => /^[a-z-]{2,20}$/.test(s)).slice(0, 12),
    enabled: bool(input.enabled, true),
    startsAt,
    endsAt,
    weight: Number.isFinite(weight) ? Math.min(10, Math.max(1, weight)) : 1,
    createdAt: existing?.createdAt ?? Date.now(),
  };
}

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
export function makeCode() {
  const bytes = crypto.randomBytes(12);
  const chars = [...bytes].map((b) => ALPHABET[b % ALPHABET.length]);
  return `${chars.slice(0, 4).join("")}-${chars.slice(4, 8).join("")}-${chars.slice(8, 12).join("")}`;
}

export const normalizeCode = (value) => String(value ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "");

// Spreadsheet programs run cells that start with = + - @ as formulas. Prefix them so an exported email cannot execute.
export function csvCell(value) {
  let s = String(value ?? "");
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
