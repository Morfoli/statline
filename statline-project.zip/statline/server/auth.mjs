import crypto from "node:crypto";
import { promisify } from "node:util";

const scrypt = promisify(crypto.scrypt);
const N = 32768;
const R = 8;
const P = 1;
const KEYLEN = 64;
const MAXMEM = 128 * 1024 * 1024;

export async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(password, salt, KEYLEN, { N, r: R, p: P, maxmem: MAXMEM });
  return `scrypt$${N}$${R}$${P}$${salt.toString("base64")}$${key.toString("base64")}`;
}

export async function verifyPassword(password, stored) {
  const parts = String(stored || "").split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;
  const [, n, r, p, salt, hash] = parts;
  const expected = Buffer.from(hash, "base64");
  const key = await scrypt(password, Buffer.from(salt, "base64"), expected.length, {
    N: Number(n),
    r: Number(r),
    p: Number(p),
    maxmem: MAXMEM,
  });
  return crypto.timingSafeEqual(key, expected);
}

let dummy;
// Run a real hash check even when there is no matching account, so timing does not reveal which emails exist.
export async function burnPasswordCheck(password) {
  dummy ??= await hashPassword("not-a-real-password");
  await verifyPassword(password, dummy);
}

export const sha256 = (value) => crypto.createHash("sha256").update(value).digest("hex");
export const newToken = (bytes = 32) => crypto.randomBytes(bytes).toString("base64url");

export function safeEqual(a, b) {
  const left = Buffer.from(String(a));
  const right = Buffer.from(String(b));
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}

// ---- TOTP (RFC 6238), compatible with Google Authenticator, 1Password, Authy ----
const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

export function base32Encode(buffer) {
  let bits = 0;
  let value = 0;
  let out = "";
  for (const byte of buffer) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      out += B32[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}

export function base32Decode(text) {
  let bits = 0;
  let value = 0;
  const out = [];
  for (const char of text.replace(/=+$/, "").toUpperCase()) {
    const index = B32.indexOf(char);
    if (index < 0) continue;
    value = (value << 5) | index;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

export function hotp(secret, counter) {
  const msg = Buffer.alloc(8);
  msg.writeBigUInt64BE(BigInt(counter));
  const digest = crypto.createHmac("sha1", base32Decode(secret)).update(msg).digest();
  const offset = digest[19] & 15;
  const code =
    (((digest[offset] & 0x7f) << 24) | (digest[offset + 1] << 16) | (digest[offset + 2] << 8) | digest[offset + 3]) % 1_000_000;
  return String(code).padStart(6, "0");
}

export function totpNow(secret, now = Date.now()) {
  return hotp(secret, Math.floor(now / 30000));
}

// Accepts the current 30-second window and one either side. A step that was already used is refused (no replay).
export function verifyTotp(secret, code, lastStep = 0, now = Date.now()) {
  const clean = String(code || "").replace(/\s+/g, "");
  if (!/^\d{6}$/.test(clean)) return { ok: false };
  const current = Math.floor(now / 30000);
  for (const delta of [-1, 0, 1]) {
    const step = current + delta;
    if (step <= lastStep) continue;
    if (safeEqual(hotp(secret, step), clean)) return { ok: true, step };
  }
  return { ok: false };
}

export function newTotpSecret() {
  return base32Encode(crypto.randomBytes(20));
}

// ---- tiny in-memory rate limiter ----
export class Limiter {
  constructor(max, windowMs) {
    this.max = max;
    this.windowMs = windowMs;
    this.hits = new Map();
  }
  check(key, now = Date.now()) {
    const entry = this.hits.get(key);
    if (!entry || entry.resetAt <= now) return { ok: true, retryAfter: 0 };
    return entry.count >= this.max ? { ok: false, retryAfter: Math.ceil((entry.resetAt - now) / 1000) } : { ok: true, retryAfter: 0 };
  }
  hit(key, now = Date.now()) {
    const entry = this.hits.get(key);
    if (!entry || entry.resetAt <= now) this.hits.set(key, { count: 1, resetAt: now + this.windowMs });
    else entry.count += 1;
    if (this.hits.size > 5000) for (const [k, v] of this.hits) if (v.resetAt <= now) this.hits.delete(k);
  }
  clear(key) {
    this.hits.delete(key);
  }
}

const COMMON = new Set(["password1234", "123456789012", "qwertyuiop12", "letmein12345", "administrator", "iloveyou1234"]);

export function passwordProblem(password, email = "") {
  if (typeof password !== "string" || password.length < 12) return "Use at least 12 characters.";
  if (password.length > 200) return "That password is too long.";
  const lower = password.toLowerCase();
  if (COMMON.has(lower)) return "That password is too common.";
  const address = String(email).toLowerCase();
  if (address.length >= 5 && lower.includes(address)) return "Do not use your email address inside the password.";
  const local = address.split("@")[0];
  if (local.length >= 4 && lower.includes(local)) return "Do not use your email name inside the password.";
  if (/^(.)\1+$/.test(password)) return "Use a mix of characters, not one repeated.";
  return "";
}
