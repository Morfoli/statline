import path from "node:path";
import { fileURLToPath } from "node:url";
import { createApp } from "./app.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const port = Number(process.env.PORT) || 8787;
const host = process.env.HOST || (process.env.PORT ? "0.0.0.0" : "127.0.0.1");

const app = createApp({
  dataDir: process.env.DATA_DIR || path.join(root, "data"),
  distDir: path.join(root, "dist"),
  setupToken: process.env.ADMIN_SETUP_TOKEN || "",
  trustProxy: process.env.TRUST_PROXY === "1",
  secureCookies: process.env.SECURE_COOKIES === "1",
});

app.server.listen(port, host, () => {
  const where = host === "0.0.0.0" ? `port ${port}` : `http://${host}:${port}`;
  console.log(`\nStatline is running on ${where}`);
  console.log(`Data folder: ${process.env.DATA_DIR || path.join(root, "data")}`);
  if (app.setupToken) {
    console.log("\nNo owner account exists yet. Open /#/admin and create it with this one-time setup token:\n");
    console.log(`    ${app.setupToken}\n`);
    console.log("Only someone who can read this console can claim the account.");
  } else {
    console.log("Admin: open /#/admin");
  }
});

for (const signal of ["SIGINT", "SIGTERM"]) {
  process.on(signal, () => {
    void app.close().then(() => process.exit(0));
  });
}
