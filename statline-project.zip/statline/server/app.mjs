import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { Store } from "./store.mjs";
import * as auth from "./auth.mjs";
import * as v from "./validate.mjs";

const ADMIN_COOKIE = "statline_admin";
const PLUS_COOKIE = "statline_plus";
const IDLE_MS = 8 * 60 * 60 * 1000;
const MAX_MS = 7 * 24 * 60 * 60 * 1000;
const DAY_MS = 24 * 60 * 60 * 1000;

// The single owner holds every permission. Each admin route names the one it needs, so adding a
// limited role later means giving it a shorter list, not rewriting the routes.
export const PERMISSIONS = [
  "site:manage",
  "monetization:manage",
  "subscribers:manage",
  "codes:manage",
  "analytics:view",
  "security:manage",
  "data:export",
];

const SECURITY_HEADERS = {
  "x-content-type-options": "nosniff",
  "x-frame-options": "DENY",
  "referrer-policy": "strict-origin-when-cross-origin",
  "permissions-policy": "geolocation=(), camera=(), microphone=()",
};

export function createApp({ dataDir, distDir, setupToken = "", trustProxy = false, secureCookies = false } = {}) {
  const store = new Store(dataDir);
  let pendingSetupToken = store.data.owner ? "" : setupToken || auth.newToken(18);

  const loginLimit = new auth.Limiter(8, 15 * 60 * 1000);
  const setupLimit = new auth.Limiter(5, 15 * 60 * 1000);
  const subscribeLimit = new auth.Limiter(6, 60 * 60 * 1000);
  const redeemLimit = new auth.Limiter(10, 15 * 60 * 1000);
  const trackLimit = new auth.Limiter(240, 60 * 1000);
  const sensitiveLimit = new auth.Limiter(10, 15 * 60 * 1000);

  // ------------------------------------------------------------------ helpers
  const clientIp = (req) =>
    (trustProxy && String(req.headers["x-forwarded-for"] || "").split(",")[0].trim()) || req.socket.remoteAddress || "unknown";

  function send(res, status, body, headers = {}) {
    const isText = typeof body === "string";
    res.writeHead(status, {
      "content-type": isText ? "text/plain; charset=utf-8" : "application/json; charset=utf-8",
      "cache-control": "no-store",
      ...SECURITY_HEADERS,
      ...headers,
    });
    res.end(status === 204 ? undefined : isText ? body : JSON.stringify(body));
  }

  async function readJson(req, limit = 100_000) {
    if (!String(req.headers["content-type"] || "").includes("application/json")) throw new v.Bad("Send JSON.", 415);
    let size = 0;
    const chunks = [];
    for await (const chunk of req) {
      size += chunk.length;
      if (size > limit) throw new v.Bad("That request is too large.", 413);
      chunks.push(chunk);
    }
    if (chunks.length === 0) return {};
    try {
      return JSON.parse(Buffer.concat(chunks).toString("utf8"));
    } catch {
      throw new v.Bad("That was not valid JSON.");
    }
  }

  function parseCookies(req) {
    const out = {};
    for (const part of String(req.headers.cookie || "").split(";")) {
      const at = part.indexOf("=");
      if (at > 0) out[part.slice(0, at).trim()] = decodeURIComponent(part.slice(at + 1).trim());
    }
    return out;
  }

  const isHttps = (req) => secureCookies || (trustProxy && req.headers["x-forwarded-proto"] === "https");

  function cookieHeader(req, name, value, maxAgeSeconds) {
    return `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAgeSeconds}${isHttps(req) ? "; Secure" : ""}`;
  }

  // ------------------------------------------------------------------ sessions
  function sessionFrom(req) {
    const raw = parseCookies(req)[ADMIN_COOKIE];
    if (!raw || !store.data.owner) return null;
    const id = auth.sha256(raw);
    const now = Date.now();
    const session = store.data.sessions.find((s) => s.id === id && s.expires > now && s.idleUntil > now);
    if (!session) return null;
    session.lastSeen = now;
    session.idleUntil = Math.min(now + IDLE_MS, session.expires);
    store.touch();
    return session;
  }

  function startSession(req) {
    const token = auth.newToken();
    const now = Date.now();
    if (store.data.sessions.length >= 20) store.data.sessions.sort((a, b) => b.lastSeen - a.lastSeen).length = 19;
    store.data.sessions.push({
      id: auth.sha256(token),
      createdAt: now,
      lastSeen: now,
      idleUntil: now + IDLE_MS,
      expires: now + MAX_MS,
      ip: clientIp(req),
      ua: String(req.headers["user-agent"] || "").slice(0, 160),
      perms: ["*"],
    });
    return cookieHeader(req, ADMIN_COOKIE, token, Math.floor(MAX_MS / 1000));
  }

  const can = (session, permission) => session.perms.includes("*") || session.perms.includes(permission);

  function guard(req, res, permission) {
    const session = sessionFrom(req);
    if (!session) {
      send(res, 401, { error: "Sign in to continue." });
      return null;
    }
    if (!can(session, permission)) {
      send(res, 403, { error: "You do not have permission to do that." });
      return null;
    }
    return session;
  }

  // Cross-site pages cannot send a custom header or JSON without a CORS preflight, and this server answers none.
  // The Origin check is a second layer for browsers that include it.
  function csrfOk(req) {
    if (req.headers["x-statline"] !== "1") return false;
    const origin = req.headers.origin;
    if (!origin) return true;
    try {
      return new URL(origin).host === req.headers.host;
    } catch {
      return false;
    }
  }

  // ------------------------------------------------------------------ Plus entitlement
  const sign = (payload) => crypto.createHmac("sha256", store.data.secret).update(payload).digest("base64url");

  function plusCookie(req, days) {
    const exp = Date.now() + days * DAY_MS;
    const payload = Buffer.from(JSON.stringify({ exp })).toString("base64url");
    return cookieHeader(req, PLUS_COOKIE, `${payload}.${sign(payload)}`, days * 86400);
  }

  function entitled(req) {
    const raw = parseCookies(req)[PLUS_COOKIE];
    if (!raw) return false;
    const [payload, sig] = raw.split(".");
    if (!payload || !sig || !auth.safeEqual(sig, sign(payload))) return false;
    try {
      return JSON.parse(Buffer.from(payload, "base64url").toString("utf8")).exp > Date.now();
    } catch {
      return false;
    }
  }

  // ------------------------------------------------------------------ public config
  function publicConfig(req) {
    const s = store.data.settings;
    const plus = entitled(req);
    const today = new Date().toISOString().slice(0, 10);
    const promos = plus
      ? []
      : store.data.promos
          .filter((p) => p.enabled && (!p.startsAt || p.startsAt <= today) && (!p.endsAt || p.endsAt >= today))
          .map(({ id, title, body, cta, kind, placements, sports, weight }) => ({ id, title, body, cta, kind, placements, sports, weight }));
    const slots = {};
    for (const [name, slot] of Object.entries(s.ads.slots)) {
      const live = !plus && s.ads.provider !== "none" || (!plus && slot.type === "custom");
      slots[name] = {
        enabled: Boolean(slot.enabled && live),
        type: slot.type,
        adsenseSlot: slot.type === "adsense" ? slot.adsenseSlot : "",
        customHtml: slot.type === "custom" ? slot.customHtml : "",
      };
    }
    return {
      siteName: s.siteName,
      announcement: s.announcement.enabled ? s.announcement : { enabled: false, text: "", url: "" },
      features: s.features,
      ads: { provider: plus ? "none" : s.ads.provider, publisherId: s.ads.publisherId, requireConsent: s.ads.requireConsent, slots },
      support: s.support,
      plus: { enabled: s.plus.enabled, name: s.plus.name, price: s.plus.price, pitch: s.plus.pitch, buyUrl: s.plus.buyUrl },
      legal: { contactEmail: s.legal.contactEmail, privacyText: s.legal.privacyText, affiliateNote: s.legal.affiliateNote },
      promos,
      entitled: plus,
    };
  }

  // ------------------------------------------------------------------ analytics
  function overview() {
    const days = store.data.stats.days;
    const sum = (obj) => Object.values(obj || {}).reduce((a, b) => a + b, 0);
    const series = [];
    const totals = { views: 0, promoViews: 0, promoClicks: 0, subs: 0, redeems: 0 };
    const pages = {};
    const promoStats = {};
    for (let i = 29; i >= 0; i -= 1) {
      const key = new Date(Date.now() - i * DAY_MS).toISOString().slice(0, 10);
      const d = days[key];
      const row = { date: key, views: d ? sum(d.views) : 0, clicks: d ? sum(d.promoClicks) : 0, subs: d ? d.subs : 0 };
      series.push(row);
      if (!d) continue;
      totals.views += row.views;
      totals.promoViews += sum(d.promoViews);
      totals.promoClicks += row.clicks;
      totals.subs += d.subs;
      totals.redeems += d.redeems;
      for (const [page, n] of Object.entries(d.views)) pages[page] = (pages[page] || 0) + n;
      for (const [id, n] of Object.entries(d.promoViews)) (promoStats[id] ??= { views: 0, clicks: 0 }).views += n;
      for (const [id, n] of Object.entries(d.promoClicks)) (promoStats[id] ??= { views: 0, clicks: 0 }).clicks += n;
    }
    return {
      totals,
      series,
      topPages: Object.entries(pages).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([page, views]) => ({ page, views })),
      promos: store.data.promos.map((p) => {
        const st = promoStats[p.id] || { views: 0, clicks: 0 };
        return { id: p.id, title: p.title, views: st.views, clicks: st.clicks, ctr: st.views ? st.clicks / st.views : 0 };
      }),
      counts: {
        subscribers: store.data.subscribers.length,
        activePromos: store.data.promos.filter((p) => p.enabled).length,
        activeCodes: store.data.codes.filter((c) => !c.revoked && (!c.expiresAt || c.expiresAt > Date.now()) && (!c.maxUses || c.uses < c.maxUses)).length,
      },
    };
  }

  // ------------------------------------------------------------------ public routes
  async function publicRoutes(req, res, url) {
    const { pathname } = url;

    if (req.method === "GET" && pathname === "/api/health") return send(res, 200, { ok: true });

    if (req.method === "GET" && pathname === "/api/config") return send(res, 200, { ok: true, config: publicConfig(req) });

    if (req.method === "POST" && pathname === "/api/track") {
      const body = await readJson(req, 2000);
      const ip = clientIp(req);
      if (!trackLimit.check(ip).ok) return send(res, 204, "");
      trackLimit.hit(ip);
      const d = store.day();
      const id = String(body.id ?? "");
      if (body.type === "view" && v.TRACKABLE_PAGES.has(id)) d.views[id] = (d.views[id] || 0) + 1;
      else if (body.type === "promo" && store.data.promos.some((p) => p.id === id)) d.promoViews[id] = (d.promoViews[id] || 0) + 1;
      else if (body.type === "ad" && ["header", "inline", "footer"].includes(id)) d.adViews[id] = (d.adViews[id] || 0) + 1;
      store.touch();
      return send(res, 204, "");
    }

    const go = pathname.match(/^\/go\/([a-f0-9]{12})$/);
    if (req.method === "GET" && go) {
      const promo = store.data.promos.find((p) => p.id === go[1]);
      if (!promo || !promo.enabled) return send(res, 302, "", { location: "/" });
      const d = store.day();
      d.promoClicks[promo.id] = (d.promoClicks[promo.id] || 0) + 1;
      store.touch();
      return send(res, 302, "", { location: promo.url, "referrer-policy": "no-referrer", "x-robots-tag": "noindex" });
    }

    if (req.method === "POST" && pathname === "/api/subscribe") {
      const body = await readJson(req, 2000);
      const ip = clientIp(req);
      if (!store.data.settings.features.subscribe) throw new v.Bad("Sign-ups are closed.", 403);
      if (!subscribeLimit.check(ip).ok) throw new v.Bad("Too many sign-ups from here. Try again later.", 429);
      subscribeLimit.hit(ip);
      if (body.website) return send(res, 200, { ok: true }); // honeypot: bots fill hidden fields
      const address = v.email(body.email);
      if (store.data.subscribers.length >= 50000) throw new v.Bad("Sign-ups are full right now.", 503);
      if (!store.data.subscribers.some((s) => s.email === address)) {
        store.data.subscribers.push({ id: crypto.randomBytes(6).toString("hex"), email: address, createdAt: Date.now(), source: v.text(body.source, 24, "Source") || "site" });
        store.day().subs += 1;
        store.flush();
      }
      return send(res, 200, { ok: true });
    }

    if (req.method === "POST" && pathname === "/api/plus/redeem") {
      const body = await readJson(req, 2000);
      const ip = clientIp(req);
      const plus = store.data.settings.plus;
      if (!plus.enabled) throw new v.Bad("Plus is not available right now.", 403);
      if (!redeemLimit.check(ip).ok) throw new v.Bad("Too many tries. Wait a few minutes.", 429);
      const wanted = v.normalizeCode(body.code);
      const code = wanted && store.data.codes.find((c) => v.normalizeCode(c.code) === wanted);
      const now = Date.now();
      if (!code || code.revoked || (code.expiresAt && code.expiresAt <= now) || (code.maxUses && code.uses >= code.maxUses)) {
        redeemLimit.hit(ip);
        throw new v.Bad("That code is not valid.", 400);
      }
      code.uses += 1;
      store.day().redeems += 1;
      store.flush();
      return send(res, 200, { ok: true }, { "set-cookie": plusCookie(req, plus.durationDays) });
    }

    if (req.method === "POST" && pathname === "/api/plus/leave") {
      return send(res, 200, { ok: true }, { "set-cookie": cookieHeader(req, PLUS_COOKIE, "", 0) });
    }

    if (req.method === "GET" && pathname === "/ads.txt") {
      const body = store.data.settings.ads.adsTxt;
      return body ? send(res, 200, body + "\n", { "cache-control": "public, max-age=300" }) : send(res, 404, "Not found");
    }
    if (req.method === "GET" && pathname === "/robots.txt") return send(res, 200, "User-agent: *\nDisallow: /api/\nDisallow: /go/\n");
    return null;
  }

  // ------------------------------------------------------------------ admin routes
  async function adminRoutes(req, res, url) {
    const { pathname } = url;
    const method = req.method;
    const ip = clientIp(req);

    if (method !== "GET" && method !== "HEAD" && !csrfOk(req)) throw new v.Bad("Request blocked (missing or foreign origin).", 403);

    if (method === "GET" && pathname === "/api/admin/status") {
      const session = sessionFrom(req);
      return send(res, 200, {
        needsSetup: !store.data.owner,
        loggedIn: Boolean(session),
        email: session ? store.data.owner.email : undefined,
        totpEnabled: session ? Boolean(store.data.owner.totp) : undefined,
        permissions: session ? PERMISSIONS : undefined,
      });
    }

    if (method === "POST" && pathname === "/api/admin/setup") {
      if (store.data.owner) throw new v.Bad("This site already has an owner.", 409);
      if (!setupLimit.check(ip).ok) throw new v.Bad("Too many tries. Wait a few minutes.", 429);
      const body = await readJson(req, 4000);
      if (!pendingSetupToken || !auth.safeEqual(String(body.token ?? "").trim(), pendingSetupToken)) {
        setupLimit.hit(ip);
        throw new v.Bad("That setup token is not right. It is printed in the server console.", 403);
      }
      const email = v.email(body.email);
      const problem = auth.passwordProblem(body.password, email);
      if (problem) throw new v.Bad(problem);
      store.data.owner = { email, passHash: await auth.hashPassword(body.password), createdAt: Date.now(), totp: null };
      pendingSetupToken = "";
      store.audit("setup", ip);
      const cookie = startSession(req);
      store.flush();
      return send(res, 200, { ok: true }, { "set-cookie": cookie });
    }

    if (method === "POST" && pathname === "/api/admin/login") {
      if (!loginLimit.check(ip).ok) throw new v.Bad(`Too many tries. Wait ${Math.ceil(loginLimit.check(ip).retryAfter / 60)} minutes.`, 429);
      const body = await readJson(req, 4000);
      const owner = store.data.owner;
      const emailMatches = owner && String(body.email ?? "").trim().toLowerCase() === owner.email;
      const passwordOk = emailMatches ? await auth.verifyPassword(String(body.password ?? ""), owner.passHash) : (await auth.burnPasswordCheck(String(body.password ?? "")), false);
      const fail = async (message) => {
        loginLimit.hit(ip);
        store.audit("login_failed", ip);
        store.touch();
        await new Promise((r) => setTimeout(r, 300));
        throw new v.Bad(message, 401);
      };
      if (!passwordOk) return fail("Wrong email or password.");
      if (owner.totp) {
        if (!body.code) return send(res, 200, { ok: false, needsCode: true });
        const check = auth.verifyTotp(owner.totp.secret, body.code, owner.totp.lastStep);
        if (!check.ok) return fail("That code is not right.");
        owner.totp.lastStep = check.step;
      }
      loginLimit.clear(ip);
      store.audit("login", ip);
      const cookie = startSession(req);
      store.flush();
      return send(res, 200, { ok: true }, { "set-cookie": cookie });
    }

    if (method === "POST" && pathname === "/api/admin/logout") {
      const raw = parseCookies(req)[ADMIN_COOKIE];
      if (raw) {
        const id = auth.sha256(raw);
        store.data.sessions = store.data.sessions.filter((s) => s.id !== id);
        store.audit("logout", ip);
        store.flush();
      }
      return send(res, 200, { ok: true }, { "set-cookie": cookieHeader(req, ADMIN_COOKIE, "", 0) });
    }

    // ---- everything below needs a signed-in owner ----
    if (method === "GET" && pathname === "/api/admin/overview") {
      if (!guard(req, res, "analytics:view")) return;
      return send(res, 200, overview());
    }

    if (pathname === "/api/admin/settings") {
      if (method === "GET") {
        if (!guard(req, res, "site:manage")) return;
        return send(res, 200, { settings: store.data.settings });
      }
      if (method === "PUT") {
        const session = guard(req, res, "site:manage");
        if (!session) return;
        const body = await readJson(req, 120_000);
        const wantsMoney = Boolean(body.ads || body.support || body.plus);
        if (wantsMoney && !can(session, "monetization:manage")) return send(res, 403, { error: "You do not have permission to do that." });
        store.data.settings = v.cleanSettings(body, store.data.settings);
        store.audit("settings_saved", Object.keys(body).join(","));
        store.flush();
        return send(res, 200, { settings: store.data.settings });
      }
    }

    if (pathname === "/api/admin/promos" || pathname.startsWith("/api/admin/promos/")) {
      if (!guard(req, res, "monetization:manage")) return;
      const id = pathname.split("/")[4];
      if (method === "GET" && !id) return send(res, 200, { promos: store.data.promos });
      if (method === "POST" && !id) {
        const promo = v.cleanPromo(await readJson(req, 20_000));
        if (store.data.promos.length >= 200) throw new v.Bad("That is the limit of 200 promotions.");
        store.data.promos.push(promo);
        store.audit("promo_created", promo.title);
        store.flush();
        return send(res, 200, { promo });
      }
      const index = store.data.promos.findIndex((p) => p.id === id);
      if (index < 0) throw new v.Bad("That promotion no longer exists.", 404);
      if (method === "PUT") {
        const promo = v.cleanPromo(await readJson(req, 20_000), store.data.promos[index]);
        store.data.promos[index] = promo;
        store.audit("promo_updated", promo.title);
        store.flush();
        return send(res, 200, { promo });
      }
      if (method === "DELETE") {
        const [removed] = store.data.promos.splice(index, 1);
        store.audit("promo_deleted", removed.title);
        store.flush();
        return send(res, 200, { ok: true });
      }
    }

    if (pathname === "/api/admin/codes" || pathname.startsWith("/api/admin/codes/")) {
      if (!guard(req, res, "codes:manage")) return;
      const id = pathname.split("/")[4];
      if (method === "GET" && !id) return send(res, 200, { codes: store.data.codes });
      if (method === "POST" && !id) {
        const body = await readJson(req, 2000);
        const count = Math.min(50, Math.max(1, Math.round(Number(body.count) || 1)));
        const maxUses = Math.min(100000, Math.max(0, Math.round(Number(body.maxUses) || 1)));
        const days = Math.round(Number(body.expiresInDays) || 0);
        const made = [];
        for (let i = 0; i < count; i += 1) {
          made.push({
            id: crypto.randomBytes(6).toString("hex"),
            code: v.makeCode(),
            label: v.text(body.label, 60, "Label"),
            createdAt: Date.now(),
            expiresAt: days > 0 ? Date.now() + Math.min(days, 3650) * DAY_MS : 0,
            maxUses,
            uses: 0,
            revoked: false,
          });
        }
        store.data.codes.push(...made);
        store.audit("codes_created", `${count}`);
        store.flush();
        return send(res, 200, { codes: made });
      }
      const code = store.data.codes.find((c) => c.id === id);
      if (!code) throw new v.Bad("That code no longer exists.", 404);
      if (method === "DELETE") {
        code.revoked = true;
        store.audit("code_revoked", code.label || code.id);
        store.flush();
        return send(res, 200, { ok: true });
      }
    }

    if (pathname === "/api/admin/subscribers.csv" && method === "GET") {
      if (!guard(req, res, "subscribers:manage")) return;
      const rows = ["email,signed_up,source", ...store.data.subscribers.map((s) => [v.csvCell(s.email), new Date(s.createdAt).toISOString(), v.csvCell(s.source)].join(","))];
      store.audit("subscribers_exported", `${store.data.subscribers.length}`);
      store.touch();
      return send(res, 200, rows.join("\n") + "\n", { "content-type": "text/csv; charset=utf-8", "content-disposition": 'attachment; filename="statline-subscribers.csv"' });
    }

    if (pathname === "/api/admin/subscribers" || pathname.startsWith("/api/admin/subscribers/")) {
      if (!guard(req, res, "subscribers:manage")) return;
      const id = pathname.split("/")[4];
      if (method === "GET" && !id) return send(res, 200, { subscribers: [...store.data.subscribers].reverse() });
      if (method === "DELETE" && id) {
        const before = store.data.subscribers.length;
        store.data.subscribers = store.data.subscribers.filter((s) => s.id !== id);
        if (store.data.subscribers.length === before) throw new v.Bad("That subscriber no longer exists.", 404);
        store.audit("subscriber_removed", id);
        store.flush();
        return send(res, 200, { ok: true });
      }
    }

    if (method === "GET" && pathname === "/api/admin/export") {
      if (!guard(req, res, "data:export")) return;
      const { settings, promos, codes, subscribers, stats } = store.data;
      store.audit("data_exported");
      store.touch();
      return send(res, 200, { exportedAt: new Date().toISOString(), settings, promos, codes, subscribers, stats }, { "content-disposition": 'attachment; filename="statline-backup.json"' });
    }

    if (method === "GET" && pathname === "/api/admin/audit") {
      if (!guard(req, res, "security:manage")) return;
      return send(res, 200, { audit: [...store.data.audit].reverse().slice(0, 100) });
    }

    if (method === "GET" && pathname === "/api/admin/sessions") {
      const me = guard(req, res, "security:manage");
      if (!me) return;
      return send(res, 200, {
        sessions: store.data.sessions.map((s) => ({ id: s.id.slice(0, 8), createdAt: s.createdAt, lastSeen: s.lastSeen, ip: s.ip, ua: s.ua, current: s.id === me.id })),
      });
    }

    if (method === "POST" && pathname === "/api/admin/sessions/revoke-others") {
      const me = guard(req, res, "security:manage");
      if (!me) return;
      store.data.sessions = store.data.sessions.filter((s) => s.id === me.id);
      store.audit("sessions_revoked", ip);
      store.flush();
      return send(res, 200, { ok: true });
    }

    if (method === "POST" && pathname === "/api/admin/password") {
      const me = guard(req, res, "security:manage");
      if (!me) return;
      if (!sensitiveLimit.check(ip).ok) throw new v.Bad("Too many tries. Wait a few minutes.", 429);
      const body = await readJson(req, 4000);
      if (!(await auth.verifyPassword(String(body.current ?? ""), store.data.owner.passHash))) {
        sensitiveLimit.hit(ip);
        throw new v.Bad("Your current password is not right.", 403);
      }
      const problem = auth.passwordProblem(body.next, store.data.owner.email);
      if (problem) throw new v.Bad(problem);
      store.data.owner.passHash = await auth.hashPassword(body.next);
      store.data.sessions = store.data.sessions.filter((s) => s.id === me.id);
      store.audit("password_changed", ip);
      store.flush();
      return send(res, 200, { ok: true });
    }

    if (method === "POST" && pathname === "/api/admin/2fa/begin") {
      if (!guard(req, res, "security:manage")) return;
      if (store.data.owner.totp) throw new v.Bad("Two-step sign-in is already on.", 409);
      const secret = auth.newTotpSecret();
      store.data.owner.totpPending = secret;
      store.flush();
      const label = encodeURIComponent(`Statline:${store.data.owner.email}`);
      return send(res, 200, { secret, uri: `otpauth://totp/${label}?secret=${secret}&issuer=Statline` });
    }

    if (method === "POST" && pathname === "/api/admin/2fa/enable") {
      if (!guard(req, res, "security:manage")) return;
      const owner = store.data.owner;
      if (!owner.totpPending) throw new v.Bad("Start the setup first.", 409);
      if (!sensitiveLimit.check(ip).ok) throw new v.Bad("Too many tries. Wait a few minutes.", 429);
      const body = await readJson(req, 2000);
      const check = auth.verifyTotp(owner.totpPending, body.code, 0);
      if (!check.ok) {
        sensitiveLimit.hit(ip);
        throw new v.Bad("That code is not right. Check the time on your phone and try again.");
      }
      owner.totp = { secret: owner.totpPending, lastStep: check.step };
      delete owner.totpPending;
      store.audit("2fa_enabled", ip);
      store.flush();
      return send(res, 200, { ok: true });
    }

    if (method === "POST" && pathname === "/api/admin/2fa/disable") {
      if (!guard(req, res, "security:manage")) return;
      const owner = store.data.owner;
      if (!owner.totp) throw new v.Bad("Two-step sign-in is already off.", 409);
      if (!sensitiveLimit.check(ip).ok) throw new v.Bad("Too many tries. Wait a few minutes.", 429);
      const body = await readJson(req, 2000);
      const check = auth.verifyTotp(owner.totp.secret, body.code, owner.totp.lastStep);
      if (!(await auth.verifyPassword(String(body.password ?? ""), owner.passHash)) || !check.ok) {
        sensitiveLimit.hit(ip);
        throw new v.Bad("Password or code is not right.", 403);
      }
      owner.totp = null;
      store.audit("2fa_disabled", ip);
      store.flush();
      return send(res, 200, { ok: true });
    }

    return null;
  }

  // ------------------------------------------------------------------ static files
  function serveApp(req, res) {
    const file = path.join(distDir, "index.html");
    fs.readFile(file, (error, buffer) => {
      if (error) return send(res, 503, "The site has not been built yet. Run: npm run build");
      res.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-cache", ...SECURITY_HEADERS });
      res.end(req.method === "HEAD" ? undefined : buffer);
    });
  }

  async function handle(req, res) {
    const url = new URL(req.url, "http://local");
    try {
      if (url.pathname.startsWith("/api/admin/")) {
        const handled = await adminRoutes(req, res, url);
        if (handled === null || (handled === undefined && !res.headersSent)) {
          if (!res.headersSent) send(res, 404, { error: "Not found." });
        }
        return;
      }
      const handled = await publicRoutes(req, res, url);
      if (res.headersSent) return;
      if (handled === null) {
        if (url.pathname.startsWith("/api/") || url.pathname.startsWith("/go/")) return send(res, 404, { error: "Not found." });
        if (req.method === "GET" || req.method === "HEAD") return serveApp(req, res);
        return send(res, 405, { error: "Method not allowed." });
      }
    } catch (error) {
      if (error instanceof v.Bad) return send(res, error.status, { error: error.message });
      console.error("Server error:", error);
      if (!res.headersSent) send(res, 500, { error: "Something went wrong on the server." });
    }
  }

  const server = http.createServer((req, res) => {
    void handle(req, res);
  });
  // Slow-connection attacks: give up on a request that dawdles.
  server.requestTimeout = 30_000;
  server.headersTimeout = 15_000;
  server.keepAliveTimeout = 5_000;

  return {
    server,
    store,
    get setupToken() {
      return pendingSetupToken;
    },
    close() {
      store.flush();
      clearInterval(store.timer);
      return new Promise((resolve) => server.close(() => resolve()));
    },
  };
}
