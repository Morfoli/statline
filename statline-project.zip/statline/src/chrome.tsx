import { useEffect, useMemo, type CSSProperties, type ReactNode } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { leagueById, sportById, sports } from "./data";
import { useFeed, type FeedView } from "./live/LiveProvider";
import { AdSlot } from "./site/Monetization";
import { resolveLeague } from "./live/resolve";
import type { League, Sport } from "./types";

export function useBoard(): {
  sport: Sport | undefined;
  league: League | null;
  setLeague: (id: string) => void;
  feed: FeedView;
} {
  const { sportId } = useParams();
  const sport = sportById(sportId);
  const [params, setParams] = useSearchParams();
  const base = sport ? leagueById(sport, params.get("league")) : null;
  const feed = useFeed(base?.id ?? null);
  const liveData = feed.data;
  const league = useMemo(() => (sport && base ? resolveLeague(sport, base, liveData) : null), [sport, base, liveData]);

  function setLeague(id: string) {
    const next = new URLSearchParams(params);
    next.set("league", id);
    setParams(next);
  }

  return { sport, league, setLeague, feed };
}

export function TopBar() {
  return (
    <header className="top">
      <Link to="/" className="word">
        STAT<span>LINE</span>
      </Link>
      <p className="top-note">
        Men's and women's boards, plus a fantasy review
        <Link to="/status" className="top-link">
          Data sources
        </Link>
      </p>
    </header>
  );
}

export function Missing() {
  return (
    <main className="wrap missing">
      <p className="kicker">Off the board</p>
      <h1>That page is not on the desk.</h1>
      <Link to="/" className="text-link">
        Back to the sports
      </Link>
    </main>
  );
}

function clock(ms: number): string {
  return new Date(ms).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

function FeedChip({ feed, league }: { feed: FeedView; league: League }) {
  if (feed.status === "unsupported") {
    return (
      <p className="feed sample">
        <span className="dot" aria-hidden="true" />
        <span>
          Sample season. This league is not connected to a live feed. <Link to="/status">Data sources</Link>
        </span>
      </p>
    );
  }
  if (feed.status === "loading" && !feed.data) {
    return (
      <p className="feed" role="status">
        <span className="dot" aria-hidden="true" />
        <span>Loading live stats from ESPN…</span>
      </p>
    );
  }
  if (feed.status === "error") {
    return (
      <p className="feed warn" role="status">
        <span className="dot" aria-hidden="true" />
        <span>
          Showing the sample season. Live stats could not load. {feed.error}.{" "}
          <button type="button" className="link-btn" onClick={feed.refresh}>
            Try again
          </button>
          <span aria-hidden="true"> · </span>
          <Link to="/status">Check the feed</Link>
        </span>
      </p>
    );
  }
  const meta = league.live;
  if (!meta) return null;
  const refreshing = feed.status === "loading";
  return (
    <p className={feed.status === "cached" ? "feed warn" : "feed live"} role="status">
      <span className="dot" aria-hidden="true" />
      <span>
        {feed.status === "cached" ? "Saved copy" : "Live"} from {meta.source}, {meta.season} season. {meta.count} players
        {feed.status === "cached" ? `, saved ${clock(meta.fetchedAt)}. Could not refresh. ${feed.error}.` : `, updated ${clock(meta.fetchedAt)}.`}{" "}
        <button type="button" className="link-btn" onClick={feed.refresh} disabled={refreshing}>
          {refreshing ? "Refreshing…" : "Refresh"}
        </button>
      </span>
    </p>
  );
}

export function SportChrome({
  mode,
  sport,
  league,
  feed,
  setLeague,
  children,
}: {
  mode: "desk" | "lab";
  sport: Sport;
  league: League;
  feed: FeedView;
  setLeague: (id: string) => void;
  children: ReactNode;
}) {
  useEffect(() => {
    document.title = `${mode === "lab" ? "Fantasy lab" : "Desk"} · ${league.short} · Statline`;
  }, [mode, league.short]);

  return (
    <main className="wrap sport" style={{ "--accent": sport.accent } as CSSProperties}>
      <nav className="sports-nav" aria-label="Sports">
        {sports.map((entry) => {
          const twin = entry.leagues.find((item) => item.gender === league.gender) ?? entry.leagues[0];
          const path = mode === "lab" ? `/${entry.id}/lab` : `/${entry.id}`;
          return (
            <Link
              key={entry.id}
              to={`${path}?league=${twin.id}`}
              className={entry.id === sport.id ? "on" : ""}
              style={{ "--accent": entry.accent } as CSSProperties}
              aria-current={entry.id === sport.id ? "page" : undefined}
            >
              {entry.name}
            </Link>
          );
        })}
      </nav>

      <header className="sport-head">
        <div>
          <p className="kicker">{sport.name}</p>
          <h1>{league.name}</h1>
          <p className="lede">{league.blurb}</p>
          <FeedChip feed={feed} league={league} />
        </div>
        <div className="head-controls">
          <nav className="modes" aria-label="Section">
            <Link to={`/${sport.id}?league=${league.id}`} className={mode === "desk" ? "on" : ""} aria-current={mode === "desk" ? "page" : undefined}>
              Stats
            </Link>
            <Link
              to={`/${sport.id}/lab?league=${league.id}`}
              className={mode === "lab" ? "on" : ""}
              aria-current={mode === "lab" ? "page" : undefined}
            >
              Fantasy lab
            </Link>
          </nav>
          <div className="sides" role="group" aria-label="Men or women">
            {sport.leagues.map((entry) => (
              <button key={entry.id} type="button" className={entry.id === league.id ? "on" : ""} onClick={() => setLeague(entry.id)}>
                <span>{entry.gender === "men" ? "Men" : "Women"}</span>
                <small>{entry.short}</small>
              </button>
            ))}
          </div>
        </div>
      </header>
      <AdSlot name="header" />
      {children}
    </main>
  );
}
