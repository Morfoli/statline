import { useCallback, useEffect, useState, type FormEvent } from "react";
import { sports } from "../data";
import { FEEDS } from "../live/espn";
import { api, type AdminCode, type AdminPromo, type AdminSettings, type Overview, type Subscriber } from "./api";
import { Check, Field, Notice, when } from "./ui";

type SaveState = { busy: boolean; notice: { kind: "ok" | "bad"; text: string } | null };

// One place that handles "save a part of the settings, show the result".
function useSave(onSaved: (settings: AdminSettings) => void) {
  const [state, setState] = useState<SaveState>({ busy: false, notice: null });
  const save = useCallback(
    async (patch: Partial<AdminSettings>) => {
      setState({ busy: true, notice: null });
      try {
        const res = await api<{ settings: AdminSettings }>("PUT", "/api/admin/settings", patch);
        onSaved(res.settings);
        setState({ busy: false, notice: { kind: "ok", text: "Saved." } });
      } catch (error) {
        setState({ busy: false, notice: { kind: "bad", text: error instanceof Error ? error.message : "Could not save." } });
      }
    },
    [onSaved],
  );
  return { ...state, save };
}

type TabProps = { settings: AdminSettings; onSaved: (settings: AdminSettings) => void };

// ------------------------------------------------------------------ overview
type TabId = "overview" | "promotions" | "ads" | "revenue" | "subscribers" | "site" | "security";

function Checklist({ settings, totpEnabled, promos, go }: { settings: AdminSettings; totpEnabled: boolean; promos: number; go: (tab: TabId) => void }) {
  const adsOn = Object.values(settings.ads.slots).some((slot) => slot.enabled);
  const liveCount = Object.values(settings.features.liveLeagues).filter(Boolean).length;
  const items: { done: boolean; text: string; tab: TabId; caution?: boolean }[] = [
    { done: totpEnabled, text: "Turn on two-step sign-in", tab: "security" },
    { done: Boolean(settings.legal.contactEmail), text: "Add a contact email to the privacy page", tab: "site" },
    { done: promos > 0, text: "Add a live promotion", tab: "promotions" },
    { done: adsOn, text: "Set up an ad slot (needs an approved ad account)", tab: "ads" },
    { done: settings.support.enabled || settings.plus.enabled, text: "Turn on the support link or Plus", tab: "revenue" },
    { done: liveCount === 0, text: `Live ESPN data is on for ${liveCount} league${liveCount === 1 ? "" : "s"}. Its terms limit commercial use, so switch to a licensed provider or turn it off before earning money`, tab: "site", caution: true },
  ];
  return (
    <section aria-label="Launch checklist">
      <h3>Before you earn money</h3>
      <ul className="checklist">
        {items.map((item) => (
          <li key={item.text} className={item.done ? "done" : item.caution ? "caution" : ""}>
            <span className="mark" aria-hidden="true">{item.done ? "✓" : item.caution ? "!" : "○"}</span>
            <span>
              {item.text}
              <span className="sr">{item.done ? " (done)" : " (to do)"}</span>
            </span>
            {!item.done ? <button type="button" className="link-btn" onClick={() => go(item.tab)}>Open</button> : null}
          </li>
        ))}
      </ul>
    </section>
  );
}

export function OverviewTab({ settings, totpEnabled, go }: { settings: AdminSettings | null; totpEnabled: boolean; go: (tab: TabId) => void }) {
  const [data, setData] = useState<Overview | null>(null);
  const [error, setError] = useState("");
  useEffect(() => {
    api<Overview>("GET", "/api/admin/overview")
      .then(setData)
      .catch((e: Error) => setError(e.message));
  }, []);
  if (error) return <Notice kind="bad">{error}</Notice>;
  if (!data) return <p className="hint-plain">Loading…</p>;
  const max = Math.max(1, ...data.series.map((d) => d.views));
  const ctr = data.totals.promoViews ? ((data.totals.promoClicks / data.totals.promoViews) * 100).toFixed(1) : "0.0";
  return (
    <div className="atab">
      <h2>Last 30 days</h2>
      <ul className="cards" aria-label="Totals">
        <li><strong>{data.totals.views}</strong><span>Page views</span></li>
        <li><strong>{data.totals.promoClicks}</strong><span>Promotion clicks</span></li>
        <li><strong>{ctr}%</strong><span>Click rate</span></li>
        <li><strong>{data.totals.subs}</strong><span>New subscribers</span></li>
        <li><strong>{data.totals.redeems}</strong><span>Plus codes used</span></li>
        <li><strong>{data.counts.subscribers}</strong><span>Subscribers in total</span></li>
      </ul>
      <div className="spark" role="img" aria-label="Page views per day for the last 30 days">
        {data.series.map((d) => (
          <i key={d.date} title={`${d.date}: ${d.views} views`} style={{ height: `${Math.max(3, (d.views / max) * 100)}%` }} />
        ))}
      </div>
      <div className="two">
        <div>
          <h3>Top pages</h3>
          {data.topPages.length === 0 ? <p className="hint-plain">No visits counted yet.</p> : (
            <table className="status-table small"><tbody>
              {data.topPages.map((p) => (<tr key={p.page}><th scope="row" className="plain">{p.page}</th><td className="num">{p.views}</td></tr>))}
            </tbody></table>
          )}
        </div>
        <div>
          <h3>Promotions</h3>
          {data.promos.length === 0 ? <p className="hint-plain">Add one on the Promotions tab.</p> : (
            <table className="status-table small">
              <thead><tr><th className="left">Name</th><th>Seen</th><th>Clicks</th><th>Rate</th></tr></thead>
              <tbody>
                {data.promos.map((p) => (<tr key={p.id}><th scope="row" className="plain">{p.title}</th><td className="num">{p.views}</td><td className="num">{p.clicks}</td><td className="num">{(p.ctr * 100).toFixed(1)}%</td></tr>))}
              </tbody>
            </table>
          )}
        </div>
      </div>
      <p className="hint-plain">Counts are anonymous: no cookies and no personal details. Visitors with Do Not Track or Global Privacy Control on are not counted.</p>
      {settings ? <Checklist settings={settings} totpEnabled={totpEnabled} promos={data.counts.activePromos} go={go} /> : null}
    </div>
  );
}

// ------------------------------------------------------------------ promotions
const BLANK: AdminPromo = { id: "", title: "", body: "", cta: "Learn more", url: "", kind: "affiliate", placements: ["home"], sports: [], enabled: true, startsAt: "", endsAt: "", weight: 1 };

export function PromotionsTab() {
  const [promos, setPromos] = useState<AdminPromo[]>([]);
  const [stats, setStats] = useState<Overview["promos"]>([]);
  const [draft, setDraft] = useState<AdminPromo | null>(null);
  const [notice, setNotice] = useState<{ kind: "ok" | "bad"; text: string } | null>(null);

  const load = useCallback(async () => {
    const [list, overview] = await Promise.all([api<{ promos: AdminPromo[] }>("GET", "/api/admin/promos"), api<Overview>("GET", "/api/admin/overview")]);
    setPromos(list.promos);
    setStats(overview.promos);
  }, []);
  useEffect(() => {
    void load().catch((e: Error) => setNotice({ kind: "bad", text: e.message }));
  }, [load]);

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!draft) return;
    try {
      if (draft.id) await api("PUT", `/api/admin/promos/${draft.id}`, draft);
      else await api("POST", "/api/admin/promos", draft);
      setDraft(null);
      setNotice({ kind: "ok", text: "Promotion saved." });
      await load();
    } catch (error) {
      setNotice({ kind: "bad", text: error instanceof Error ? error.message : "Could not save." });
    }
  }

  async function toggle(promo: AdminPromo) {
    await api("PUT", `/api/admin/promos/${promo.id}`, { ...promo, enabled: !promo.enabled });
    await load();
  }
  async function remove(promo: AdminPromo) {
    if (!window.confirm(`Delete "${promo.title}"?`)) return;
    await api("DELETE", `/api/admin/promos/${promo.id}`);
    await load();
  }
  const flip = (list: string[], value: string) => (list.includes(value) ? list.filter((v) => v !== value) : [...list, value]);

  return (
    <div className="atab">
      <div className="status-head">
        <h2>Promotions</h2>
        <button type="button" className="ghost" onClick={() => setDraft({ ...BLANK })}>New promotion</button>
      </div>
      <p className="hint-plain">
        Affiliate and sponsor cards shown on the home, stats and fantasy pages. Each card is labelled automatically and clicks are counted. Some programs
        (betting, for example) have age and licensing rules, so check the program's terms before you promote it.
      </p>
      {notice ? <Notice kind={notice.kind}>{notice.text}</Notice> : null}

      {draft ? (
        <form className="aform" onSubmit={(e) => void submit(e)}>
          <h3>{draft.id ? "Edit promotion" : "New promotion"}</h3>
          <Field label="Title"><input value={draft.title} maxLength={80} onChange={(e) => setDraft({ ...draft, title: e.target.value })} required /></Field>
          <Field label="Description" hint="One or two short sentences."><textarea rows={2} maxLength={240} value={draft.body} onChange={(e) => setDraft({ ...draft, body: e.target.value })} /></Field>
          <div className="arow">
            <Field label="Link (your affiliate or sponsor URL)"><input type="url" value={draft.url} onChange={(e) => setDraft({ ...draft, url: e.target.value })} placeholder="https://" required /></Field>
            <Field label="Button text"><input value={draft.cta} maxLength={30} onChange={(e) => setDraft({ ...draft, cta: e.target.value })} /></Field>
          </div>
          <div className="arow">
            <Field label="Type" hint="Sets the label shown on the card.">
              <select value={draft.kind} onChange={(e) => setDraft({ ...draft, kind: e.target.value as AdminPromo["kind"] })}>
                <option value="affiliate">Affiliate link</option>
                <option value="sponsor">Sponsored</option>
                <option value="house">From Statline (your own)</option>
              </select>
            </Field>
            <Field label="Weight (1 to 10)" hint="Higher shows more often."><input type="number" min={1} max={10} value={draft.weight} onChange={(e) => setDraft({ ...draft, weight: Number(e.target.value) })} /></Field>
          </div>
          <fieldset><legend>Where it shows</legend>
            {(["home", "desk", "lab"] as const).map((place) => (
              <Check key={place} label={place === "home" ? "Home page" : place === "desk" ? "Stats pages" : "Fantasy lab"} checked={draft.placements.includes(place)} onChange={() => setDraft({ ...draft, placements: flip(draft.placements, place) })} />
            ))}
          </fieldset>
          <fieldset><legend>Only on these sports (none ticked means all)</legend>
            <div className="checkgrid">
              {sports.map((sport) => (<Check key={sport.id} label={sport.name} checked={draft.sports.includes(sport.id)} onChange={() => setDraft({ ...draft, sports: flip(draft.sports, sport.id) })} />))}
            </div>
          </fieldset>
          <div className="arow">
            <Field label="Starts"><input type="date" value={draft.startsAt} onChange={(e) => setDraft({ ...draft, startsAt: e.target.value })} /></Field>
            <Field label="Ends"><input type="date" value={draft.endsAt} onChange={(e) => setDraft({ ...draft, endsAt: e.target.value })} /></Field>
          </div>
          <Check label="Live" checked={draft.enabled} onChange={(value) => setDraft({ ...draft, enabled: value })} />
          <div className="aactions">
            <button type="submit" className="primary">Save promotion</button>
            <button type="button" className="ghost" onClick={() => setDraft(null)}>Cancel</button>
          </div>
        </form>
      ) : null}

      {promos.length === 0 && !draft ? <p className="hint-plain">No promotions yet.</p> : (
        <div className="table-wrap" tabIndex={0} role="region" aria-label="Promotions list"><table className="status-table">
          <thead><tr><th className="left">Promotion</th><th className="left">Status</th><th>Seen</th><th>Clicks</th><th className="left">Actions</th></tr></thead>
          <tbody>
            {promos.map((promo) => {
              const st = stats.find((s) => s.id === promo.id);
              return (
                <tr key={promo.id}>
                  <th scope="row" className="plain">{promo.title}<span className="detail">{promo.kind} · {promo.placements.join(", ")}{promo.sports.length ? ` · ${promo.sports.join(", ")}` : ""}</span></th>
                  <td className={`left result ${promo.enabled ? "ok" : ""}`}>{promo.enabled ? "Live" : "Paused"}</td>
                  <td className="num">{st?.views ?? 0}</td><td className="num">{st?.clicks ?? 0}</td>
                  <td className="left acts">
                    <button type="button" className="link-btn" onClick={() => setDraft(promo)}>Edit</button>{" "}
                    <button type="button" className="link-btn" onClick={() => void toggle(promo)}>{promo.enabled ? "Pause" : "Resume"}</button>{" "}
                    <button type="button" className="link-btn" onClick={() => void remove(promo)}>Delete</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table></div>
      )}
    </div>
  );
}

// ------------------------------------------------------------------ ads
const SLOT_INFO = {
  header: ["Top of page", "Under the header on the home, stats and fantasy pages."],
  inline: ["Between content", "Between the standings and the stat table, and above the fantasy review."],
  footer: ["Bottom of page", "Above the footer on every content page."],
} as const;

export function AdsTab({ settings, onSaved }: TabProps) {
  const [ads, setAds] = useState(settings.ads);
  const { busy, notice, save } = useSave(onSaved);
  const slotNames = ["header", "inline", "footer"] as const;
  return (
    <div className="atab">
      <h2>Ads</h2>
      <p className="hint-plain">
        Ads need an approved ad account, such as Google AdSense. Ads load only after a visitor accepts, never on admin, privacy or account pages, and never
        for Plus members. Visitors in some regions need a certified consent tool on top of this banner, so check your ad network's rules.
      </p>
      <form className="aform" onSubmit={(e: FormEvent) => { e.preventDefault(); void save({ ads }); }}>
        <div className="arow">
          <Field label="Ad network">
            <select value={ads.provider} onChange={(e) => setAds({ ...ads, provider: e.target.value as "none" | "adsense" })}>
              <option value="none">None (custom code only)</option>
              <option value="adsense">Google AdSense</option>
            </select>
          </Field>
          <Field label="AdSense publisher ID" hint="Looks like ca-pub-1234567890123456."><input value={ads.publisherId} onChange={(e) => setAds({ ...ads, publisherId: e.target.value })} placeholder="ca-pub-" /></Field>
        </div>
        <Check label="Ask visitors first" checked={ads.requireConsent} onChange={(value) => setAds({ ...ads, requireConsent: value })} hint="Shows a banner, and ads stay off until the visitor accepts." />
        <Field label="ads.txt" hint="Served at /ads.txt. AdSense shows you the exact line to paste here."><textarea rows={3} value={ads.adsTxt} onChange={(e) => setAds({ ...ads, adsTxt: e.target.value })} spellCheck={false} /></Field>
        {slotNames.map((name) => {
          const slot = ads.slots[name];
          const update = (change: Partial<typeof slot>) => setAds({ ...ads, slots: { ...ads.slots, [name]: { ...slot, ...change } } });
          return (
            <fieldset key={name}>
              <legend>{SLOT_INFO[name][0]}</legend>
              <p className="hint-plain">{SLOT_INFO[name][1]}</p>
              <Check label="Show this slot" checked={slot.enabled} onChange={(value) => update({ enabled: value })} />
              <Field label="Slot type">
                <select value={slot.type} onChange={(e) => update({ type: e.target.value as "adsense" | "custom" })}>
                  <option value="adsense">AdSense ad unit</option>
                  <option value="custom">Custom code (other networks, sponsor banners)</option>
                </select>
              </Field>
              {slot.type === "adsense" ? (
                <Field label="AdSense ad slot ID" hint="Digits only, from your ad unit."><input value={slot.adsenseSlot} onChange={(e) => update({ adsenseSlot: e.target.value })} inputMode="numeric" /></Field>
              ) : (
                <Field label="Ad code" hint="Runs in a sandboxed frame that cannot reach this site's data."><textarea rows={4} value={slot.customHtml} onChange={(e) => update({ customHtml: e.target.value })} spellCheck={false} /></Field>
              )}
            </fieldset>
          );
        })}
        <div className="aactions"><button type="submit" className="primary" disabled={busy}>{busy ? "Saving…" : "Save ad settings"}</button></div>
        {notice ? <Notice kind={notice.kind}>{notice.text}</Notice> : null}
      </form>
    </div>
  );
}

// ------------------------------------------------------------------ revenue: support, Plus, codes
export function RevenueTab({ settings, onSaved }: TabProps) {
  const [support, setSupport] = useState(settings.support);
  const [plus, setPlus] = useState(settings.plus);
  const supportSave = useSave(onSaved);
  const plusSave = useSave(onSaved);
  const [codes, setCodes] = useState<AdminCode[]>([]);
  const [fresh, setFresh] = useState<AdminCode[]>([]);
  const [form, setForm] = useState({ count: 1, maxUses: 1, expiresInDays: 0, label: "" });
  const [error, setError] = useState("");

  const load = useCallback(async () => setCodes((await api<{ codes: AdminCode[] }>("GET", "/api/admin/codes")).codes), []);
  useEffect(() => {
    void load().catch((e: Error) => setError(e.message));
  }, [load]);

  async function make(event: FormEvent) {
    event.preventDefault();
    try {
      const res = await api<{ codes: AdminCode[] }>("POST", "/api/admin/codes", form);
      setFresh(res.codes);
      setError("");
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not make codes.");
    }
  }

  return (
    <div className="atab">
      <h2>Support button</h2>
      <p className="hint-plain">A link to wherever people can tip or back the site, such as Buy Me a Coffee, Ko-fi, GitHub Sponsors or a Stripe Payment Link.</p>
      <form className="aform" onSubmit={(e: FormEvent) => { e.preventDefault(); void supportSave.save({ support }); }}>
        <Check label="Show the support link in the footer" checked={support.enabled} onChange={(value) => setSupport({ ...support, enabled: value })} />
        <div className="arow">
          <Field label="Label"><input value={support.label} maxLength={40} onChange={(e) => setSupport({ ...support, label: e.target.value })} /></Field>
          <Field label="Link"><input type="url" value={support.url} onChange={(e) => setSupport({ ...support, url: e.target.value })} placeholder="https://" /></Field>
        </div>
        <div className="aactions"><button type="submit" className="primary" disabled={supportSave.busy}>Save support link</button></div>
        {supportSave.notice ? <Notice kind={supportSave.notice.kind}>{supportSave.notice.text}</Notice> : null}
      </form>

      <h2>Plus (ad-free)</h2>
      <p className="hint-plain">
        Sell ad-free access without writing payment code: put a Stripe Payment Link (or similar) in the buy link, and when someone pays, generate an access code
        below and send it to them. A code removes ads and sponsored cards on their browser.
      </p>
      <form className="aform" onSubmit={(e: FormEvent) => { e.preventDefault(); void plusSave.save({ plus }); }}>
        <Check label="Turn Plus on" checked={plus.enabled} onChange={(value) => setPlus({ ...plus, enabled: value })} />
        <div className="arow">
          <Field label="Plan name"><input value={plus.name} maxLength={40} onChange={(e) => setPlus({ ...plus, name: e.target.value })} /></Field>
          <Field label="Price shown"><input value={plus.price} maxLength={40} onChange={(e) => setPlus({ ...plus, price: e.target.value })} placeholder="$3 a month" /></Field>
        </div>
        <Field label="Pitch"><textarea rows={2} maxLength={300} value={plus.pitch} onChange={(e) => setPlus({ ...plus, pitch: e.target.value })} /></Field>
        <div className="arow">
          <Field label="Buy link"><input type="url" value={plus.buyUrl} onChange={(e) => setPlus({ ...plus, buyUrl: e.target.value })} placeholder="https://" /></Field>
          <Field label="Access lasts (days)"><input type="number" min={1} max={3650} value={plus.durationDays} onChange={(e) => setPlus({ ...plus, durationDays: Number(e.target.value) })} /></Field>
        </div>
        <div className="aactions"><button type="submit" className="primary" disabled={plusSave.busy}>Save Plus settings</button></div>
        {plusSave.notice ? <Notice kind={plusSave.notice.kind}>{plusSave.notice.text}</Notice> : null}
      </form>

      <h3>Access codes</h3>
      <form className="aform inline" onSubmit={(e) => void make(e)}>
        <Field label="How many"><input type="number" min={1} max={50} value={form.count} onChange={(e) => setForm({ ...form, count: Number(e.target.value) })} /></Field>
        <Field label="Uses each"><input type="number" min={0} value={form.maxUses} onChange={(e) => setForm({ ...form, maxUses: Number(e.target.value) })} /></Field>
        <Field label="Code expires after (days, 0 = never)"><input type="number" min={0} value={form.expiresInDays} onChange={(e) => setForm({ ...form, expiresInDays: Number(e.target.value) })} /></Field>
        <Field label="Label (who it is for)"><input value={form.label} maxLength={60} onChange={(e) => setForm({ ...form, label: e.target.value })} /></Field>
        <button type="submit" className="primary">Make codes</button>
      </form>
      {error ? <Notice kind="bad">{error}</Notice> : null}
      {fresh.length > 0 ? (
        <Notice kind="info">New codes (copy them now): <code className="codes">{fresh.map((c) => c.code).join("   ")}</code></Notice>
      ) : null}
      {codes.length === 0 ? <p className="hint-plain">No codes yet.</p> : (
        <div className="table-wrap" tabIndex={0} role="region" aria-label="Access codes"><table className="status-table small">
          <thead><tr><th className="left">Code</th><th className="left">Label</th><th>Used</th><th className="left">Status</th><th className="left"><span className="sr">Actions</span></th></tr></thead>
          <tbody>
            {[...codes].reverse().map((c) => {
              const dead = c.revoked || (c.expiresAt > 0 && c.expiresAt < Date.now()) || (c.maxUses > 0 && c.uses >= c.maxUses);
              return (
                <tr key={c.id}>
                  <th scope="row" className="plain"><code>{c.code}</code></th><td className="left">{c.label || "—"}</td>
                  <td className="num">{c.uses}{c.maxUses ? ` / ${c.maxUses}` : ""}</td>
                  <td className={`left result ${dead ? "fail" : "ok"}`}>{c.revoked ? "Revoked" : dead ? "Finished" : "Active"}</td>
                  <td className="left">{!c.revoked ? <button type="button" className="link-btn" onClick={() => void api("DELETE", `/api/admin/codes/${c.id}`).then(load)}>Revoke</button> : null}</td>
                </tr>
              );
            })}
          </tbody>
        </table></div>
      )}
    </div>
  );
}

// ------------------------------------------------------------------ subscribers
export function SubscribersTab() {
  const [list, setList] = useState<Subscriber[] | null>(null);
  const [error, setError] = useState("");
  const load = useCallback(async () => setList((await api<{ subscribers: Subscriber[] }>("GET", "/api/admin/subscribers")).subscribers), []);
  useEffect(() => {
    void load().catch((e: Error) => setError(e.message));
  }, [load]);
  return (
    <div className="atab">
      <div className="status-head">
        <h2>Subscribers{list ? ` (${list.length})` : ""}</h2>
        <a className="ghost-link" href="/api/admin/subscribers.csv" download>Download CSV</a>
      </div>
      <p className="hint-plain">People who signed up in the footer form. The site stores the address and the date; sending email needs a mailing service, and you can import the CSV there.</p>
      {error ? <Notice kind="bad">{error}</Notice> : null}
      {list && list.length === 0 ? <p className="hint-plain">No sign-ups yet.</p> : null}
      {list && list.length > 0 ? (
        <div className="table-wrap" tabIndex={0} role="region" aria-label="Subscribers list"><table className="status-table small">
          <thead><tr><th className="left">Email</th><th className="left">Signed up</th><th className="left">From</th><th className="left"><span className="sr">Actions</span></th></tr></thead>
          <tbody>
            {list.map((s) => (
              <tr key={s.id}>
                <th scope="row" className="plain">{s.email}</th><td className="left nowrap">{when(s.createdAt)}</td><td className="left">{s.source}</td>
                <td className="left"><button type="button" className="link-btn" onClick={() => { if (window.confirm(`Remove ${s.email}?`)) void api("DELETE", `/api/admin/subscribers/${s.id}`).then(load); }}>Remove</button></td>
              </tr>
            ))}
          </tbody>
        </table></div>
      ) : null}
    </div>
  );
}

// ------------------------------------------------------------------ site
export function SiteTab({ settings, onSaved }: TabProps) {
  const [name, setName] = useState(settings.siteName);
  const [note, setNote] = useState(settings.announcement);
  const [features, setFeatures] = useState(settings.features);
  const [legal, setLegal] = useState(settings.legal);
  const general = useSave(onSaved);
  const feeds = useSave(onSaved);
  const legalSave = useSave(onSaved);
  const leagueIds = Object.keys(FEEDS);
  return (
    <div className="atab">
      <h2>Site</h2>
      <form className="aform" onSubmit={(e: FormEvent) => { e.preventDefault(); void general.save({ siteName: name, announcement: note, features: { ...settings.features, subscribe: features.subscribe } }); }}>
        <Field label="Site name"><input value={name} maxLength={40} onChange={(e) => setName(e.target.value)} /></Field>
        <Check label="Show an announcement bar" checked={note.enabled} onChange={(value) => setNote({ ...note, enabled: value })} />
        <div className="arow">
          <Field label="Announcement text"><input value={note.text} maxLength={200} onChange={(e) => setNote({ ...note, text: e.target.value })} /></Field>
          <Field label="Link (optional)"><input type="url" value={note.url} onChange={(e) => setNote({ ...note, url: e.target.value })} placeholder="https://" /></Field>
        </div>
        <Check label="Show the email sign-up form" checked={features.subscribe} onChange={(value) => setFeatures({ ...features, subscribe: value })} />
        <div className="aactions"><button type="submit" className="primary" disabled={general.busy}>Save</button></div>
        {general.notice ? <Notice kind={general.notice.kind}>{general.notice.text}</Notice> : null}
      </form>

      <h3>Live data</h3>
      <p className="hint-plain">
        Live stats come from ESPN's public feeds. Those feeds are unofficial and ESPN's terms limit commercial use, so before this site earns money, switch to a
        licensed data provider or turn these off. A league that is off shows the sample season.
      </p>
      <form className="aform" onSubmit={(e: FormEvent) => { e.preventDefault(); void feeds.save({ features }); }}>
        <div className="checkgrid">
          {leagueIds.map((id) => (
            <Check key={id} label={id.toUpperCase()} checked={features.liveLeagues[id] !== false} onChange={(value) => setFeatures({ ...features, liveLeagues: { ...features.liveLeagues, [id]: value } })} />
          ))}
        </div>
        <div className="aactions"><button type="submit" className="primary" disabled={feeds.busy}>Save live data</button></div>
        {feeds.notice ? <Notice kind={feeds.notice.kind}>{feeds.notice.text}</Notice> : null}
      </form>

      <h3>Privacy and disclosure</h3>
      <form className="aform" onSubmit={(e: FormEvent) => { e.preventDefault(); void legalSave.save({ legal }); }}>
        <Field label="Contact email (shown on the privacy page)"><input type="email" value={legal.contactEmail} onChange={(e) => setLegal({ ...legal, contactEmail: e.target.value })} /></Field>
        <Field label="Affiliate disclosure" hint="Shown under any page that has an affiliate card."><textarea rows={2} maxLength={500} value={legal.affiliateNote} onChange={(e) => setLegal({ ...legal, affiliateNote: e.target.value })} /></Field>
        <Field label="Privacy page text" hint="Starts as a template. Edit it to match what you really do; it is not legal advice."><textarea rows={12} maxLength={20000} value={legal.privacyText} onChange={(e) => setLegal({ ...legal, privacyText: e.target.value })} /></Field>
        <div className="aactions"><button type="submit" className="primary" disabled={legalSave.busy}>Save privacy text</button></div>
        {legalSave.notice ? <Notice kind={legalSave.notice.kind}>{legalSave.notice.text}</Notice> : null}
      </form>

      <h3>Backup</h3>
      <p className="hint-plain">Settings, promotions, codes, subscribers and counts as one file. It never contains your password or sign-in secrets.</p>
      <a className="ghost-link" href="/api/admin/export" download>Download backup</a>
    </div>
  );
}

// ------------------------------------------------------------------ security
const PERMISSION_LABELS: Record<string, string> = {
  "site:manage": "manage the site",
  "monetization:manage": "manage ads, promotions and Plus",
  "subscribers:manage": "manage subscribers",
  "codes:manage": "manage access codes",
  "analytics:view": "view analytics",
  "security:manage": "manage security",
  "data:export": "export data",
};

type SessionRow = { id: string; createdAt: number; lastSeen: number; ip: string; ua: string; current: boolean };
type AuditRow = { at: number; action: string; detail: string };

export function SecurityTab({ email, totpEnabled, permissions, refresh, onSignedOut }: { email: string; totpEnabled: boolean; permissions: string[]; refresh: () => void; onSignedOut: () => void }) {
  const [sessions, setSessions] = useState<SessionRow[]>([]);
  const [audit, setAudit] = useState<AuditRow[]>([]);
  const [pw, setPw] = useState({ current: "", next: "" });
  const [pwNote, setPwNote] = useState<{ kind: "ok" | "bad"; text: string } | null>(null);
  const [setup, setSetup] = useState<{ secret: string; uri: string } | null>(null);
  const [code, setCode] = useState("");
  const [off, setOff] = useState({ password: "", code: "" });
  const [tfaNote, setTfaNote] = useState<{ kind: "ok" | "bad"; text: string } | null>(null);

  const load = useCallback(async () => {
    const [s, a] = await Promise.all([api<{ sessions: SessionRow[] }>("GET", "/api/admin/sessions"), api<{ audit: AuditRow[] }>("GET", "/api/admin/audit")]);
    setSessions(s.sessions);
    setAudit(a.audit);
  }, []);
  useEffect(() => {
    void load().catch(() => undefined);
  }, [load]);

  const run = async (fn: () => Promise<void>, set: (n: { kind: "ok" | "bad"; text: string }) => void, done: string) => {
    try {
      await fn();
      set({ kind: "ok", text: done });
      await load();
    } catch (e) {
      set({ kind: "bad", text: e instanceof Error ? e.message : "That did not work." });
    }
  };

  return (
    <div className="atab">
      <h2>Security</h2>
      <p className="hint-plain">Signed in as <strong>{email}</strong>. This is the only account, and it holds every permission: {permissions.map((p) => PERMISSION_LABELS[p] ?? p).join(", ")}.</p>

      <h3>Password</h3>
      <form className="aform inline" onSubmit={(e) => { e.preventDefault(); void run(async () => { await api("POST", "/api/admin/password", pw); setPw({ current: "", next: "" }); }, setPwNote, "Password changed. Other sessions were signed out."); }}>
        <Field label="Current password"><input type="password" autoComplete="current-password" value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} required /></Field>
        <Field label="New password (12 characters or more)"><input type="password" autoComplete="new-password" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} required /></Field>
        <button type="submit" className="primary">Change password</button>
      </form>
      {pwNote ? <Notice kind={pwNote.kind}>{pwNote.text}</Notice> : null}

      <h3>Two-step sign-in</h3>
      {totpEnabled ? (
        <form className="aform inline" onSubmit={(e) => { e.preventDefault(); void run(async () => { await api("POST", "/api/admin/2fa/disable", off); setOff({ password: "", code: "" }); refresh(); }, setTfaNote, "Two-step sign-in is off."); }}>
          <p className="hint-plain">On. Signing in needs a code from your authenticator app.</p>
          <Field label="Password"><input type="password" value={off.password} onChange={(e) => setOff({ ...off, password: e.target.value })} required /></Field>
          <Field label="Current code"><input inputMode="numeric" value={off.code} onChange={(e) => setOff({ ...off, code: e.target.value })} required /></Field>
          <button type="submit" className="ghost">Turn off</button>
        </form>
      ) : setup ? (
        <form className="aform" onSubmit={(e) => { e.preventDefault(); void run(async () => { await api("POST", "/api/admin/2fa/enable", { code }); setSetup(null); setCode(""); refresh(); }, setTfaNote, "Two-step sign-in is on."); }}>
          <p className="hint-plain">Add this key to an authenticator app (Google Authenticator, 1Password, Authy), then enter the 6-digit code it shows.</p>
          <p><code className="codes">{setup.secret}</code></p>
          <p className="hint-plain"><a href={setup.uri}>Open in an authenticator app</a> (works on phones).</p>
          <Field label="6-digit code"><input inputMode="numeric" value={code} onChange={(e) => setCode(e.target.value)} required /></Field>
          <div className="aactions"><button type="submit" className="primary">Turn on</button><button type="button" className="ghost" onClick={() => setSetup(null)}>Cancel</button></div>
        </form>
      ) : (
        <div>
          <p className="hint-plain">Strongly recommended for an account that controls money features.</p>
          <button type="button" className="ghost" onClick={() => void run(async () => setSetup(await api<{ secret: string; uri: string }>("POST", "/api/admin/2fa/begin")), setTfaNote, "Key created.")}>Set up two-step sign-in</button>
        </div>
      )}
      {tfaNote ? <Notice kind={tfaNote.kind}>{tfaNote.text}</Notice> : null}

      <h3>Sessions</h3>
      <div className="table-wrap" tabIndex={0} role="region" aria-label="Signed-in sessions"><table className="status-table small">
        <thead><tr><th className="left">Device</th><th className="left">Started</th><th className="left">Last active</th><th className="left">Address</th></tr></thead>
        <tbody>
          {sessions.map((s) => (<tr key={s.id}><th scope="row" className="plain">{s.current ? "This browser" : s.ua.slice(0, 60) || "Unknown"}</th><td className="left nowrap">{when(s.createdAt)}</td><td className="left nowrap">{when(s.lastSeen)}</td><td className="left">{s.ip}</td></tr>))}
        </tbody>
      </table></div>
      <div className="aactions">
        <button type="button" className="ghost" onClick={() => void api("POST", "/api/admin/sessions/revoke-others").then(load)}>Sign out everywhere else</button>
        <button type="button" className="ghost" onClick={() => void api("POST", "/api/admin/logout").then(onSignedOut)}>Sign out</button>
      </div>

      <h3>Recent activity</h3>
      <div className="table-wrap" tabIndex={0} role="region" aria-label="Recent activity"><table className="status-table small">
        <tbody>
          {audit.slice(0, 25).map((a, i) => (<tr key={`${a.at}-${i}`}><td className="left nowrap">{when(a.at)}</td><th scope="row" className="plain">{a.action.replace(/_/g, " ")}</th><td className="left">{a.detail}</td></tr>))}
        </tbody>
      </table></div>
    </div>
  );
}
