export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

// The custom header and JSON body are what the server uses to tell this app apart from a forged cross-site request.
export async function api<T>(method: "GET" | "POST" | "PUT" | "DELETE", path: string, body?: unknown): Promise<T> {
  const res = await fetch(path, {
    method,
    credentials: "same-origin",
    headers: method === "GET" ? { "x-statline": "1" } : { "content-type": "application/json", "x-statline": "1" },
    body: method === "GET" ? undefined : JSON.stringify(body ?? {}),
  });
  let json: unknown = null;
  try {
    json = await res.json();
  } catch {
    // not JSON
  }
  if (!res.ok) throw new ApiError((json as { error?: string } | null)?.error || `Request failed (${res.status})`, res.status);
  return json as T;
}

export type AdminSettings = {
  siteName: string;
  announcement: { enabled: boolean; text: string; url: string };
  features: { subscribe: boolean; liveLeagues: Record<string, boolean> };
  ads: {
    provider: "none" | "adsense";
    publisherId: string;
    requireConsent: boolean;
    adsTxt: string;
    slots: Record<"header" | "inline" | "footer", { enabled: boolean; type: "adsense" | "custom"; adsenseSlot: string; customHtml: string }>;
  };
  support: { enabled: boolean; label: string; url: string };
  plus: { enabled: boolean; name: string; price: string; pitch: string; buyUrl: string; durationDays: number };
  legal: { contactEmail: string; privacyText: string; affiliateNote: string };
};

export type AdminPromo = {
  id: string;
  title: string;
  body: string;
  cta: string;
  url: string;
  kind: "affiliate" | "sponsor" | "house";
  placements: string[];
  sports: string[];
  enabled: boolean;
  startsAt: string;
  endsAt: string;
  weight: number;
};

export type AdminCode = { id: string; code: string; label: string; createdAt: number; expiresAt: number; maxUses: number; uses: number; revoked: boolean };
export type Subscriber = { id: string; email: string; createdAt: number; source: string };
export type Overview = {
  totals: { views: number; promoViews: number; promoClicks: number; subs: number; redeems: number };
  series: { date: string; views: number; clicks: number; subs: number }[];
  topPages: { page: string; views: number }[];
  promos: { id: string; title: string; views: number; clicks: number; ctr: number }[];
  counts: { subscribers: number; activePromos: number; activeCodes: number };
};
