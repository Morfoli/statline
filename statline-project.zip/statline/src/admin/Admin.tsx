import { useCallback, useEffect, useState, type FormEvent } from "react";
import { useSite } from "../site/SiteProvider";
import { api, type AdminSettings } from "./api";
import { AdsTab, OverviewTab, PromotionsTab, RevenueTab, SecurityTab, SiteTab, SubscribersTab } from "./tabs";
import { Field, Notice } from "./ui";

type Status = { needsSetup: boolean; loggedIn: boolean; email?: string; totpEnabled?: boolean; permissions?: string[] };

const TABS = [
  ["overview", "Overview"],
  ["promotions", "Promotions"],
  ["ads", "Ads"],
  ["revenue", "Plus and support"],
  ["subscribers", "Subscribers"],
  ["site", "Site"],
  ["security", "Security"],
] as const;
type TabId = (typeof TABS)[number][0];

function useNoIndex() {
  useEffect(() => {
    const meta = document.createElement("meta");
    meta.name = "robots";
    meta.content = "noindex, nofollow";
    document.head.appendChild(meta);
    document.title = "Admin · Statline";
    return () => meta.remove();
  }, []);
}

export function Admin() {
  useNoIndex();
  const { config, loaded } = useSite();
  const [status, setStatus] = useState<Status | null>(null);
  const [error, setError] = useState("");

  const refresh = useCallback(() => {
    api<Status>("GET", "/api/admin/status")
      .then(setStatus)
      .catch((e: Error) => setError(e.message));
  }, []);
  useEffect(() => {
    if (loaded && config.server) refresh();
  }, [loaded, config.server, refresh]);

  if (!loaded) return <main className="wrap status"><p className="hint-plain">Loading…</p></main>;
  if (!config.server) {
    return (
      <main className="wrap status">
        <p className="kicker">Admin</p>
        <h1>The admin needs the Statline server.</h1>
        <p className="lede">
          This copy is running as a plain file or on a static host, which cannot keep a private account. Run the server (<code>npm start</code>) or deploy it, then
          open this page from there. The README walks through it.
        </p>
      </main>
    );
  }
  if (error) return <main className="wrap status"><Notice kind="bad">{error}</Notice></main>;
  if (!status) return <main className="wrap status"><p className="hint-plain">Loading…</p></main>;
  if (status.needsSetup) return <Gate mode="setup" onDone={refresh} />;
  if (!status.loggedIn) return <Gate mode="login" onDone={refresh} />;
  return <Dashboard status={status} refresh={refresh} />;
}

function Gate({ mode, onDone }: { mode: "setup" | "login"; onDone: () => void }) {
  const [form, setForm] = useState({ token: "", email: "", password: "", code: "" });
  const [needsCode, setNeedsCode] = useState(false);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setNote("");
    try {
      const res = await api<{ ok: boolean; needsCode?: boolean }>("POST", mode === "setup" ? "/api/admin/setup" : "/api/admin/login", form);
      if (res.needsCode) setNeedsCode(true);
      else onDone();
    } catch (error) {
      setNote(error instanceof Error ? error.message : "That did not work.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="wrap status gate">
      <p className="kicker">Admin</p>
      <h1>{mode === "setup" ? "Create the owner account." : "Sign in."}</h1>
      {mode === "setup" ? (
        <p className="lede">
          This is the only account and it holds every admin permission. The setup token was printed in the console where the server started, so only someone who can
          see that console can claim the site.
        </p>
      ) : null}
      <form className="aform narrow" onSubmit={(e) => void submit(e)}>
        {mode === "setup" ? <Field label="Setup token"><input value={form.token} onChange={(e) => setForm({ ...form, token: e.target.value })} autoComplete="off" required /></Field> : null}
        <Field label="Email"><input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} autoComplete="username" required disabled={needsCode} /></Field>
        <Field label="Password" hint={mode === "setup" ? "At least 12 characters. A passphrase of a few words works well." : undefined}>
          <input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} autoComplete={mode === "setup" ? "new-password" : "current-password"} required disabled={needsCode} />
        </Field>
        {needsCode ? <Field label="Code from your authenticator app"><input inputMode="numeric" autoFocus value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} autoComplete="one-time-code" required /></Field> : null}
        <div className="aactions"><button type="submit" className="primary" disabled={busy}>{busy ? "One moment…" : mode === "setup" ? "Create account" : needsCode ? "Verify" : "Sign in"}</button></div>
        {note ? <Notice kind="bad">{note}</Notice> : null}
      </form>
    </main>
  );
}

function Dashboard({ status, refresh }: { status: Status; refresh: () => void }) {
  const [tab, setTab] = useState<TabId>("overview");
  const [settings, setSettings] = useState<AdminSettings | null>(null);
  const [error, setError] = useState("");
  const { reload } = useSite();

  useEffect(() => {
    api<{ settings: AdminSettings }>("GET", "/api/admin/settings")
      .then((res) => setSettings(res.settings))
      .catch((e: Error) => setError(e.message));
  }, []);

  // Saving settings also refreshes what visitors see, so a change is visible straight away.
  const onSaved = useCallback(
    (next: AdminSettings) => {
      setSettings(next);
      reload();
    },
    [reload],
  );

  return (
    <main className="wrap status admin">
      <p className="kicker">Admin</p>
      <h1>Run the site.</h1>
      <div className="views" role="tablist" aria-label="Admin sections">
        {TABS.map(([id, label]) => (
          <button key={id} type="button" role="tab" aria-selected={tab === id} className={tab === id ? "on" : ""} onClick={() => setTab(id)}>
            {label}
          </button>
        ))}
      </div>
      {error ? <Notice kind="bad">{error}</Notice> : null}
      {tab === "overview" ? <OverviewTab settings={settings} totpEnabled={Boolean(status.totpEnabled)} go={setTab} /> : null}
      {tab === "promotions" ? <PromotionsTab /> : null}
      {tab === "subscribers" ? <SubscribersTab /> : null}
      {settings && tab === "ads" ? <AdsTab settings={settings} onSaved={onSaved} /> : null}
      {settings && tab === "revenue" ? <RevenueTab settings={settings} onSaved={onSaved} /> : null}
      {settings && tab === "site" ? <SiteTab settings={settings} onSaved={onSaved} /> : null}
      {tab === "security" ? (
        <SecurityTab email={status.email ?? ""} totpEnabled={Boolean(status.totpEnabled)} permissions={status.permissions ?? []} refresh={refresh} onSignedOut={refresh} />
      ) : null}
    </main>
  );
}
