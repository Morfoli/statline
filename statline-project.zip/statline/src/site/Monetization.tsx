import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { Link, useLocation } from "react-router-dom";
import { track, useSite, type PromoItem, type SlotName } from "./SiteProvider";

const CONSENT_KEY = "statline-consent";
type Consent = "granted" | "denied" | null;

function readConsent(): Consent {
  try {
    const value = localStorage.getItem(CONSENT_KEY);
    return value === "granted" || value === "denied" ? value : null;
  } catch {
    return null;
  }
}

export function useConsent(): [Consent, (choice: "granted" | "denied") => void] {
  const [consent, setConsent] = useState<Consent>(readConsent);
  const choose = (choice: "granted" | "denied") => {
    try {
      localStorage.setItem(CONSENT_KEY, choice);
    } catch {
      // the choice still applies for this visit
    }
    setConsent(choice);
    window.dispatchEvent(new Event("statline-consent"));
  };
  useEffect(() => {
    const sync = () => setConsent(readConsent());
    window.addEventListener("statline-consent", sync);
    return () => window.removeEventListener("statline-consent", sync);
  }, []);
  return [consent, choose];
}

// Pages that carry real content. Ads never appear on admin, status, legal or account pages.
function adsAllowed(pathname: string): boolean {
  return !/^\/(admin|status|plus|privacy)/.test(pathname);
}

export function AnnouncementBar() {
  const { config } = useSite();
  const [hidden, setHidden] = useState(() => {
    try {
      return sessionStorage.getItem("statline-announce") === config.announcement.text;
    } catch {
      return false;
    }
  });
  const note = config.announcement;
  if (!note.enabled || !note.text || hidden) return null;
  return (
    <div className="announce" role="region" aria-label="Announcement">
      <p>
        {note.url ? (
          <a href={note.url} target="_blank" rel="noopener noreferrer">
            {note.text}
          </a>
        ) : (
          note.text
        )}
      </p>
      <button
        type="button"
        aria-label="Dismiss announcement"
        onClick={() => {
          try {
            sessionStorage.setItem("statline-announce", note.text);
          } catch {
            // ignore
          }
          setHidden(true);
        }}
      >
        ×
      </button>
    </div>
  );
}

export function ConsentBanner() {
  const { config } = useSite();
  const [consent, choose] = useConsent();
  const { pathname } = useLocation();
  if (config.ads.provider === "none" || !config.ads.requireConsent || consent !== null || /^\/admin/.test(pathname)) return null;
  return (
    <div className="consent" role="dialog" aria-label="Advertising choice">
      <p>
        This site shows ads. With your OK, our ad partner may use cookies to choose them.{" "}
        <Link to="/privacy">Privacy</Link>
      </p>
      <div>
        <button type="button" className="ghost" onClick={() => choose("denied")}>
          No thanks
        </button>
        <button type="button" className="primary" onClick={() => choose("granted")}>
          Accept
        </button>
      </div>
    </div>
  );
}

declare global {
  interface Window {
    adsbygoogle?: unknown[];
  }
}

function useAdsenseScript(publisherId: string, enabled: boolean) {
  useEffect(() => {
    if (!enabled || !/^ca-pub-\d{10,20}$/.test(publisherId)) return;
    if (document.querySelector("script[data-statline-adsense]")) return;
    const script = document.createElement("script");
    script.async = true;
    script.crossOrigin = "anonymous";
    script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${publisherId}`;
    script.dataset.statlineAdsense = "1";
    document.head.appendChild(script);
  }, [publisherId, enabled]);
}

function AdsenseUnit({ publisherId, slot }: { publisherId: string; slot: string }) {
  const done = useRef(false);
  useEffect(() => {
    if (done.current) return;
    done.current = true;
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch {
      // the ad script may be blocked; the space simply stays empty
    }
  }, []);
  return (
    <ins
      className="adsbygoogle"
      style={{ display: "block" }}
      data-ad-client={publisherId}
      data-ad-slot={slot}
      data-ad-format="auto"
      data-full-width-responsive="true"
    />
  );
}

// Owner-pasted ad code runs inside a sandboxed frame with no access to this site's storage or cookies.
function CustomUnit({ html }: { html: string }) {
  const doc = `<!doctype html><meta name="viewport" content="width=device-width"><style>html,body{margin:0;background:transparent}</style>${html}`;
  return (
    <iframe
      title="Advertisement"
      className="ad-frame"
      sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox"
      srcDoc={doc}
      loading="lazy"
    />
  );
}

export function AdSlot({ name }: { name: SlotName }) {
  const { config } = useSite();
  const [consent] = useConsent();
  const { pathname } = useLocation();
  const slot = config.ads.slots[name];
  const allowedHere = adsAllowed(pathname);
  const consentOk = !config.ads.requireConsent || consent === "granted";
  const adsenseReady = config.ads.provider === "adsense" && slot.type === "adsense" && Boolean(slot.adsenseSlot) && consentOk;
  const customReady = slot.type === "custom" && Boolean(slot.customHtml) && consentOk;
  const show = config.server && !config.entitled && slot.enabled && allowedHere && (adsenseReady || customReady);

  // The ad script only loads on a page that actually shows one of these ads, and only after consent.
  useAdsenseScript(config.ads.publisherId, show && slot.type === "adsense");
  const counted = useRef(false);
  useEffect(() => {
    if (show && !counted.current) {
      counted.current = true;
      track(config, "ad", name);
    }
  }, [show, config, name]);

  if (!show) return null;
  return (
    <aside className={`ad ad-${name}`} aria-label="Advertisement">
      <span className="ad-tag">Advertisement</span>
      {slot.type === "adsense" ? <AdsenseUnit publisherId={config.ads.publisherId} slot={slot.adsenseSlot} /> : <CustomUnit html={slot.customHtml} />}
    </aside>
  );
}

function pickPromos(promos: PromoItem[], placement: string, sportId: string | undefined, limit: number): PromoItem[] {
  const pool = promos.filter((p) => p.placements.includes(placement) && (p.sports.length === 0 || (sportId !== undefined && p.sports.includes(sportId))));
  const picked: PromoItem[] = [];
  const left = [...pool];
  while (picked.length < limit && left.length > 0) {
    const total = left.reduce((sum, p) => sum + p.weight, 0);
    let roll = Math.random() * total;
    let index = left.findIndex((p) => (roll -= p.weight) < 0);
    if (index < 0) index = left.length - 1;
    picked.push(left.splice(index, 1)[0]);
  }
  return picked;
}

const KIND_LABEL: Record<PromoItem["kind"], string> = { affiliate: "Affiliate link", sponsor: "Sponsored", house: "From Statline" };

export function PromoSlot({ placement, sportId, limit = 2 }: { placement: "home" | "desk" | "lab"; sportId?: string; limit?: number }) {
  const { config } = useSite();
  const promos = useMemo(
    () => (config.server && !config.entitled ? pickPromos(config.promos, placement, sportId, limit) : []),
    [config.server, config.entitled, config.promos, placement, sportId, limit],
  );
  const reported = useRef(new Set<string>());
  useEffect(() => {
    for (const promo of promos) {
      if (reported.current.has(promo.id)) continue;
      reported.current.add(promo.id);
      track(config, "promo", promo.id);
    }
  }, [promos, config]);

  if (promos.length === 0) return null;
  const hasAffiliate = promos.some((p) => p.kind === "affiliate");
  return (
    <section className="promos" aria-label="Offers">
      <ul>
        {promos.map((promo) => (
          <li key={promo.id}>
            <span className="promo-kind">{KIND_LABEL[promo.kind]}</span>
            <h3>{promo.title}</h3>
            {promo.body ? <p>{promo.body}</p> : null}
            <a href={`/go/${promo.id}`} target="_blank" rel="sponsored noopener noreferrer" className="promo-cta">
              {promo.cta}
            </a>
          </li>
        ))}
      </ul>
      {hasAffiliate && config.legal.affiliateNote ? <p className="promo-note">{config.legal.affiliateNote}</p> : null}
    </section>
  );
}

export function SubscribeBox({ source }: { source: string }) {
  const { config } = useSite();
  const [email, setEmail] = useState("");
  const [trap, setTrap] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  if (!config.server || !config.features.subscribe) return null;

  async function submit(event: FormEvent) {
    event.preventDefault();
    setState("sending");
    try {
      const res = await fetch("/api/subscribe", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ email, source, website: trap }),
      });
      const json = (await res.json()) as { error?: string };
      if (!res.ok) throw new Error(json.error || "That did not work.");
      setState("done");
      setMessage("You are on the list.");
      setEmail("");
    } catch (error) {
      setState("error");
      setMessage(error instanceof Error ? error.message : "That did not work.");
    }
  }

  return (
    <form className="subscribe" onSubmit={(event) => void submit(event)}>
      <label>
        <span>Get updates by email</span>
        <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email" />
      </label>
      <input className="trap" tabIndex={-1} autoComplete="off" aria-hidden="true" value={trap} onChange={(e) => setTrap(e.target.value)} name="website" />
      <button type="submit" className="primary" disabled={state === "sending"}>
        {state === "sending" ? "Sending…" : "Subscribe"}
      </button>
      {message ? (
        <p className={state === "error" ? "form-msg bad" : "form-msg"} role="status">
          {message}
        </p>
      ) : null}
    </form>
  );
}

export function SiteFooter({ note }: { note: string }) {
  const { config } = useSite();
  const { pathname } = useLocation();
  const showTools = !/^\/admin/.test(pathname);
  return (
    <>
      <AdSlot name="footer" />
      <footer className="colophon">
        {showTools ? <SubscribeBox source="footer" /> : null}
        <p>{note}</p>
        {showTools ? (
          <nav className="foot-links" aria-label="Site">
            <Link to="/status">Data sources</Link>
            {config.server ? <Link to="/privacy">Privacy</Link> : null}
            {config.server && config.plus.enabled ? <Link to="/plus">{config.plus.name}</Link> : null}
            {config.support.enabled && config.support.url ? (
              <a href={config.support.url} target="_blank" rel="noopener noreferrer">
                {config.support.label}
              </a>
            ) : null}
          </nav>
        ) : null}
      </footer>
    </>
  );
}
