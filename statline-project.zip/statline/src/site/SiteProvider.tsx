import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useLocation } from "react-router-dom";
import { sports } from "../data";

export type SlotName = "header" | "inline" | "footer";

export type SlotConfig = { enabled: boolean; type: "adsense" | "custom"; adsenseSlot: string; customHtml: string };

export type PromoItem = {
  id: string;
  title: string;
  body: string;
  cta: string;
  kind: "affiliate" | "sponsor" | "house";
  placements: string[];
  sports: string[];
  weight: number;
};

export type SiteConfig = {
  server: boolean;
  siteName: string;
  announcement: { enabled: boolean; text: string; url: string };
  features: { subscribe: boolean; liveLeagues: Record<string, boolean> };
  ads: { provider: "none" | "adsense"; publisherId: string; requireConsent: boolean; slots: Record<SlotName, SlotConfig> };
  support: { enabled: boolean; label: string; url: string };
  plus: { enabled: boolean; name: string; price: string; pitch: string; buyUrl: string };
  legal: { contactEmail: string; privacyText: string; affiliateNote: string };
  promos: PromoItem[];
  entitled: boolean;
};

const off: SlotConfig = { enabled: false, type: "adsense", adsenseSlot: "", customHtml: "" };

// With no server (the plain index.html file, or a static host) every money feature is off and nothing changes.
export const DEFAULT_CONFIG: SiteConfig = {
  server: false,
  siteName: "Statline",
  announcement: { enabled: false, text: "", url: "" },
  features: { subscribe: false, liveLeagues: {} },
  ads: { provider: "none", publisherId: "", requireConsent: true, slots: { header: off, inline: off, footer: off } },
  support: { enabled: false, label: "Support", url: "" },
  plus: { enabled: false, name: "Plus", price: "", pitch: "", buyUrl: "" },
  legal: { contactEmail: "", privacyText: "", affiliateNote: "" },
  promos: [],
  entitled: false,
};

type Context = { config: SiteConfig; loaded: boolean; reload: () => void };
const SiteContext = createContext<Context>({ config: DEFAULT_CONFIG, loaded: false, reload: () => undefined });

export function SiteProvider({ children }: { children: ReactNode }) {
  const [config, setConfig] = useState<SiteConfig>(DEFAULT_CONFIG);
  const [loaded, setLoaded] = useState(false);

  const reload = useCallback(() => {
    if (!/^https?:$/.test(window.location.protocol)) {
      setLoaded(true);
      return;
    }
    fetch("/api/config", { credentials: "same-origin" })
      .then((res) => (res.ok ? res.json() : Promise.reject(new Error("no server"))))
      .then((json: { ok?: boolean; config?: Partial<SiteConfig> }) => {
        if (json?.ok && json.config) setConfig({ ...DEFAULT_CONFIG, ...json.config, server: true } as SiteConfig);
      })
      .catch(() => undefined)
      .finally(() => setLoaded(true));
  }, []);

  useEffect(() => {
    reload();
  }, [reload]);

  const value = useMemo(() => ({ config, loaded, reload }), [config, loaded, reload]);
  return <SiteContext.Provider value={value}>{children}</SiteContext.Provider>;
}

export function useSite(): Context {
  return useContext(SiteContext);
}

function doNotTrack(): boolean {
  return navigator.doNotTrack === "1" || (navigator as Navigator & { globalPrivacyControl?: boolean }).globalPrivacyControl === true;
}

export function track(config: SiteConfig, type: "view" | "promo" | "ad", id: string) {
  if (!config.server || doNotTrack()) return;
  fetch("/api/track", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ type, id }),
    keepalive: true,
  }).catch(() => undefined);
}

const PLAIN_PAGES = new Set(["home", "status", "plus", "privacy"]);

function isCountedPage(page: string): boolean {
  return PLAIN_PAGES.has(page) || sports.some((sport) => page === sport.id || page === `${sport.id}/lab`);
}

// Counts one page view per page, as a short page name (never a person). Admin and unknown pages are skipped,
// and a settings refresh on the same page does not count twice.
export function PageViews() {
  const { config, loaded } = useSite();
  const { pathname } = useLocation();
  const last = useRef("");
  useEffect(() => {
    if (!loaded || !config.server) return;
    const page = pathname === "/" ? "home" : pathname.replace(/^\//, "");
    if (!isCountedPage(page) || last.current === page) return;
    last.current = page;
    track(config, "view", page);
  }, [pathname, loaded, config]);
  return null;
}
