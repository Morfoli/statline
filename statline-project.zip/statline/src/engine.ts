import type { Category, League, Player, Slot, Sport } from "./types";

export function points(sport: Sport, player: Player): number {
  let total = 0;
  for (const rule of sport.scoring) {
    if (rule.roles && !rule.roles.includes(player.role)) continue;
    const raw = player.stats[rule.key];
    if (raw === undefined) continue;
    total += raw * rule.weight;
  }
  return Math.round(total * 10) / 10;
}

export function fits(player: Player, slot: Slot): boolean {
  return slot.accepts.some((tag) => player.tags.includes(tag));
}

export function ordinal(n: number): string {
  const tens = n % 100;
  if (tens >= 11 && tens <= 13) return `${n}th`;
  switch (n % 10) {
    case 1:
      return `${n}st`;
    case 2:
      return `${n}nd`;
    case 3:
      return `${n}rd`;
    default:
      return `${n}th`;
  }
}

export function formatStat(value: number | undefined, digits = 0): string {
  if (value === undefined || Number.isNaN(value)) return "—";
  if (digits === 0) return Math.round(value).toLocaleString("en-US");
  return value.toFixed(digits);
}

export function normalizeName(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

const SLOT_WORD =
  /^(c|1b|2b|3b|ss|of|dh|util|sp|rp|qb|rb|wr|te|flex|pg|sg|sf|pf|g|f|gk|d|m|w|oh|mb|opp|l|s|a|fh|bk|fw|p|dst|def|k|bn|bench|slot|pos|position|team)$/i;

// "Soto, Juan" (a common export format) becomes "Juan Soto".
function flipLastFirst(name: string): string {
  const at = name.indexOf(",");
  if (at < 1) return name;
  const last = name.slice(0, at).trim();
  const first = name.slice(at + 1).trim();
  return first && last ? `${first} ${last}` : name;
}

function cells(line: string): string[] {
  const trimmed = line.trim();
  if (!trimmed) return [];
  if (trimmed.startsWith('"')) {
    const end = trimmed.indexOf('"', 1);
    const name = (end > 0 ? trimmed.slice(1, end) : trimmed.replaceAll('"', "")).trim();
    return name ? [flipLastFirst(name)] : [];
  }
  return trimmed
    .split(/[,\t]/)
    .map((part) => part.trim())
    .filter(Boolean);
}

function stripNoise(value: string): string {
  return value
    .replace(/^\d+\s*[.):\-]\s*/, "")
    .replace(/^(qb|rb|wr|te|flex|util|pg|sg|sf|pf|sp|rp|of|1b|2b|3b|ss|dh|gk|oh|mb|opp|fh|bk|fw|c|g|d|m|f|w|s|a|l|p)\s*[:\-]\s*/i, "")
    .trim();
}

export function parseImport(text: string): string[] {
  const names: string[] = [];
  text.split(/\r?\n/).forEach((line, index) => {
    const parts = cells(line).map(stripNoise).filter(Boolean);
    if (parts.length === 0) return;
    if (index === 0 && /^(name|player|athlete)$/i.test(parts[0])) return;
    const named = parts.find((part) => part.includes(" ") && !SLOT_WORD.test(part));
    const pick = named ?? parts.find((part) => !SLOT_WORD.test(part));
    if (pick) names.push(pick);
  });
  return names;
}

const NAME_SUFFIXES = new Set(["jr", "sr", "ii", "iii", "iv", "v"]);

function dropSuffix(key: string): string {
  const parts = key.split(" ");
  while (parts.length > 1 && NAME_SUFFIXES.has(parts[parts.length - 1])) parts.pop();
  return parts.join(" ");
}

function addTo(index: Map<string, Player[]>, key: string, player: Player) {
  const list = index.get(key);
  if (list) list.push(player);
  else index.set(key, [player]);
}

// Matches imported names against the board. Tries the full name, then the name without
// Jr./II style suffixes, then "J. Embiid" style initials, then a last name on its own.
export function resolveNames(
  league: League,
  names: string[],
): { players: Player[]; unmatched: string[] } {
  const exactIndex = new Map<string, Player[]>();
  const looseIndex = new Map<string, Player[]>();
  const lastIndex = new Map<string, Player[]>();
  for (const player of league.players) {
    const key = normalizeName(player.name);
    const loose = dropSuffix(key);
    addTo(exactIndex, key, player);
    addTo(looseIndex, loose, player);
    addTo(lastIndex, loose.split(" ").at(-1) ?? loose, player);
  }

  const players: Player[] = [];
  const unmatched: string[] = [];
  const seen = new Set<string>();

  for (const raw of names) {
    const key = normalizeName(raw);
    if (!key) continue;
    const loose = dropSuffix(key);
    const parts = loose.split(" ");
    let hits = exactIndex.get(key) ?? looseIndex.get(loose) ?? [];
    if (hits.length === 0 && parts.length === 1) hits = lastIndex.get(loose) ?? [];
    if (hits.length === 0 && parts.length >= 2 && parts[0].length === 1) {
      hits = (lastIndex.get(parts[parts.length - 1]) ?? []).filter((player) => normalizeName(player.name).startsWith(parts[0]));
    }
    if (hits.length === 1) {
      const player = hits[0];
      if (!seen.has(player.id)) {
        seen.add(player.id);
        players.push(player);
      }
    } else if (hits.length > 1) {
      unmatched.push(`${raw} matches more than one player. Use the full name.`);
    } else {
      unmatched.push(raw);
    }
  }

  return { players, unmatched };
}

const LOWER_IS_BETTER = new Set(["era", "whip", "gaa", "gc", "int", "tov", "errors", "score", "rank"]);

export function lowerIsBetter(key: string, role?: string): boolean {
  // An interception is a mistake for a passer and a play for a defender.
  if (key === "int" && role !== undefined && role !== "passer") return false;
  return LOWER_IS_BETTER.has(key);
}

function percentile(value: number, pool: number[], higher: boolean): number {
  if (pool.length === 0) return 50;
  const better = pool.filter((entry) => (higher ? entry < value : entry > value)).length;
  const ties = pool.filter((entry) => entry === value).length;
  return Math.round((100 * (better + ties * 0.5)) / pool.length);
}

function categoryValue(category: Category, player: Player): number | null {
  if (category.role && player.role !== category.role) return null;
  if (category.require && !(player.stats[category.require] > 0)) return null;
  if (!category.keys.some((key) => player.stats[key] !== undefined)) return null;
  return category.keys.reduce((sum, key) => sum + (player.stats[key] ?? 0), 0);
}

function gradeFrom(score: number): string {
  if (score >= 88) return "A";
  if (score >= 80) return "A-";
  if (score >= 74) return "B+";
  if (score >= 67) return "B";
  if (score >= 60) return "B-";
  if (score >= 52) return "C+";
  if (score >= 45) return "C";
  if (score >= 38) return "C-";
  return "D";
}

export type MemoItem = { title: string; detail: string };

export type RosterRow = {
  slotId: string;
  slotLabel: string;
  player: Player | null;
  points: number | null;
  percentile: number | null;
  verdict: "keep" | "upgrade" | "empty";
};

export type BenchRow = { player: Player; points: number; note: string };

export type CategoryRead = { id: string; label: string; index: number | null; note: string };

export type Report = {
  grade: string;
  score: number;
  summary: string;
  strengths: MemoItem[];
  changes: MemoItem[];
  needs: MemoItem[];
  roster: RosterRow[];
  bench: BenchRow[];
  categories: CategoryRead[];
  unmatched: string[];
  totalPoints: number;
};

function bestFree(
  sport: Sport,
  league: League,
  taken: Set<string>,
  slot: Slot,
): Player | null {
  const options = league.players
    .filter((player) => !taken.has(player.id) && fits(player, slot))
    .sort((a, b) => points(sport, b) - points(sport, a));
  return options[0] ?? null;
}

export function analyze(sport: Sport, league: League, names: string[]): Report {
  const { players, unmatched } = resolveNames(league, names);
  const remaining = [...players].sort((a, b) => points(sport, b) - points(sport, a));
  const chosen = new Set<string>();
  const roster: RosterRow[] = league.slots.map((slot) => {
    const options = remaining.filter((player) => !chosen.has(player.id) && fits(player, slot));
    const player = options[0] ?? null;
    if (!player) {
      return { slotId: slot.id, slotLabel: slot.label, player: null, points: null, percentile: null, verdict: "empty" };
    }
    chosen.add(player.id);
    const score = points(sport, player);
    const pool = league.players.filter((entry) => fits(entry, slot)).map((entry) => points(sport, entry));
    const pct = percentile(score, pool, true);
    return {
      slotId: slot.id,
      slotLabel: slot.label,
      player,
      points: score,
      percentile: pct,
      verdict: pct >= 62 ? "keep" : "upgrade",
    };
  });

  const reserved = new Set(roster.flatMap((row) => (row.player ? [row.player.id] : [])));
  const strengths: MemoItem[] = [];
  const changes: MemoItem[] = [];
  const needs: MemoItem[] = [];

  const keepers = roster.filter((row) => row.verdict === "keep" && row.player);
  keepers
    .slice()
    .sort((a, b) => (b.percentile ?? 0) - (a.percentile ?? 0))
    .slice(0, 2)
    .forEach((row) => {
      strengths.push({
        title: `${row.player!.name} is a keeper`,
        detail: `${row.slotLabel} grades in the ${ordinal(row.percentile ?? 0)} percentile of this board at ${row.points} desk points. Build around this spot. A sideways swap is not a plan.`,
      });
    });

  roster.forEach((row) => {
    const slot = league.slots.find((entry) => entry.id === row.slotId);
    if (!slot) return;
    if (!row.player || row.verdict === "empty") {
      const add = bestFree(sport, league, reserved, slot);
      needs.push({
        title: `Fill ${row.slotLabel}`,
        detail: add
          ? `The slot is empty. Best fit still available: ${add.name}, ${add.pos}, ${add.team} (${points(sport, add)} pts).`
          : `The slot is empty, and this board has no eligible player left outside the club.`,
      });
      if (add) reserved.add(add.id);
      return;
    }
    if (row.verdict === "upgrade" && row.percentile !== null) {
      const add = bestFree(sport, league, reserved, slot);
      if (add) reserved.add(add.id);
      const hard = row.percentile < 48;
      changes.push({
        title: hard ? `Change ${row.slotLabel}` : `Upgrade ${row.slotLabel} if you can`,
        detail: add
          ? `${row.player.name} is in the ${ordinal(row.percentile ?? 0)} percentile here (${row.points} pts). ${add.name} is available at ${points(sport, add)} pts and is the cleaner play.`
          : `${row.player.name} is in the ${ordinal(row.percentile ?? 0)} percentile (${row.points} pts). The board does not have a clear upgrade outside this club, so the fix is a trade, not a free add.`,
      });
    }
  });

  const covered = sport.categories.filter((category) => league.players.some((player) => categoryValue(category, player) !== null));
  const categories: CategoryRead[] = covered.map((category) => {
    const pool = league.players
      .map((player) => categoryValue(category, player))
      .filter((value): value is number => value !== null);
    const starterValues = roster
      .map((row) => (row.player ? categoryValue(category, row.player) : null))
      .filter((value): value is number => value !== null);
    if (starterValues.length === 0 || pool.length === 0) {
      return {
        id: category.id,
        label: category.label,
        index: null,
        note: "Nobody in the lineup covers this.",
      };
    }
    const average = starterValues.reduce((sum, value) => sum + value, 0) / starterValues.length;
    const index = percentile(average, pool, category.higher);
    const direction = index >= 72 ? "a weapon" : index < 45 ? "light" : "playable";
    return {
      id: category.id,
      label: category.label,
      index,
      note:
        index >= 72
          ? `Your typical starter is ahead of ${index}% of this board. ${category.label} is ${direction}.`
          : index < 45
            ? `Your typical starter trails most of this board (${ordinal(index)} percentile). ${category.label} is ${direction}.`
            : `${category.label} sits near the middle of the board (${ordinal(index)} percentile).`,
    };
  });

  categories
    .filter((category) => category.index !== null && category.index >= 72)
    .slice(0, 2)
    .forEach((category) => {
      strengths.push({ title: `${category.label} is working`, detail: category.note });
    });

  const weakCategories = categories.filter((category) => category.index !== null && category.index < 45);
  weakCategories.slice(0, 3).forEach((category) => {
    const spec = sport.categories.find((entry) => entry.id === category.id);
    if (!spec) return;
    const boost = league.players
      .filter((player) => !chosen.has(player.id))
      .map((player) => ({ player, value: categoryValue(spec, player) }))
      .filter((entry): entry is { player: Player; value: number } => entry.value !== null)
      .sort((a, b) => (spec.higher ? b.value - a.value : a.value - b.value))[0];
    needs.push({
      title: `You need ${category.label.toLowerCase()}`,
      detail: boost
        ? `${category.note} ${boost.player.name} is the strongest available lift in that category.`
        : category.note,
    });
  });

  const bench: BenchRow[] = players
    .filter((player) => !chosen.has(player.id))
    .map((player) => {
      const open = league.slots.find((slot) => roster.some((row) => row.slotLabel === slot.label && row.player && fits(player, slot)));
      const starter = open
        ? roster.find((row) => row.slotLabel === open.label && row.player && fits(player, open))
        : undefined;
      let note = "No starting slot takes this role on this roster.";
      if (player.role === "defense") {
        note = "Defense is on the football desk. This fantasy roster starts offense only.";
      } else if (starter?.player) {
        note = `Behind ${starter.player.name} at ${starter.slotLabel}. ${points(sport, player)} pts against the starter's ${starter.points}.`;
      }
      return { player, points: points(sport, player), note };
    });

  if (bench.some((row) => row.player.role === "defense") && !changes.some((item) => item.title.includes("Defense"))) {
    changes.push({
      title: "Defense does not start here",
      detail: "Imported defenders stay off the offensive roster. Read them on the football desk. They do not patch a weak skill spot.",
    });
  }

  if (strengths.length === 0) {
    const closest = roster
      .filter((row) => row.player && row.percentile !== null)
      .sort((a, b) => (b.percentile ?? 0) - (a.percentile ?? 0))[0];
    strengths.push({
      title: closest?.player ? `${closest.player.name} is the least of the problems` : "Nothing here is a building block yet",
      detail: closest?.player
        ? `At the ${ordinal(closest.percentile ?? 0)} percentile, this is the high point of the club. It is not a reason to stand pat.`
        : "Add a full set of starters before looking for style points.",
    });
  }

  const hardHoles = roster.filter((row) => row.verdict === "empty" || (row.percentile !== null && row.percentile < 48)).length;
  const slotScore =
    roster.reduce((sum, row) => sum + (row.percentile ?? 12), 0) / Math.max(roster.length, 1);
  const score = Math.max(0, Math.min(100, Math.round(slotScore)));
  const grade = gradeFrom(score);
  const lead = keepers.slice(0, 2).map((row) => row.player!.name);
  let summary = `${grade} on the ${league.short} board. `;
  summary += lead.length
    ? `${lead.join(" and ")} ${lead.length > 1 ? "are" : "is"} worth keeping. `
    : "No starter is strong enough to build around. ";
  summary += hardHoles
    ? `${hardHoles} spot${hardHoles === 1 ? "" : "s"} should change before this club contends.`
    : "The shape is sound. Tinker only when a clear upgrade is actually available.";

  return {
    grade,
    score,
    summary,
    strengths: strengths.slice(0, 4),
    changes: changes.slice(0, 5),
    needs: needs.slice(0, 5),
    roster,
    bench,
    categories,
    unmatched,
    totalPoints: Math.round(roster.reduce((sum, row) => sum + (row.points ?? 0), 0) * 10) / 10,
  };
}

export function scoutLine(league: League, player: Player, columns: { key: string; label: string }[]): string {
  const ranked = columns
    .filter((column) => player.stats[column.key] !== undefined)
    .map((column) => {
      const pool = league.players
        .filter((entry) => entry.role === player.role)
        .map((entry) => entry.stats[column.key])
        .filter((value): value is number => value !== undefined);
      const higher = !lowerIsBetter(column.key, player.role);
      return { label: column.label, pct: percentile(player.stats[column.key], pool, higher) };
    })
    .sort((a, b) => b.pct - a.pct);
  if (ranked.length === 0) return `${player.name} is on the board without a full stat line.`;
  const best = ranked[0];
  const quiet = ranked[ranked.length - 1];
  if (best.label === quiet.label) {
    return `${player.name} grades in the ${ordinal(best.pct)} percentile for ${best.label.toLowerCase()} on this board.`;
  }
  return `${player.name} grades in the ${ordinal(best.pct)} percentile for ${best.label.toLowerCase()}. The quiet part of the profile is ${quiet.label.toLowerCase()} (${ordinal(quiet.pct)}).`;
}

export function statPercentile(league: League, player: Player, key: string, higher: boolean): number {
  const pool = league.players
    .map((entry) => entry.stats[key])
    .filter((value): value is number => value !== undefined);
  return percentile(player.stats[key] ?? 0, pool, higher);
}
