import type { BoardRow, Player } from "../types";

// Live stats come from ESPN's public JSON API (no key). Two endpoints are used:
//   player leaderboards: /apis/common/v3/sports/{sport}/{league}/statistics/byathlete
//   standings:           /apis/v2/sports/{sport}/{league}/standings
// The payload shape (athletes[].categories[].values[] aligned with the top-level
// categories[].names[]) was checked against real captured responses. Request parameter
// formats that differ by league (football categories, goalie sorts) are tried in order
// and the working one is remembered, so a rejected format degrades instead of breaking.

const WEB_HOSTS = ["site.web.api.espn.com", "site.api.espn.com"];
const STANDINGS_HOST = "site.api.espn.com";
const PAGE_SIZE = 50;
const REQUEST_MS = 12000;

export type LiveLeagueData = {
  players: Player[];
  board: BoardRow[];
  season: string;
  fetchedAt: number;
  source: string;
  notes: string[];
};

export class FeedError extends Error {
  kind: "network" | "http" | "parse" | "empty";
  status?: number;
  constructor(message: string, kind: FeedError["kind"], status?: number) {
    super(message);
    this.kind = kind;
    this.status = status;
  }
}

type Variant = { category?: string; sort?: string };
type Row = { id: string; name: string; team: string; pos: string; v: Record<string, number> };
type PlanResult = { rows: Row[]; season?: string };
type Plan = {
  id: string;
  variants: Variant[];
  pages: number;
  accept: (rows: Row[]) => boolean;
};
export type Feed = {
  id: string;
  sport: string;
  league: string;
  season: (now: Date) => number;
  plans: Plan[];
  build: (leagueId: string, results: Record<string, Row[]>) => Player[];
  standings: "record" | "points";
};

type RawCategoryDef = { name?: string; names?: string[] };
type RawAthlete = {
  athlete?: {
    id?: string | number;
    displayName?: string;
    teamShortName?: string;
    teamName?: string;
    position?: { abbreviation?: string };
  };
  categories?: { name?: string; values?: unknown[]; totals?: unknown[] }[];
};
type RawPage = {
  pagination?: { pages?: number };
  athletes?: RawAthlete[];
  categories?: RawCategoryDef[];
  requestedSeason?: { displayName?: string };
};

// ---------------------------------------------------------------- network

async function getJson(url: string): Promise<unknown> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_MS);
  try {
    let res: Response;
    try {
      res = await fetch(url, { signal: controller.signal });
    } catch {
      throw new FeedError(
        controller.signal.aborted ? "ESPN took too long to answer" : "The browser could not reach ESPN (offline, blocked, or CORS)",
        "network",
      );
    }
    if (!res.ok) throw new FeedError(`ESPN answered HTTP ${res.status}`, "http", res.status);
    try {
      return await res.json();
    } catch {
      throw new FeedError("ESPN's reply was not readable JSON", "parse");
    }
  } finally {
    clearTimeout(timer);
  }
}

let hostPref = 0;

function byAthleteUrl(host: string, feed: Feed, season: number, page: number, variant: Variant): string {
  const params = new URLSearchParams({
    season: String(season),
    seasontype: "2",
    limit: String(PAGE_SIZE),
    page: String(page),
  });
  if (variant.category) params.set("category", variant.category);
  if (variant.sort) params.set("sort", variant.sort);
  return `https://${host}/apis/common/v3/sports/${feed.sport}/${feed.league}/statistics/byathlete?${params.toString()}`;
}

async function fetchPage(feed: Feed, season: number, page: number, variant: Variant): Promise<RawPage> {
  let last: unknown = new FeedError("No ESPN host answered", "network");
  for (let k = 0; k < WEB_HOSTS.length; k += 1) {
    const at = (hostPref + k) % WEB_HOSTS.length;
    try {
      const json = await getJson(byAthleteUrl(WEB_HOSTS[at], feed, season, page, variant));
      hostPref = at;
      return json as RawPage;
    } catch (error) {
      last = error;
      // Only a network-level failure is worth retrying on the other host.
      if (!(error instanceof FeedError) || error.kind !== "network") throw error;
    }
  }
  throw last;
}

// ---------------------------------------------------------------- parsing

function parseTotal(text: unknown): number | undefined {
  if (typeof text !== "string" || text.trim() === "") return undefined;
  const n = Number(text.replace(/,/g, ""));
  return Number.isFinite(n) ? n : undefined;
}

export function parseRows(page: RawPage): Row[] {
  const defs = new Map<string, string[]>();
  for (const category of page.categories ?? []) {
    if (category?.name && Array.isArray(category.names)) defs.set(category.name, category.names);
  }
  const rows: Row[] = [];
  for (const entry of page.athletes ?? []) {
    const athlete = entry?.athlete;
    if (!athlete || athlete.id === undefined || !athlete.displayName) continue;
    const v: Record<string, number> = {};
    for (const category of entry.categories ?? []) {
      const names = category.name ? defs.get(category.name) : undefined;
      if (!names) continue;
      names.forEach((stat, i) => {
        const raw = Array.isArray(category.values) ? category.values[i] : parseTotal(category.totals?.[i]);
        if (typeof raw === "number" && Number.isFinite(raw)) v[`${category.name}.${stat}`] = raw;
      });
    }
    rows.push({
      id: String(athlete.id),
      name: athlete.displayName,
      team: athlete.teamShortName || athlete.teamName || "FA",
      pos: athlete.position?.abbreviation ?? "",
      v,
    });
  }
  return rows;
}

// ---------------------------------------------------------------- plans

function variantKey(feed: Feed, plan: Plan): string {
  return `statline-variant:v1:${feed.id}:${plan.id}`;
}

function variantOrder(feed: Feed, plan: Plan): number[] {
  const all = plan.variants.map((_, i) => i);
  try {
    const saved = Number(localStorage.getItem(variantKey(feed, plan)));
    if (Number.isInteger(saved) && saved >= 0 && saved < all.length) return [saved, ...all.filter((i) => i !== saved)];
  } catch {
    // storage can be blocked; the default order is fine
  }
  return all;
}

function rememberVariant(feed: Feed, plan: Plan, index: number) {
  try {
    localStorage.setItem(variantKey(feed, plan), String(index));
  } catch {
    // ignore
  }
}

function isVariantProblem(error: unknown): boolean {
  if (!(error instanceof FeedError)) return false;
  if (error.kind === "empty" || error.kind === "parse") return true;
  return error.kind === "http" && [400, 404, 422].includes(error.status ?? 0);
}

async function runPlan(feed: Feed, plan: Plan, season: number, notes: string[]): Promise<PlanResult> {
  let last: unknown = new FeedError(`${plan.id}: no request variants`, "empty");
  for (const index of variantOrder(feed, plan)) {
    const variant = plan.variants[index];
    try {
      const first = await fetchPage(feed, season, 1, variant);
      let rows = parseRows(first);
      if (!plan.accept(rows)) {
        last = new FeedError(`${plan.id}: ESPN returned no usable rows for ${season}`, "empty");
        continue;
      }
      const pages = Math.min(Math.max(first.pagination?.pages ?? 1, 1), plan.pages);
      if (pages > 1) {
        const rest = await Promise.all(
          Array.from({ length: pages - 1 }, (_, i) => fetchPage(feed, season, i + 2, variant)),
        );
        for (const page of rest) rows = rows.concat(parseRows(page));
      }
      rememberVariant(feed, plan, index);
      notes.push(`${plan.id}: request style ${index + 1} of ${plan.variants.length}, ${rows.length} rows`);
      return { rows, season: first.requestedSeason?.displayName };
    } catch (error) {
      if (!isVariantProblem(error)) throw error;
      last = error;
    }
  }
  throw last;
}

// ---------------------------------------------------------------- standings

type RawStat = { name?: string; value?: number; displayValue?: string };
type RawEntry = { team?: { abbreviation?: string; shortDisplayName?: string; name?: string }; stats?: RawStat[] };
type RawGroup = {
  name?: string;
  abbreviation?: string;
  shortName?: string;
  standings?: { entries?: RawEntry[] };
  children?: RawGroup[];
};

function collectGroups(node: RawGroup, out: { label: string; entries: RawEntry[] }[] = []) {
  if (node.standings?.entries?.length) {
    out.push({ label: node.abbreviation || node.shortName || node.name || "", entries: node.standings.entries });
  }
  for (const child of node.children ?? []) collectGroups(child, out);
  return out;
}

function statValue(entry: RawEntry, name: string): number | undefined {
  const found = entry.stats?.find((s) => s.name === name);
  return typeof found?.value === "number" ? found.value : undefined;
}

async function loadBoard(feed: Feed, season: number): Promise<BoardRow[]> {
  const url = `https://${STANDINGS_HOST}/apis/v2/sports/${feed.sport}/${feed.league}/standings?season=${season}`;
  const root = (await getJson(url)) as RawGroup;
  const teams: { row: BoardRow; sortKey: number; wins: number }[] = [];
  let played = 0;
  for (const group of collectGroups(root)) {
    for (const entry of group.entries) {
      const team = entry.team;
      if (!team?.abbreviation) continue;
      const wins = statValue(entry, "wins") ?? 0;
      const losses = statValue(entry, "losses") ?? 0;
      const ties = statValue(entry, "ties") ?? 0;
      played += wins + losses + ties + (statValue(entry, "otLosses") ?? 0);
      let mark: string;
      let sortKey: number;
      if (feed.standings === "points") {
        const points = statValue(entry, "points") ?? 0;
        mark = `${points} pts`;
        sortKey = points;
      } else {
        mark = ties > 0 ? `${wins}-${losses}-${ties}` : `${wins}-${losses}`;
        sortKey = statValue(entry, "winPercent") ?? wins / Math.max(1, wins + losses + ties);
      }
      teams.push({
        row: { abbr: team.abbreviation, name: team.shortDisplayName || team.name || team.abbreviation, mark, line: group.label },
        sortKey,
        wins,
      });
    }
  }
  if (teams.length === 0 || played === 0) throw new FeedError("Standings had no games played yet", "empty");
  teams.sort((a, b) => b.sortKey - a.sortKey || b.wins - a.wins);
  return teams.slice(0, 6).map((t) => t.row);
}

// ---------------------------------------------------------------- shared mapping helpers

function uniq(rows: Row[] | undefined): Row[] {
  const seen = new Map<string, Row>();
  for (const row of rows ?? []) if (!seen.has(row.id)) seen.set(row.id, row);
  return [...seen.values()];
}

function compact(stats: Record<string, number | undefined>): Record<string, number> {
  const out: Record<string, number> = {};
  for (const [key, value] of Object.entries(stats)) if (value !== undefined) out[key] = value;
  return out;
}

function maxOf(rows: Row[], key: string): number {
  return rows.reduce((best, row) => Math.max(best, row.v[key] ?? 0), 0);
}

function hasCount(rows: Row[], enough: number, test: (row: Row) => boolean): boolean {
  return rows.filter(test).length >= enough;
}

// ---------------------------------------------------------------- basketball (NBA, WNBA)

// ESPN only reports G, F and C here, so a guard fits both guard slots and a forward both forward slots.
function basketballTags(pos: string): string[] {
  switch (pos) {
    case "PG":
      return ["PG"];
    case "SG":
      return ["SG"];
    case "SF":
      return ["SF"];
    case "PF":
      return ["PF"];
    case "C":
      return ["C"];
    case "G":
      return ["PG", "SG"];
    case "F":
      return ["SF", "PF"];
    case "GF":
    case "G-F":
      return ["SG", "SF"];
    case "FC":
    case "F-C":
      return ["PF", "C"];
    default:
      return ["SF", "PF"];
  }
}

function buildBasketball(leagueId: string, results: Record<string, Row[]>): Player[] {
  const rows = uniq(results.players);
  const threshold = Math.max(1, Math.ceil(maxOf(rows, "general.gamesPlayed") * 0.4));
  const out: Player[] = [];
  for (const row of rows) {
    const points = row.v["offensive.avgPoints"];
    if (points === undefined || (row.v["general.gamesPlayed"] ?? 0) < threshold) continue;
    const pos = row.pos || "F";
    out.push({
      id: `${leagueId}-${row.id}`,
      name: row.name,
      team: row.team,
      pos,
      role: "player",
      tags: basketballTags(pos),
      stats: compact({
        pts: points,
        reb: row.v["general.avgRebounds"],
        ast: row.v["offensive.avgAssists"],
        stl: row.v["defensive.avgSteals"],
        blk: row.v["defensive.avgBlocks"],
        tov: row.v["offensive.avgTurnovers"],
        fg: row.v["offensive.fieldGoalPct"],
      }),
    });
  }
  return out;
}

const basketballPlan = (pages: number): Plan => ({
  id: "players",
  variants: [{ sort: "offensive.avgPoints:desc" }, {}],
  pages,
  accept: (rows) => hasCount(rows, 8, (r) => r.v["offensive.avgPoints"] !== undefined),
});

// ---------------------------------------------------------------- hockey (NHL)

function hockeySkaterPos(pos: string): string {
  if (pos === "C" || pos === "D") return pos;
  return "W"; // LW, RW and anything else on the wing
}

function buildHockey(leagueId: string, results: Record<string, Row[]>): Player[] {
  const skaters = uniq(results.skaters).filter((r) => r.pos !== "G" && r.v["offensive.points"] !== undefined);
  const skaterGames = Math.max(1, Math.ceil(maxOf(skaters, "general.games") * 0.4));
  const goalies = uniq(results.goalies).filter((r) => r.pos === "G" && r.v["defensive.savePct"] !== undefined);
  const goalieGames = Math.max(1, Math.ceil(maxOf(goalies, "general.games") * 0.35));
  const out: Player[] = [];
  for (const row of skaters) {
    if ((row.v["general.games"] ?? 0) < skaterGames) continue;
    const pos = hockeySkaterPos(row.pos);
    out.push({
      id: `${leagueId}-${row.id}`,
      name: row.name,
      team: row.team,
      pos,
      role: "skater",
      tags: [pos],
      stats: compact({
        g: row.v["offensive.goals"],
        a: row.v["offensive.assists"],
        pts: row.v["offensive.points"],
        sog: row.v["offensive.shotsTotal"],
      }),
    });
  }
  for (const row of goalies) {
    if ((row.v["general.games"] ?? 0) < goalieGames) continue;
    const savePct = row.v["defensive.savePct"] as number;
    out.push({
      id: `${leagueId}-${row.id}`,
      name: row.name,
      team: row.team,
      pos: "G",
      role: "goalie",
      tags: ["G"],
      stats: compact({
        w: row.v["general.wins"] ?? 0,
        svpct: savePct > 1.5 ? savePct / 100 : savePct,
        gaa: row.v["defensive.avgGoalsAgainst"],
        so: row.v["defensive.shutouts"] ?? 0,
      }),
    });
  }
  return out;
}

// ---------------------------------------------------------------- football (NFL)

type GridKind = { pos: string; role: "passer" | "skill" | "defense" };

function footballKind(raw: string): GridKind | null {
  switch (raw) {
    case "QB":
      return { pos: "QB", role: "passer" };
    case "RB":
    case "FB":
      return { pos: "RB", role: "skill" };
    case "WR":
      return { pos: "WR", role: "skill" };
    case "TE":
      return { pos: "TE", role: "skill" };
    case "DE":
    case "DT":
    case "NT":
    case "DL":
      return { pos: "DL", role: "defense" };
    case "EDGE":
      return { pos: "EDGE", role: "defense" };
    case "LB":
    case "OLB":
    case "ILB":
    case "MLB":
      return { pos: "LB", role: "defense" };
    case "CB":
    case "S":
    case "FS":
    case "SS":
    case "DB":
      return { pos: "DB", role: "defense" };
    default:
      return null;
  }
}

function buildFootball(leagueId: string, results: Record<string, Row[]>): Player[] {
  const merged = new Map<string, Row>();
  for (const key of ["qb", "rush", "rec", "def"]) {
    for (const row of results[key] ?? []) {
      const have = merged.get(row.id);
      if (!have) {
        merged.set(row.id, { ...row, v: { ...row.v } });
      } else {
        for (const [stat, value] of Object.entries(row.v)) if (have.v[stat] === undefined) have.v[stat] = value;
      }
    }
  }
  const all = [...merged.values()];
  const maxAttempts = maxOf(all.filter((r) => r.pos === "QB"), "passing.passingAttempts");
  const out: Player[] = [];
  for (const row of all) {
    const kind = footballKind(row.pos);
    const games = row.v["general.gamesPlayed"] ?? 0;
    if (!kind || games <= 0) continue;
    const n = (key: string) => row.v[key] ?? 0;
    let stats: Record<string, number>;
    if (kind.role === "passer") {
      if (n("passing.passingAttempts") < Math.max(1, maxAttempts * 0.25)) continue;
      stats = {
        passYd: n("passing.passingYards"),
        passTd: n("passing.passingTouchdowns"),
        int: n("passing.interceptions"),
        rushYd: n("rushing.rushingYards"),
        rushTd: n("rushing.rushingTouchdowns"),
      };
    } else if (kind.role === "skill") {
      const touches = n("rushing.rushingAttempts") + n("receiving.receptions");
      if (touches / games < 3) continue;
      stats = {
        rushYd: n("rushing.rushingYards"),
        rushTd: n("rushing.rushingTouchdowns"),
        rec: n("receiving.receptions"),
        recYd: n("receiving.receivingYards"),
        recTd: n("receiving.receivingTouchdowns"),
      };
    } else {
      if (row.v["defensive.totalTackles"] === undefined) continue;
      stats = {
        tkl: n("defensive.totalTackles"),
        tfl: n("defensive.tacklesForLoss"),
        sack: n("defensive.sacks"),
        int: n("defensiveinterceptions.interceptions"),
        ff: n("general.fumblesForced"),
      };
    }
    out.push({ id: `${leagueId}-${row.id}`, name: row.name, team: row.team, pos: kind.pos, role: kind.role, tags: [kind.pos], stats });
  }
  return out;
}

const footballVariants = (group: string, category: string, sort: string): Variant[] => [
  { category: `${group}:${category}`, sort },
  { category, sort },
  { sort },
];

// ---------------------------------------------------------------- baseball (MLB)

function baseballPos(raw: string): string | null {
  switch (raw) {
    case "C":
    case "1B":
    case "2B":
    case "3B":
    case "SS":
    case "DH":
      return raw;
    case "LF":
    case "CF":
    case "RF":
    case "OF":
      return "OF";
    default:
      return null;
  }
}

function buildBaseball(leagueId: string, results: Record<string, Row[]>): Player[] {
  const out: Player[] = [];
  const hitters = uniq(results.hit);
  const minAtBats = maxOf(hitters, "batting.atBats") * 0.35;
  const hitterIds = new Set<string>();
  for (const row of hitters) {
    const pos = baseballPos(row.pos);
    const avg = row.v["batting.avg"];
    if (!pos || avg === undefined || (row.v["batting.atBats"] ?? 0) < Math.max(1, minAtBats)) continue;
    hitterIds.add(row.id);
    out.push({
      id: `${leagueId}-${row.id}`,
      name: row.name,
      team: row.team,
      pos,
      role: "hitter",
      tags: pos === "DH" ? ["UTIL"] : [pos, "UTIL"],
      stats: compact({
        avg,
        hr: row.v["batting.homeRuns"] ?? 0,
        rbi: row.v["batting.RBIs"] ?? 0,
        r: row.v["batting.runs"] ?? 0,
        sb: row.v["batting.stolenBases"] ?? 0,
      }),
    });
  }

  const pitchers = uniq([...(results.sp ?? []), ...(results.rp ?? [])]).filter(
    (r) => r.v["pitching.innings"] !== undefined && r.v["pitching.ERA"] !== undefined,
  );
  const starters = pitchers.filter((r) => isStarter(r));
  const maxInnings = Math.max(1, maxOf(starters.length ? starters : pitchers, "pitching.innings"));
  for (const row of pitchers) {
    const innings = row.v["pitching.innings"] as number;
    const saves = row.v["pitching.saves"] ?? 0;
    const starter = isStarter(row);
    if (starter ? innings < maxInnings * 0.3 : !(saves >= 2 || innings >= maxInnings * 0.2)) continue;
    const pos = starter ? "SP" : "RP";
    out.push({
      id: `${leagueId}-${row.id}p`,
      name: hitterIds.has(row.id) ? `${row.name} (P)` : row.name,
      team: row.team,
      pos,
      role: "pitcher",
      tags: [pos],
      stats: compact({
        ip: innings,
        era: row.v["pitching.ERA"],
        k: row.v["pitching.strikeouts"] ?? 0,
        whip: row.v["pitching.WHIP"],
        sv: saves,
      }),
    });
  }
  return out;
}

function isStarter(row: Row): boolean {
  const games = row.v["pitching.gamesPlayed"] ?? 0;
  const started = row.v["pitching.gamesStarted"] ?? 0;
  return started >= 1 && started / Math.max(1, games) >= 0.5;
}

// ---------------------------------------------------------------- registry

const yearEnding = (now: Date) => (now.getMonth() >= 9 ? now.getFullYear() + 1 : now.getFullYear());
const yearStarting = (startMonth: number) => (now: Date) =>
  now.getMonth() >= startMonth ? now.getFullYear() : now.getFullYear() - 1;

const FOOTBALL_DEFENSE = new Set(["DE", "DT", "NT", "DL", "EDGE", "LB", "OLB", "ILB", "MLB", "CB", "S", "FS", "SS", "DB"]);

export const FEEDS: Record<string, Feed> = {
  nba: {
    id: "nba",
    sport: "basketball",
    league: "nba",
    season: yearEnding,
    plans: [basketballPlan(4)],
    build: buildBasketball,
    standings: "record",
  },
  wnba: {
    id: "wnba",
    sport: "basketball",
    league: "wnba",
    season: yearStarting(3),
    plans: [basketballPlan(3)],
    build: buildBasketball,
    standings: "record",
  },
  nhl: {
    id: "nhl",
    sport: "hockey",
    league: "nhl",
    season: yearEnding,
    plans: [
      {
        id: "skaters",
        variants: [{ sort: "offensive.points:desc" }, {}],
        pages: 3,
        accept: (rows) => hasCount(rows, 8, (r) => r.pos !== "G" && r.v["offensive.points"] !== undefined),
      },
      {
        id: "goalies",
        variants: [{ sort: "general.wins:desc" }, { category: "defensive", sort: "defensive.saves:desc" }],
        pages: 1,
        accept: (rows) => hasCount(rows, 5, (r) => r.pos === "G" && r.v["defensive.savePct"] !== undefined),
      },
    ],
    build: buildHockey,
    standings: "points",
  },
  nfl: {
    id: "nfl",
    sport: "football",
    league: "nfl",
    season: yearStarting(7),
    plans: [
      {
        id: "qb",
        variants: [{ sort: "passing.passingYards:desc" }, {}],
        pages: 1,
        accept: (rows) => hasCount(rows, 8, (r) => r.pos === "QB" && r.v["passing.passingYards"] !== undefined),
      },
      {
        id: "rush",
        variants: footballVariants("offense", "rushing", "rushing.rushingYards:desc"),
        pages: 2,
        accept: (rows) => hasCount(rows, 8, (r) => (r.pos === "RB" || r.pos === "FB") && r.v["rushing.rushingYards"] !== undefined),
      },
      {
        id: "rec",
        variants: footballVariants("offense", "receiving", "receiving.receivingYards:desc"),
        pages: 3,
        accept: (rows) => hasCount(rows, 8, (r) => (r.pos === "WR" || r.pos === "TE") && r.v["receiving.receivingYards"] !== undefined),
      },
      {
        id: "def",
        variants: footballVariants("defense", "defensive", "defensive.totalTackles:desc"),
        pages: 2,
        accept: (rows) => hasCount(rows, 8, (r) => FOOTBALL_DEFENSE.has(r.pos) && r.v["defensive.totalTackles"] !== undefined),
      },
    ],
    build: buildFootball,
    standings: "record",
  },
  mlb: {
    id: "mlb",
    sport: "baseball",
    league: "mlb",
    season: yearStarting(2),
    plans: [
      {
        id: "hit",
        variants: [{ category: "batting", sort: "batting.hits:desc" }, { sort: "batting.hits:desc" }, {}],
        pages: 3,
        accept: (rows) => hasCount(rows, 8, (r) => baseballPos(r.pos) !== null && r.v["batting.atBats"] !== undefined),
      },
      {
        id: "sp",
        variants: [{ category: "pitching", sort: "pitching.innings:desc" }, { sort: "pitching.innings:desc" }],
        pages: 2,
        accept: (rows) => hasCount(rows, 8, (r) => r.v["pitching.innings"] !== undefined),
      },
      {
        id: "rp",
        variants: [{ category: "pitching", sort: "pitching.saves:desc" }, { sort: "pitching.saves:desc" }],
        pages: 1,
        accept: (rows) => hasCount(rows, 3, (r) => (r.v["pitching.saves"] ?? 0) > 0),
      },
    ],
    build: buildBaseball,
    standings: "record",
  },
};

export const LIVE_LEAGUE_IDS = new Set(Object.keys(FEEDS));

export function hasLiveFeed(leagueId: string): boolean {
  return LIVE_LEAGUE_IDS.has(leagueId);
}

// ---------------------------------------------------------------- loading

async function loadSeason(feed: Feed, season: number, now: Date): Promise<LiveLeagueData> {
  const notes: string[] = [`season ${season}`];
  const [results, board] = await Promise.all([
    Promise.all(feed.plans.map((plan) => runPlan(feed, plan, season, notes))),
    loadBoard(feed, season).catch((error) => {
      if (error instanceof FeedError && error.kind === "empty") throw error;
      notes.push(`standings unavailable: ${error instanceof Error ? error.message : "unknown error"}`);
      return [] as BoardRow[];
    }),
  ]);
  const byPlan: Record<string, Row[]> = {};
  feed.plans.forEach((plan, i) => {
    byPlan[plan.id] = results[i].rows;
  });
  const players = feed.build(feed.id, byPlan);
  if (players.length < 10) throw new FeedError(`Only ${players.length} usable players for ${season}`, "empty");
  const label = results.map((r) => r.season).find(Boolean) ?? String(season);
  return {
    players,
    board,
    season: label,
    fetchedAt: now.getTime(),
    source: "ESPN",
    notes: [...notes, `${players.length} players, ${board.length} standings rows`],
  };
}

export async function loadLeague(feed: Feed, now: Date = new Date()): Promise<LiveLeagueData> {
  const primary = feed.season(now);
  let last: unknown;
  for (const season of [primary, primary - 1]) {
    try {
      return await loadSeason(feed, season, now);
    } catch (error) {
      // A season that has not started yet answers with nothing: try the previous one.
      if (error instanceof FeedError && error.kind === "empty") {
        last = error;
        continue;
      }
      throw error;
    }
  }
  throw last;
}

export function describeError(error: unknown): string {
  if (error instanceof FeedError) return error.message;
  if (error instanceof Error) return error.message;
  return "Something unexpected went wrong";
}
