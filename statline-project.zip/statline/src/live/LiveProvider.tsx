import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useSite } from "../site/SiteProvider";
import { FEEDS, describeError, loadLeague, type LiveLeagueData } from "./espn";

export type FeedStatus = "unsupported" | "loading" | "live" | "cached" | "error";

export type FeedState = {
  status: FeedStatus;
  data?: LiveLeagueData;
  error?: string;
};

export type FeedView = FeedState & { refresh: () => void };

const FRESH_MS = 15 * 60 * 1000;
const cacheKey = (leagueId: string) => `statline-live:v1:${leagueId}`;

function readCache(leagueId: string): LiveLeagueData | undefined {
  try {
    const raw = localStorage.getItem(cacheKey(leagueId));
    if (!raw) return undefined;
    const data = JSON.parse(raw) as LiveLeagueData;
    if (!Array.isArray(data.players) || !Array.isArray(data.board) || typeof data.fetchedAt !== "number") return undefined;
    return data;
  } catch {
    return undefined;
  }
}

function writeCache(leagueId: string, data: LiveLeagueData) {
  try {
    localStorage.setItem(cacheKey(leagueId), JSON.stringify(data));
  } catch {
    // storage full or blocked: the live copy still works for this visit
  }
}

export function clearLiveCache() {
  try {
    for (const id of Object.keys(FEEDS)) {
      localStorage.removeItem(cacheKey(id));
      for (const plan of FEEDS[id].plans) localStorage.removeItem(`statline-variant:v1:${id}:${plan.id}`);
    }
  } catch {
    // ignore
  }
}

type Context = {
  entries: Record<string, FeedState>;
  ensure: (leagueId: string) => void;
  refresh: (leagueId: string) => void;
};

const LiveContext = createContext<Context | null>(null);

export function LiveProvider({ children }: { children: ReactNode }) {
  const [entries, setEntries] = useState<Record<string, FeedState>>({});
  const seen = useRef(new Set<string>());
  const inflight = useRef(new Set<string>());

  const run = useCallback(async (leagueId: string, force: boolean) => {
    const feed = FEEDS[leagueId];
    if (!feed || inflight.current.has(leagueId)) return;
    const cached = readCache(leagueId);
    if (!force && cached && Date.now() - cached.fetchedAt < FRESH_MS) {
      setEntries((e) => ({ ...e, [leagueId]: { status: "live", data: cached } }));
      return;
    }
    inflight.current.add(leagueId);
    setEntries((e) => ({ ...e, [leagueId]: { status: "loading", data: e[leagueId]?.data ?? cached } }));
    try {
      const data = await loadLeague(feed);
      writeCache(leagueId, data);
      setEntries((e) => ({ ...e, [leagueId]: { status: "live", data } }));
    } catch (error) {
      const message = describeError(error);
      setEntries((e) => ({
        ...e,
        [leagueId]: cached ? { status: "cached", data: cached, error: message } : { status: "error", error: message },
      }));
    } finally {
      inflight.current.delete(leagueId);
    }
  }, []);

  const ensure = useCallback(
    (leagueId: string) => {
      if (seen.current.has(leagueId)) return;
      seen.current.add(leagueId);
      void run(leagueId, false);
    },
    [run],
  );
  const refresh = useCallback((leagueId: string) => void run(leagueId, true), [run]);

  const value = useMemo(() => ({ entries, ensure, refresh }), [entries, ensure, refresh]);
  return <LiveContext.Provider value={value}>{children}</LiveContext.Provider>;
}

export function useFeed(leagueId: string | null): FeedView {
  const context = useContext(LiveContext);
  if (!context) throw new Error("useFeed needs a LiveProvider");
  const { entries, ensure, refresh } = context;
  const { config, loaded } = useSite();
  const known = leagueId !== null && leagueId in FEEDS;
  // The site owner can switch a league's live feed off; it then shows the sample season.
  // Feeds wait for the site settings so a switched-off league never makes a request.
  const allowed = known && config.features.liveLeagues[leagueId] !== false;

  useEffect(() => {
    if (leagueId && allowed && loaded) ensure(leagueId);
  }, [leagueId, allowed, loaded, ensure]);

  const state: FeedState = !allowed ? { status: "unsupported" } : !loaded ? { status: "loading" } : (entries[leagueId as string] ?? { status: "loading" });
  return { ...state, refresh: () => (leagueId ? refresh(leagueId) : undefined) };
}
