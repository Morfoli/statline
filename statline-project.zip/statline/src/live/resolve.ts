import { fits, points } from "../engine";
import type { League, Slot, Sport } from "../types";
import type { LiveLeagueData } from "./espn";

// Sample clubs for the fantasy lab, built from whatever pool is on the board: a strong club
// takes players near the top at every slot, the needs-work club takes middling players and
// leaves a couple of slots open. Scarcest slots are filled first so nobody is double-booked.
export function buildPresets(sport: Sport, league: League): { contender: string[]; retool: string[] } {
  const eligible = (slot: Slot) =>
    league.players.filter((p) => fits(p, slot)).sort((a, b) => points(sport, b) - points(sport, a));
  const lists = league.slots.map(eligible);
  const order = league.slots.map((_, i) => i).sort((a, b) => lists[a].length - lists[b].length);

  const pick = (rankFor: (poolSize: number, step: number) => number | null): string[] => {
    const taken = new Set<string>();
    const chosen = new Map<number, string>();
    order.forEach((slotIndex, step) => {
      const pool = lists[slotIndex].filter((p) => !taken.has(p.id));
      if (pool.length === 0) return;
      const rank = rankFor(pool.length, step);
      if (rank === null) return;
      const player = pool[Math.min(rank, pool.length - 1)];
      taken.add(player.id);
      chosen.set(slotIndex, player.name);
    });
    return league.slots.flatMap((_, i) => (chosen.has(i) ? [chosen.get(i) as string] : []));
  };

  const spread = [0, 2, 1, 3];
  return {
    contender: pick((size, step) => Math.min(spread[step % spread.length], size - 1)),
    retool: pick((size, step) => (step % 5 === 4 ? null : Math.min(size - 1, Math.floor(size * 0.6) + (step % 3)))),
  };
}

export function resolveLeague(sport: Sport, base: League, data: LiveLeagueData | undefined): League {
  if (!data) return base;
  const draft: League = {
    ...base,
    players: data.players,
    board: data.board,
    contender: [],
    retool: [],
    live: { source: data.source, season: data.season, fetchedAt: data.fetchedAt, count: data.players.length },
  };
  const presets = buildPresets(sport, draft);
  return { ...draft, contender: presets.contender, retool: presets.retool };
}
