import type { BoardRow, Gender, League, Player, Slot, Sport } from "./types";

type Seed = Omit<Player, "id">;

function players(block: string, roleFor: (pos: string) => string, tagsFor: (pos: string) => string[]): Seed[] {
  return block
    .trim()
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line.length > 0 && !line.startsWith("#"))
    .map((line) => {
      const parts = line.split("|").map((part) => part.trim());
      if (parts.length !== 4) throw new Error(`Bad player row: ${line}`);
      const [name, team, pos, rest] = parts;
      const stats: Record<string, number> = {};
      for (const pair of rest.split(/\s+/)) {
        if (!pair) continue;
        const [key, raw] = pair.split("=");
        if (!key || raw === undefined) throw new Error(`Bad stat for ${name}: ${pair}`);
        stats[key] = Number(raw);
        if (Number.isNaN(stats[key])) throw new Error(`Stat is not a number for ${name}: ${pair}`);
      }
      return { name, team, pos, role: roleFor(pos), tags: tagsFor(pos), stats };
    });
}

function league(
  id: string,
  gender: Gender,
  name: string,
  short: string,
  blurb: string,
  boardLabel: string,
  board: BoardRow[],
  slots: Slot[],
  rows: Seed[],
  contender: string[],
  retool: string[],
): League {
  return {
    id,
    gender,
    name,
    short,
    blurb,
    boardLabel,
    board,
    slots,
    contender,
    retool,
    players: rows.map((row) => ({
      ...row,
      id: `${id}-${row.name
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/(^-|-$)/g, "")}`,
    })),
  };
}

const anyRole = () => "player";

const diamondSlots: Slot[] = [
  { id: "c", label: "C", accepts: ["C"] },
  { id: "1b", label: "1B", accepts: ["1B"] },
  { id: "2b", label: "2B", accepts: ["2B"] },
  { id: "3b", label: "3B", accepts: ["3B"] },
  { id: "ss", label: "SS", accepts: ["SS"] },
  { id: "of1", label: "OF", accepts: ["OF"] },
  { id: "of2", label: "OF", accepts: ["OF"] },
  { id: "of3", label: "OF", accepts: ["OF"] },
  { id: "util", label: "UTIL", accepts: ["UTIL"] },
  { id: "sp1", label: "SP", accepts: ["SP"] },
  { id: "sp2", label: "SP", accepts: ["SP"] },
  { id: "rp", label: "RP", accepts: ["RP"] },
];

const skateSlots: Slot[] = [
  { id: "c1", label: "C", accepts: ["C"] },
  { id: "c2", label: "C", accepts: ["C"] },
  { id: "w1", label: "W", accepts: ["W"] },
  { id: "w2", label: "W", accepts: ["W"] },
  { id: "d1", label: "D", accepts: ["D"] },
  { id: "d2", label: "D", accepts: ["D"] },
  { id: "g", label: "G", accepts: ["G"] },
];

const nflSlots: Slot[] = [
  { id: "qb", label: "QB", accepts: ["QB"] },
  { id: "rb1", label: "RB", accepts: ["RB"] },
  { id: "rb2", label: "RB", accepts: ["RB"] },
  { id: "wr1", label: "WR", accepts: ["WR"] },
  { id: "wr2", label: "WR", accepts: ["WR"] },
  { id: "te", label: "TE", accepts: ["TE"] },
  { id: "flex", label: "FLEX", accepts: ["RB", "WR", "TE"] },
];

const wnfcSlots: Slot[] = [
  { id: "qb", label: "QB", accepts: ["QB"] },
  { id: "rb1", label: "RB", accepts: ["RB"] },
  { id: "rb2", label: "RB", accepts: ["RB"] },
  { id: "wr1", label: "WR", accepts: ["WR"] },
  { id: "wr2", label: "WR", accepts: ["WR"] },
  { id: "flex", label: "FLEX", accepts: ["RB", "WR"] },
];

const pitchSlots: Slot[] = [
  { id: "gk", label: "GK", accepts: ["GK"] },
  { id: "d1", label: "D", accepts: ["D"] },
  { id: "d2", label: "D", accepts: ["D"] },
  { id: "m1", label: "M", accepts: ["M"] },
  { id: "m2", label: "M", accepts: ["M"] },
  { id: "f1", label: "F", accepts: ["F"] },
  { id: "f2", label: "F", accepts: ["F"] },
  { id: "flex", label: "FLEX", accepts: ["D", "M", "F"] },
];

const teeSlots: Slot[] = [1, 2, 3, 4, 5, 6].map((n) => ({ id: `p${n}`, label: "P", accepts: ["P"] }));
const tourSlots: Slot[] = [1, 2, 3, 4, 5].map((n) => ({ id: `p${n}`, label: "P", accepts: ["P"] }));

const hoopsSlots: Slot[] = [
  { id: "pg", label: "PG", accepts: ["PG"] },
  { id: "sg", label: "SG", accepts: ["SG"] },
  { id: "sf", label: "SF", accepts: ["SF"] },
  { id: "pf", label: "PF", accepts: ["PF"] },
  { id: "c", label: "C", accepts: ["C"] },
  { id: "g", label: "G", accepts: ["PG", "SG"] },
  { id: "f", label: "F", accepts: ["SF", "PF"] },
  { id: "util", label: "UTIL", accepts: ["PG", "SG", "SF", "PF", "C"] },
];

const volleySlots: Slot[] = [
  { id: "s", label: "S", accepts: ["S"] },
  { id: "oh1", label: "OH", accepts: ["OH"] },
  { id: "oh2", label: "OH", accepts: ["OH"] },
  { id: "mb", label: "MB", accepts: ["MB"] },
  { id: "opp", label: "OPP", accepts: ["OPP"] },
  { id: "l", label: "L", accepts: ["L"] },
];

const laxSlots: Slot[] = [
  { id: "a1", label: "A", accepts: ["A"] },
  { id: "a2", label: "A", accepts: ["A"] },
  { id: "m1", label: "M", accepts: ["M"] },
  { id: "m2", label: "M", accepts: ["M"] },
  { id: "d", label: "D", accepts: ["D"] },
  { id: "g", label: "G", accepts: ["G"] },
];

const rugbySlots: Slot[] = [
  { id: "fh", label: "FH", accepts: ["FH"] },
  { id: "bk1", label: "BK", accepts: ["BK"] },
  { id: "bk2", label: "BK", accepts: ["BK"] },
  { id: "fw1", label: "FW", accepts: ["FW"] },
  { id: "fw2", label: "FW", accepts: ["FW"] },
  { id: "util", label: "UTIL", accepts: ["FH", "BK", "FW"] },
];

function diamondRole(pos: string) {
  return pos === "SP" || pos === "RP" ? "pitcher" : "hitter";
}
function diamondTags(pos: string) {
  if (pos === "SP" || pos === "RP") return [pos];
  if (pos === "DH") return ["UTIL"];
  return [pos, "UTIL"];
}
function skateRole(pos: string) {
  return pos === "G" ? "goalie" : "skater";
}
function skateTags(pos: string) {
  return [pos];
}
function gridRole(pos: string) {
  if (pos === "QB") return "passer";
  if (["LB", "EDGE", "DB", "DL"].includes(pos)) return "defense";
  return "skill";
}
function gridTags(pos: string) {
  if (pos === "QB") return ["QB"];
  if (pos === "RB") return ["RB"];
  if (pos === "WR") return ["WR"];
  if (pos === "TE") return ["TE"];
  return [pos];
}
function footTags(pos: string) {
  if (pos === "W") return ["M", "F"];
  return [pos];
}
function golfTags() {
  return ["P"];
}
function volleyTags(pos: string) {
  return [pos];
}

const hitters = players(
  `
Aaron Judge | NYY | OF | avg=.322 hr=53 rbi=132 r=128 sb=8
Juan Soto | NYM | OF | avg=.288 hr=41 rbi=109 r=128 sb=7
Mookie Betts | LAD | OF | avg=.291 hr=24 rbi=88 r=110 sb=12
Shohei Ohtani | LAD | DH | avg=.301 hr=51 rbi=112 r=130 sb=22
Bobby Witt Jr. | KC | SS | avg=.328 hr=32 rbi=109 r=120 sb=31
Jose Ramirez | CLE | 3B | avg=.279 hr=39 rbi=118 r=112 sb=30
Freddie Freeman | LAD | 1B | avg=.304 hr=22 rbi=90 r=108 sb=8
Ketel Marte | AZ | 2B | avg=.310 hr=36 rbi=95 r=100 sb=6
Adley Rutschman | BAL | C | avg=.258 hr=22 rbi=70 r=78 sb=1
Vladimir Guerrero Jr. | TOR | 1B | avg=.312 hr=30 rbi=98 r=92 sb=2
Elly De La Cruz | CIN | SS | avg=.265 hr=25 rbi=76 r=102 sb=60
Austin Wells | NYY | C | avg=.219 hr=13 rbi=48 r=42 sb=1
Luis Rengifo | LAA | 2B | avg=.248 hr=8 rbi=40 r=50 sb=6
Lane Thomas | CLE | OF | avg=.238 hr=12 rbi=48 r=58 sb=12
Jake McCarthy | AZ | OF | avg=.242 hr=6 rbi=34 r=48 sb=16
`,
  diamondRole,
  diamondTags,
);

const arms = players(
  `
Tarik Skubal | DET | SP | ip=192 era=2.39 k=228 whip=0.91
Paul Skenes | PIT | SP | ip=170 era=2.20 k=198 whip=0.98
Chris Sale | ATL | SP | ip=178 era=2.55 k=214 whip=1.02
Spencer Arrighetti | HOU | SP | ip=148 era=4.62 k=142 whip=1.36
Emmanuel Clase | CLE | RP | ip=68 era=2.85 k=72 whip=1.08 sv=36
Tyler Kinley | COL | RP | ip=52 era=4.40 k=48 whip=1.42 sv=8
`,
  diamondRole,
  diamondTags,
);

export const sports: Sport[] = [
  {
    id: "baseball",
    name: "Baseball",
    accent: "#d6ff4a",
    deck: "Major League Baseball beside the Athletes Unlimited Softball League.",
    views: [
      { id: "hit", label: "Hitters", role: "hitter", columns: [
        { key: "avg", label: "AVG", digits: 3 },
        { key: "hr", label: "HR" },
        { key: "rbi", label: "RBI" },
        { key: "r", label: "R" },
        { key: "sb", label: "SB" },
      ] },
      { id: "pit", label: "Pitchers", role: "pitcher", columns: [
        { key: "ip", label: "IP", digits: 1 },
        { key: "era", label: "ERA", digits: 2 },
        { key: "k", label: "K" },
        { key: "whip", label: "WHIP", digits: 2 },
        { key: "sv", label: "SV" },
      ] },
    ],
    scoring: [
      { key: "hr", weight: 3.2, roles: ["hitter"] },
      { key: "rbi", weight: 0.55, roles: ["hitter"] },
      { key: "r", weight: 0.45, roles: ["hitter"] },
      { key: "sb", weight: 1.8, roles: ["hitter"] },
      { key: "avg", weight: 40, roles: ["hitter"] },
      { key: "k", weight: 0.28, roles: ["pitcher"] },
      { key: "ip", weight: 0.18, roles: ["pitcher"] },
      { key: "sv", weight: 4.5, roles: ["pitcher"] },
      { key: "era", weight: -6, roles: ["pitcher"] },
      { key: "whip", weight: -14, roles: ["pitcher"] },
    ],
    categories: [
      { id: "power", label: "Power", keys: ["hr"], higher: true, role: "hitter" },
      { id: "run", label: "Run production", keys: ["r", "rbi"], higher: true, role: "hitter" },
      { id: "speed", label: "Speed", keys: ["sb"], higher: true, role: "hitter" },
      { id: "avg", label: "Average", keys: ["avg"], higher: true, role: "hitter" },
      { id: "era", label: "Run prevention", keys: ["era"], higher: false, role: "pitcher", require: "ip" },
      { id: "k", label: "Strikeouts", keys: ["k"], higher: true, role: "pitcher", require: "ip" },
      { id: "sv", label: "Saves", keys: ["sv"], higher: true, role: "pitcher" },
    ],
    leagues: [
      league("mlb", "men", "Major League Baseball", "MLB", "A 12-man mixed roster. Hitters and arms are graded against this sample board.", "Standings", [
        { abbr: "LAD", name: "Dodgers", mark: "98-64", line: "NL West" },
        { abbr: "NYY", name: "Yankees", mark: "94-68", line: "AL East" },
        { abbr: "PHI", name: "Phillies", mark: "93-69", line: "NL East" },
        { abbr: "DET", name: "Tigers", mark: "92-70", line: "AL Central" },
        { abbr: "SD", name: "Padres", mark: "90-72", line: "NL West" },
        { abbr: "CLE", name: "Guardians", mark: "88-74", line: "AL Central" },
      ], diamondSlots, [...hitters, ...arms], [
        "Aaron Judge", "Juan Soto", "Mookie Betts", "Shohei Ohtani", "Elly De La Cruz", "Jose Ramirez", "Vladimir Guerrero Jr.", "Ketel Marte", "Adley Rutschman", "Tarik Skubal", "Chris Sale", "Emmanuel Clase",
      ], [
        "Austin Wells", "Vladimir Guerrero Jr.", "Luis Rengifo", "Jose Ramirez", "Elly De La Cruz", "Lane Thomas", "Jake McCarthy", "Shohei Ohtani", "Spencer Arrighetti", "Tyler Kinley",
      ]),
      league("ausl", "women", "Athletes Unlimited Softball", "AUSL", "Pro softball is the women's diamond board. Same roster shape, its own scale.", "Standings", [
        { abbr: "TAL", name: "Talons", mark: "1st", line: "Regular season" },
        { abbr: "BAN", name: "Bandits", mark: "2nd", line: "League-best offense" },
        { abbr: "BLZ", name: "Blaze", mark: "3rd", line: "Rookie class" },
        { abbr: "VOL", name: "Volts", mark: "4th", line: "Garcia's innings" },
      ], diamondSlots, players(`
Morgan Zerkle | BAN | OF | avg=.419 hr=9 rbi=24 r=28 sb=4
Erin Coffel | BAN | SS | avg=.390 hr=6 rbi=28 r=26 sb=2
Skylar Wallace | BAN | 2B | avg=.390 hr=6 rbi=20 r=24 sb=7
Ana Gold | BLZ | 3B | avg=.340 hr=4 rbi=18 r=22 sb=3
Amanda Lorenz | VOL | OF | avg=.308 hr=5 rbi=16 r=20 sb=1
Aubrey Leach | BLZ | 1B | avg=.355 hr=0 rbi=14 r=22 sb=6
Caroline Jacobsen | TAL | OF | avg=.384 hr=3 rbi=16 r=21 sb=2
Korbe Otis | BLZ | OF | avg=.346 hr=2 rbi=12 r=18 sb=1
Danielle Gibson | BAN | DH | avg=.351 hr=3 rbi=21 r=16 sb=0
Jordan Roberts | BAN | C | avg=.286 hr=2 rbi=12 r=10 sb=0
Kelly Torres | BAN | C | avg=.214 hr=0 rbi=6 r=5 sb=0
Hannah Flippen | TAL | 3B | avg=.268 hr=1 rbi=10 r=12 sb=4
Rachel Garcia | VOL | SP | ip=54.2 era=3.84 k=51 whip=1.18
Georgina Corrick | TAL | SP | ip=48 era=1.72 k=62 whip=0.94
Montana Fouts | TAL | SP | ip=42 era=2.40 k=48 whip=1.08
Odicci Alexander | BAN | RP | ip=28 era=2.10 k=24 whip=1.12 sv=6
Sarah Willis | BAN | RP | ip=22 era=4.90 k=12 whip=1.55 sv=1
`, diamondRole, diamondTags), [
        "Morgan Zerkle", "Erin Coffel", "Skylar Wallace", "Ana Gold", "Amanda Lorenz", "Danielle Gibson", "Caroline Jacobsen", "Hannah Flippen", "Jordan Roberts", "Georgina Corrick", "Montana Fouts", "Odicci Alexander", "Aubrey Leach",
      ], [
        "Kelly Torres", "Aubrey Leach", "Hannah Flippen", "Ana Gold", "Korbe Otis", "Amanda Lorenz", "Danielle Gibson", "Sarah Willis",
      ]),
    ],
  },
  {
    id: "hockey",
    name: "Hockey",
    accent: "#9fd4ff",
    deck: "The NHL and the PWHL. Skaters and goalies share one desk.",
    views: [
      { id: "sk", label: "Skaters", role: "skater", columns: [
        { key: "g", label: "G" },
        { key: "a", label: "A" },
        { key: "pts", label: "PTS" },
        { key: "sog", label: "SOG" },
        { key: "blk", label: "BLK" },
      ] },
      { id: "g", label: "Goalies", role: "goalie", columns: [
        { key: "w", label: "W" },
        { key: "svpct", label: "SV%", digits: 3 },
        { key: "gaa", label: "GAA", digits: 2 },
        { key: "so", label: "SO" },
      ] },
    ],
    scoring: [
      { key: "g", weight: 3, roles: ["skater"] },
      { key: "a", weight: 2, roles: ["skater"] },
      { key: "sog", weight: 0.25, roles: ["skater"] },
      { key: "blk", weight: 0.35, roles: ["skater"] },
      { key: "w", weight: 2.4, roles: ["goalie"] },
      { key: "svpct", weight: 80, roles: ["goalie"] },
      { key: "gaa", weight: -8, roles: ["goalie"] },
      { key: "so", weight: 3, roles: ["goalie"] },
    ],
    categories: [
      { id: "g", label: "Goals", keys: ["g"], higher: true, role: "skater" },
      { id: "a", label: "Playmaking", keys: ["a"], higher: true, role: "skater" },
      { id: "sog", label: "Shot volume", keys: ["sog"], higher: true, role: "skater" },
      { id: "blk", label: "Blocks", keys: ["blk"], higher: true, role: "skater" },
      { id: "sv", label: "Save percentage", keys: ["svpct"], higher: true, role: "goalie" },
      { id: "gaa", label: "Goals against", keys: ["gaa"], higher: false, role: "goalie" },
    ],
    leagues: [
      league("nhl", "men", "National Hockey League", "NHL", "Two centers, two wings, two defenders, one goalie.", "Standings", [
        { abbr: "DAL", name: "Stars", mark: "112 pts", line: "Central" },
        { abbr: "EDM", name: "Oilers", mark: "108 pts", line: "Pacific" },
        { abbr: "COL", name: "Avalanche", mark: "106 pts", line: "Central" },
        { abbr: "FLA", name: "Panthers", mark: "104 pts", line: "Atlantic" },
        { abbr: "CAR", name: "Hurricanes", mark: "102 pts", line: "Metropolitan" },
        { abbr: "WPG", name: "Jets", mark: "100 pts", line: "Central" },
      ], skateSlots, players(`
Connor McDavid | EDM | C | g=38 a=74 pts=112 sog=260 blk=18
Nathan MacKinnon | COL | C | g=42 a=68 pts=110 sog=310 blk=22
Auston Matthews | TOR | C | g=48 a=42 pts=90 sog=290 blk=30
Nikita Kucherov | TBL | W | g=36 a=84 pts=120 sog=250 blk=16
Mikko Rantanen | DAL | W | g=34 a=70 pts=104 sog=230 blk=28
David Pastrnak | BOS | W | g=40 a=52 pts=92 sog=300 blk=14
Cale Makar | COL | D | g=28 a=68 pts=96 sog=240 blk=90
Quinn Hughes | VAN | D | g=16 a=76 pts=92 sog=190 blk=70
Connor Brown | EDM | W | g=12 a=16 pts=28 sog=110 blk=20
Nick Cousins | OTT | C | g=9 a=14 pts=23 sog=90 blk=24
Adam Larsson | SEA | D | g=4 a=16 pts=20 sog=80 blk=140
Connor Hellebuyck | WPG | G | w=38 svpct=.925 gaa=2.25 so=6
Igor Shesterkin | NYR | G | w=32 svpct=.918 gaa=2.48 so=4
Alex Lyon | DET | G | w=14 svpct=.892 gaa=3.35 so=0
`, skateRole, skateTags), [
        "Connor McDavid", "Nathan MacKinnon", "Nikita Kucherov", "Mikko Rantanen", "Cale Makar", "Quinn Hughes", "Connor Hellebuyck",
      ], [
        "Nick Cousins", "Connor Brown", "Adam Larsson", "Nathan MacKinnon", "Alex Lyon",
      ]),
      league("pwhl", "women", "Professional Women's Hockey League", "PWHL", "Same seven-spot build as the NHL board, on the women's scale.", "Standings", [
        { abbr: "MTL", name: "Victoire", mark: "Top seed", line: "Poulin's line" },
        { abbr: "MIN", name: "Frost", mark: "2nd", line: "Heise and Knight's orbit" },
        { abbr: "TOR", name: "Sceptres", mark: "3rd", line: "Nurse and Spooner" },
        { abbr: "BOS", name: "Fleet", mark: "4th", line: "Frankel in net" },
        { abbr: "OTT", name: "Charge", mark: "5th", line: "Hughes up front" },
        { abbr: "NY", name: "Sirens", mark: "6th", line: "Shelton on the blue line" },
      ], skateSlots, players(`
Marie-Philip Poulin | MTL | C | g=16 a=22 pts=38 sog=110 blk=20
Taylor Heise | MIN | C | g=14 a=20 pts=34 sog=120 blk=18
Hilary Knight | BOS | W | g=15 a=16 pts=31 sog=100 blk=12
Sarah Nurse | TOR | W | g=12 a=18 pts=30 sog=95 blk=14
Kendall Coyne Schofield | MIN | W | g=11 a=14 pts=25 sog=90 blk=10
Natalie Spooner | TOR | C | g=13 a=12 pts=25 sog=88 blk=16
Renata Fast | TOR | D | g=4 a=18 pts=22 sog=70 blk=80
Ella Shelton | NY | D | g=6 a=14 pts=20 sog=85 blk=70
Gabbie Hughes | OTT | W | g=6 a=8 pts=14 sog=60 blk=8
Marie-Jo Pelletier | OTT | C | g=3 a=6 pts=9 sog=40 blk=10
Alexie Guay | NY | D | g=1 a=6 pts=7 sog=30 blk=40
Ann-Renee Desbiens | MTL | G | w=16 svpct=.940 gaa=1.85 so=4
Aerin Frankel | BOS | G | w=14 svpct=.933 gaa=1.98 so=3
Corinne Schroeder | NY | G | w=6 svpct=.900 gaa=3.10 so=0
`, skateRole, skateTags), [
        "Marie-Philip Poulin", "Taylor Heise", "Hilary Knight", "Sarah Nurse", "Renata Fast", "Ella Shelton", "Ann-Renee Desbiens",
      ], [
        "Marie-Jo Pelletier", "Gabbie Hughes", "Alexie Guay", "Hilary Knight", "Corinne Schroeder",
      ]),
    ],
  },
  {
    id: "football",
    name: "Football",
    accent: "#ff7a45",
    deck: "The NFL and the Women's National Football Conference.",
    views: [
      { id: "qb", label: "Quarterbacks", role: "passer", columns: [
        { key: "passYd", label: "YDS" },
        { key: "passTd", label: "TD" },
        { key: "int", label: "INT" },
        { key: "rushYd", label: "RUSH" },
        { key: "rushTd", label: "RTD" },
      ] },
      { id: "sk", label: "Skill", role: "skill", columns: [
        { key: "rushYd", label: "RUSH" },
        { key: "rushTd", label: "RTD" },
        { key: "rec", label: "REC" },
        { key: "recYd", label: "YDS" },
        { key: "recTd", label: "TD" },
      ] },
      { id: "def", label: "Defense", role: "defense", columns: [
        { key: "tkl", label: "TKL" },
        { key: "tfl", label: "TFL" },
        { key: "sack", label: "SACK", digits: 1 },
        { key: "int", label: "INT" },
        { key: "ff", label: "FF" },
      ] },
    ],
    scoring: [
      { key: "passYd", weight: 0.04, roles: ["passer"] },
      { key: "passTd", weight: 4, roles: ["passer"] },
      { key: "int", weight: -2, roles: ["passer"] },
      { key: "rushYd", weight: 0.1, roles: ["passer", "skill"] },
      { key: "rushTd", weight: 6, roles: ["passer", "skill"] },
      { key: "rec", weight: 0.5, roles: ["skill"] },
      { key: "recYd", weight: 0.1, roles: ["skill"] },
      { key: "recTd", weight: 6, roles: ["skill"] },
    ],
    categories: [
      { id: "pass", label: "Passing", keys: ["passYd", "passTd"], higher: true, role: "passer" },
      { id: "rush", label: "Rushing", keys: ["rushYd", "rushTd"], higher: true },
      { id: "rec", label: "Receiving", keys: ["recYd", "recTd"], higher: true, role: "skill" },
      { id: "care", label: "Ball security", keys: ["int"], higher: false, role: "passer" },
    ],
    leagues: [
      league("nfl", "men", "National Football League", "NFL", "One quarterback, two backs, two receivers, a tight end, and a flex. Defense is scouted here and left off the fantasy roster.", "Standings", [
        { abbr: "KC", name: "Chiefs", mark: "15-2", line: "AFC West" },
        { abbr: "DET", name: "Lions", mark: "14-3", line: "NFC North" },
        { abbr: "PHI", name: "Eagles", mark: "14-3", line: "NFC East" },
        { abbr: "BUF", name: "Bills", mark: "13-4", line: "AFC East" },
        { abbr: "BAL", name: "Ravens", mark: "12-5", line: "AFC North" },
        { abbr: "SF", name: "49ers", mark: "11-6", line: "NFC West" },
      ], nflSlots, players(`
Patrick Mahomes | KC | QB | passYd=4280 passTd=36 int=10 rushYd=380 rushTd=4
Josh Allen | BUF | QB | passYd=3900 passTd=32 int=8 rushYd=620 rushTd=8
Jalen Hurts | PHI | QB | passYd=3600 passTd=26 int=9 rushYd=580 rushTd=12
Mac Jones | JAX | QB | passYd=2800 passTd=14 int=12 rushYd=90 rushTd=0
Christian McCaffrey | SF | RB | rushYd=1450 rushTd=14 rec=70 recYd=620 recTd=4
Derrick Henry | BAL | RB | rushYd=1680 rushTd=16 rec=22 recYd=180 recTd=1
Saquon Barkley | PHI | RB | rushYd=1600 rushTd=13 rec=40 recYd=320 recTd=2
Ty Chandler | MIN | RB | rushYd=420 rushTd=2 rec=18 recYd=110 recTd=0
Justin Jefferson | MIN | WR | rec=108 recYd=1620 recTd=10
Ja'Marr Chase | CIN | WR | rec=110 recYd=1580 recTd=14
CeeDee Lamb | DAL | WR | rec=120 recYd=1540 recTd=9
Amon-Ra St. Brown | DET | WR | rec=115 recYd=1320 recTd=10
Josh Reynolds | DEN | WR | rec=42 recYd=480 recTd=2
Travis Kelce | KC | TE | rec=90 recYd=1020 recTd=8
Noah Fant | SEA | TE | rec=36 recYd=340 recTd=1
Myles Garrett | CLE | EDGE | tkl=42 tfl=18 sack=16 int=0 ff=4
Micah Parsons | GB | EDGE | tkl=48 tfl=16 sack=13 int=1 ff=3
Patrick Surtain II | DEN | DB | tkl=52 tfl=6 sack=1 int=4 ff=1
Fred Warner | SF | LB | tkl=130 tfl=12 sack=3 int=2 ff=2
`, gridRole, gridTags), [
        "Josh Allen", "Christian McCaffrey", "Saquon Barkley", "Justin Jefferson", "Ja'Marr Chase", "Travis Kelce", "CeeDee Lamb",
      ], [
        "Mac Jones", "Ty Chandler", "Saquon Barkley", "Josh Reynolds", "Amon-Ra St. Brown", "Noah Fant",
      ]),
      league("wnfc", "women", "Women's National Football Conference", "WNFC", "Tackle football on a shorter season. The roster is quarterback, two backs, two receivers, and a flex.", "Board", [
        { abbr: "CHI", name: "Winds", mark: "MVP club", line: "Teubner and Miles" },
        { abbr: "SD", name: "Rebellion", mark: "OPOY", line: "Wesley" },
        { abbr: "LA", name: "Legends", mark: "Rush rank", line: "Gamble" },
        { abbr: "WAS", name: "Prodigy", mark: "Ballhawks", line: "Somerville" },
        { abbr: "ORE", name: "Ravens", mark: "Edge", line: "Greer" },
        { abbr: "KC", name: "Glory", mark: "Defense", line: "Snowden" },
      ], wnfcSlots, players(`
Sarah Teubner | CHI | QB | passYd=1008 passTd=18 int=4 rushYd=80 rushTd=1
Karen Mulligan | JSW | QB | passYd=640 passTd=8 int=6 rushYd=40 rushTd=0
Michelle Angel | TEX | QB | passYd=420 passTd=4 int=5 rushYd=30 rushTd=0
Kesz Wesley | SD | RB | rushYd=620 rushTd=8 rec=18 recYd=160 recTd=1
Jazmin Gamble | LA | RB | rushYd=549 rushTd=6 rec=12 recYd=90 recTd=0
Morgan Alston | CHI | RB | rushYd=210 rushTd=1 rec=8 recYd=40 recTd=0
Dajour Miles | CHI | WR | rec=28 recYd=456 recTd=11
Summer McNeal | TEX | WR | rec=22 recYd=310 recTd=4
Madison Grayson | JSW | WR | rec=14 recYd=160 recTd=1
Madeline Violette | CHI | LB | tkl=83 tfl=5 sack=0 int=2 ff=1
Alexis Greer | ORE | EDGE | tkl=28 tfl=8 sack=5.5 int=0 ff=2
Myla Somerville | WAS | DB | tkl=36 tfl=2 sack=0 int=6 ff=0
`, gridRole, gridTags), [
        "Sarah Teubner", "Kesz Wesley", "Jazmin Gamble", "Dajour Miles", "Summer McNeal", "Madison Grayson",
      ], [
        "Michelle Angel", "Morgan Alston", "Kesz Wesley", "Madison Grayson",
      ]),
    ],
  },
  {
    id: "soccer",
    name: "Soccer",
    accent: "#9ee37d",
    deck: "The Premier League and the NWSL.",
    views: [
      { id: "all", label: "Field", columns: [
        { key: "g", label: "G" },
        { key: "a", label: "A" },
        { key: "sot", label: "SOT" },
        { key: "cs", label: "CS" },
        { key: "sv", label: "SV" },
        { key: "gc", label: "GC" },
      ] },
    ],
    scoring: [
      { key: "g", weight: 6 },
      { key: "a", weight: 4 },
      { key: "sot", weight: 0.45 },
      { key: "cs", weight: 4 },
      { key: "sv", weight: 0.35 },
      { key: "gc", weight: -0.6 },
    ],
    categories: [
      { id: "g", label: "Goals", keys: ["g"], higher: true },
      { id: "a", label: "Creation", keys: ["a"], higher: true },
      { id: "sot", label: "Shots on target", keys: ["sot"], higher: true },
      { id: "cs", label: "Clean sheets", keys: ["cs"], higher: true },
      { id: "sv", label: "Saves", keys: ["sv"], higher: true },
    ],
    leagues: [
      league("epl", "men", "Premier League", "Premier League", "A goalkeeper, two defenders, two midfielders, two forwards, and a flex.", "Table", [
        { abbr: "LIV", name: "Liverpool", mark: "78 pts", line: "Title race" },
        { abbr: "ARS", name: "Arsenal", mark: "74 pts", line: "Title race" },
        { abbr: "MCI", name: "Man City", mark: "72 pts", line: "Haaland" },
        { abbr: "CHE", name: "Chelsea", mark: "64 pts", line: "Palmer" },
        { abbr: "AVL", name: "Aston Villa", mark: "58 pts", line: "Watkins" },
        { abbr: "NEW", name: "Newcastle", mark: "56 pts", line: "European place" },
      ], pitchSlots, players(`
Erling Haaland | MCI | F | g=28 a=6 sot=62 cs=0 sv=0 gc=0
Mohamed Salah | LIV | W | g=22 a=16 sot=48 cs=0 sv=0 gc=0
Alexander Isak | LIV | F | g=20 a=5 sot=40 cs=0 sv=0 gc=0
Ollie Watkins | AVL | F | g=14 a=8 sot=32 cs=0 sv=0 gc=0
Bukayo Saka | ARS | W | g=12 a=14 sot=36 cs=0 sv=0 gc=0
Cole Palmer | CHE | M | g=16 a=12 sot=38 cs=0 sv=0 gc=0
Rodri | MCI | M | g=6 a=9 sot=14 cs=0 sv=0 gc=0
Declan Rice | ARS | M | g=7 a=8 sot=16 cs=0 sv=0 gc=0
Philip Billing | NAP | M | g=2 a=3 sot=8 cs=0 sv=0 gc=0
Virgil van Dijk | LIV | D | g=3 a=2 sot=8 cs=16 sv=0 gc=22
Gabriel | ARS | D | g=4 a=1 sot=10 cs=15 sv=0 gc=24
Tyrick Mitchell | CRY | D | g=0 a=2 sot=2 cs=6 sv=0 gc=40
David Raya | ARS | GK | g=0 a=0 sot=0 cs=15 sv=92 gc=26
Alphonse Areola | WHU | GK | g=0 a=0 sot=0 cs=6 sv=70 gc=48
`, anyRole, footTags), [
        "Erling Haaland", "Mohamed Salah", "Alexander Isak", "Bukayo Saka", "Cole Palmer", "Rodri", "Virgil van Dijk", "David Raya", "Gabriel",
      ], [
        "Ollie Watkins", "Philip Billing", "Tyrick Mitchell", "Alphonse Areola", "Declan Rice",
      ]),
      league("nwsl", "women", "National Women's Soccer League", "NWSL", "Same shape as the Premier League board.", "Table", [
        { abbr: "ORL", name: "Pride", mark: "Top", line: "Banda" },
        { abbr: "KC", name: "Current", mark: "2nd", line: "Chawinga" },
        { abbr: "WAS", name: "Spirit", mark: "3rd", line: "Rodman" },
        { abbr: "POR", name: "Thorns", mark: "4th", line: "Smith" },
        { abbr: "SD", name: "Wave", mark: "5th", line: "Girma" },
        { abbr: "CHI", name: "Red Stars", mark: "6th", line: "Naeher" },
      ], pitchSlots, players(`
Barbra Banda | ORL | F | g=16 a=5 sot=40 cs=0 sv=0 gc=0
Temwa Chawinga | KC | F | g=18 a=6 sot=42 cs=0 sv=0 gc=0
Sophia Smith | POR | F | g=14 a=7 sot=34 cs=0 sv=0 gc=0
Trinity Rodman | WAS | W | g=10 a=8 sot=28 cs=0 sv=0 gc=0
Mallory Swanson | CHI | W | g=11 a=6 sot=26 cs=0 sv=0 gc=0
Alyssa Thompson | ANG | W | g=6 a=4 sot=18 cs=0 sv=0 gc=0
Rose Lavelle | GFC | M | g=4 a=8 sot=12 cs=0 sv=0 gc=0
Naomi Girma | SD | D | g=1 a=2 sot=3 cs=10 sv=0 gc=18
Emily Sonnett | GFC | D | g=1 a=1 sot=2 cs=7 sv=0 gc=28
Abby Dahlkemper | SD | D | g=0 a=0 sot=1 cs=4 sv=0 gc=32
Alyssa Naeher | CHI | GK | g=0 a=0 sot=0 cs=9 sv=70 gc=22
Phallon Tullis-Joyce | POR | GK | g=0 a=1 sot=0 cs=5 sv=48 gc=30
Casey Murphy | NC | GK | g=0 a=0 sot=0 cs=3 sv=40 gc=36
`, anyRole, footTags), [
        "Barbra Banda", "Temwa Chawinga", "Sophia Smith", "Trinity Rodman", "Rose Lavelle", "Mallory Swanson", "Naomi Girma", "Alyssa Naeher", "Emily Sonnett",
      ], [
        "Alyssa Thompson", "Emily Sonnett", "Abby Dahlkemper", "Casey Murphy", "Rose Lavelle",
      ]),
    ],
  },
  {
    id: "golf",
    name: "Golf",
    accent: "#e4d2a8",
    deck: "The PGA Tour and the LPGA. A club is six golfers, no positions.",
    views: [
      { id: "all", label: "Board", columns: [
        { key: "score", label: "AVG", digits: 2 },
        { key: "birdies", label: "BIR" },
        { key: "gir", label: "GIR%" },
        { key: "top10", label: "TOP 10" },
        { key: "cuts", label: "CUTS" },
      ] },
    ],
    scoring: [
      { key: "under", weight: 8 },
      { key: "birdies", weight: 0.15 },
      { key: "gir", weight: 0.2 },
      { key: "top10", weight: 3.5 },
      { key: "cuts", weight: 1.1 },
    ],
    categories: [
      { id: "score", label: "Scoring average", keys: ["score"], higher: false },
      { id: "birdies", label: "Birdies", keys: ["birdies"], higher: true },
      { id: "gir", label: "Greens in regulation", keys: ["gir"], higher: true },
      { id: "top10", label: "Top 10s", keys: ["top10"], higher: true },
      { id: "cuts", label: "Cuts made", keys: ["cuts"], higher: true },
    ],
    leagues: [
      league("pga", "men", "PGA Tour", "PGA Tour", "Six starters. Lower scoring average is better, and the memo says so.", "Form", [
        { abbr: "1", name: "Scottie Scheffler", mark: "68.4", line: "Scoring average" },
        { abbr: "2", name: "Xander Schauffele", mark: "69.1", line: "Scoring average" },
        { abbr: "3", name: "Rory McIlroy", mark: "69.3", line: "Scoring average" },
        { abbr: "4", name: "Ludvig Aberg", mark: "69.5", line: "Scoring average" },
      ], teeSlots, players(`
Scottie Scheffler | PGA | P | score=68.40 under=11.6 birdies=320 gir=73 top10=14 cuts=20
Xander Schauffele | PGA | P | score=69.10 under=10.9 birdies=300 gir=70 top10=11 cuts=20
Rory McIlroy | PGA | P | score=69.30 under=10.7 birdies=290 gir=68 top10=10 cuts=18
Ludvig Aberg | PGA | P | score=69.50 under=10.5 birdies=270 gir=71 top10=9 cuts=19
Collin Morikawa | PGA | P | score=69.70 under=10.3 birdies=260 gir=72 top10=8 cuts=19
Jon Rahm | PGA | P | score=69.80 under=10.2 birdies=250 gir=69 top10=8 cuts=17
Wyndham Clark | PGA | P | score=70.40 under=9.6 birdies=240 gir=66 top10=5 cuts=17
Cameron Young | PGA | P | score=70.80 under=9.2 birdies=220 gir=64 top10=4 cuts=16
Adam Schenk | PGA | P | score=71.60 under=8.4 birdies=180 gir=62 top10=1 cuts=13
Taylor Pendrith | PGA | P | score=71.90 under=8.1 birdies=170 gir=61 top10=1 cuts=12
`, anyRole, golfTags), [
        "Scottie Scheffler", "Xander Schauffele", "Rory McIlroy", "Ludvig Aberg", "Collin Morikawa", "Jon Rahm",
      ], [
        "Adam Schenk", "Taylor Pendrith", "Cameron Young", "Wyndham Clark", "Scottie Scheffler",
      ]),
      league("lpga", "women", "LPGA", "LPGA", "Six starters. The women's board is graded on its own scoring scale.", "Form", [
        { abbr: "1", name: "Nelly Korda", mark: "69.2", line: "Scoring average" },
        { abbr: "2", name: "Lydia Ko", mark: "69.6", line: "Scoring average" },
        { abbr: "3", name: "Jin Young Ko", mark: "69.7", line: "Scoring average" },
        { abbr: "4", name: "Rose Zhang", mark: "69.9", line: "Scoring average" },
      ], teeSlots, players(`
Nelly Korda | LPGA | P | score=69.20 under=10.8 birdies=280 gir=74 top10=12 cuts=18
Lydia Ko | LPGA | P | score=69.60 under=10.4 birdies=260 gir=72 top10=10 cuts=18
Jin Young Ko | LPGA | P | score=69.70 under=10.3 birdies=250 gir=73 top10=9 cuts=17
Rose Zhang | LPGA | P | score=69.90 under=10.1 birdies=240 gir=70 top10=8 cuts=17
Lilia Vu | LPGA | P | score=70.10 under=9.9 birdies=230 gir=69 top10=7 cuts=16
Hannah Green | LPGA | P | score=70.30 under=9.7 birdies=220 gir=68 top10=6 cuts=16
Charley Hull | LPGA | P | score=70.50 under=9.5 birdies=230 gir=66 top10=6 cuts=15
Atthaya Thitikul | LPGA | P | score=70.70 under=9.3 birdies=210 gir=67 top10=5 cuts=15
Megan Khang | LPGA | P | score=71.40 under=8.6 birdies=180 gir=64 top10=2 cuts=14
Sarah Schmelzel | LPGA | P | score=72.10 under=7.9 birdies=150 gir=60 top10=0 cuts=11
`, anyRole, golfTags), [
        "Nelly Korda", "Lydia Ko", "Jin Young Ko", "Rose Zhang", "Lilia Vu", "Hannah Green",
      ], [
        "Sarah Schmelzel", "Megan Khang", "Atthaya Thitikul", "Nelly Korda",
      ]),
    ],
  },
  {
    id: "basketball",
    name: "Basketball",
    accent: "#ffb020",
    deck: "The NBA and the WNBA.",
    views: [
      { id: "all", label: "Players", columns: [
        { key: "pts", label: "PTS", digits: 1 },
        { key: "reb", label: "REB", digits: 1 },
        { key: "ast", label: "AST", digits: 1 },
        { key: "stl", label: "STL", digits: 1 },
        { key: "blk", label: "BLK", digits: 1 },
        { key: "tov", label: "TOV", digits: 1 },
        { key: "fg", label: "FG%", digits: 1 },
      ] },
    ],
    scoring: [
      { key: "pts", weight: 1 },
      { key: "reb", weight: 1.2 },
      { key: "ast", weight: 1.5 },
      { key: "stl", weight: 3 },
      { key: "blk", weight: 3 },
      { key: "tov", weight: -1.4 },
      { key: "fg", weight: 0.15 },
    ],
    categories: [
      { id: "pts", label: "Scoring", keys: ["pts"], higher: true },
      { id: "reb", label: "Rebounding", keys: ["reb"], higher: true },
      { id: "ast", label: "Playmaking", keys: ["ast"], higher: true },
      { id: "stocks", label: "Steals and blocks", keys: ["stl", "blk"], higher: true },
      { id: "tov", label: "Ball security", keys: ["tov"], higher: false },
    ],
    leagues: [
      league("nba", "men", "National Basketball Association", "NBA", "A full eight-man lineup: five positions, a guard, a forward, and a utility.", "Standings", [
        { abbr: "OKC", name: "Thunder", mark: "62-20", line: "West" },
        { abbr: "BOS", name: "Celtics", mark: "58-24", line: "East" },
        { abbr: "CLE", name: "Cavaliers", mark: "56-26", line: "East" },
        { abbr: "DEN", name: "Nuggets", mark: "54-28", line: "West" },
        { abbr: "NYK", name: "Knicks", mark: "52-30", line: "East" },
        { abbr: "MIN", name: "Timberwolves", mark: "50-32", line: "West" },
      ], hoopsSlots, players(`
Nikola Jokic | DEN | C | pts=29.6 reb=12.8 ast=10.2 stl=1.4 blk=0.8 tov=3.2 fg=58.2
Shai Gilgeous-Alexander | OKC | PG | pts=32.4 reb=5.4 ast=6.4 stl=1.8 blk=1.0 tov=2.4 fg=52.8
Luka Doncic | LAL | PG | pts=28.2 reb=8.2 ast=8.0 stl=1.3 blk=0.5 tov=3.6 fg=47.8
Jayson Tatum | BOS | SF | pts=27.4 reb=8.6 ast=5.2 stl=1.1 blk=0.6 tov=2.6 fg=46.5
Giannis Antetokounmpo | MIL | PF | pts=30.2 reb=11.6 ast=6.2 stl=1.2 blk=1.2 tov=3.4 fg=60.4
Anthony Edwards | MIN | SG | pts=27.8 reb=5.6 ast=4.6 stl=1.3 blk=0.6 tov=2.8 fg=45.2
Jalen Brunson | NYK | PG | pts=26.8 reb=3.4 ast=7.4 stl=0.9 blk=0.2 tov=2.2 fg=48.0
Victor Wembanyama | SAS | C | pts=24.2 reb=11.0 ast=3.8 stl=1.2 blk=3.6 tov=3.0 fg=48.4
Jaylen Brown | BOS | SF | pts=23.4 reb=5.8 ast=4.2 stl=1.2 blk=0.4 tov=2.4 fg=48.2
Franz Wagner | ORL | SF | pts=24.0 reb=5.6 ast=5.0 stl=1.1 blk=0.4 tov=2.2 fg=47.0
Paolo Banchero | ORL | PF | pts=25.6 reb=7.4 ast=4.8 stl=0.9 blk=0.6 tov=3.0 fg=45.5
Clint Capela | ATL | C | pts=11.2 reb=9.6 ast=1.0 stl=0.6 blk=1.1 tov=1.2 fg=58.0
Cole Anthony | ORL | PG | pts=11.4 reb=3.6 ast=3.2 stl=0.8 blk=0.3 tov=1.8 fg=42.5
Buddy Hield | GSW | SG | pts=12.2 reb=3.2 ast=1.8 stl=0.7 blk=0.2 tov=1.2 fg=41.0
`, anyRole, (pos) => {
        if (pos === "PG") return ["PG", "G"];
        if (pos === "SG") return ["SG", "G"];
        if (pos === "SF") return ["SF", "F"];
        if (pos === "PF") return ["PF", "F"];
        return ["C"];
      }), [
        "Shai Gilgeous-Alexander", "Anthony Edwards", "Jayson Tatum", "Giannis Antetokounmpo", "Nikola Jokic", "Luka Doncic", "Paolo Banchero", "Victor Wembanyama",
      ], [
        "Cole Anthony", "Buddy Hield", "Franz Wagner", "Paolo Banchero", "Clint Capela", "Nikola Jokic",
      ]),
      league("wnba", "women", "Women's National Basketball Association", "WNBA", "Same eight-spot lineup. Grades stay inside the WNBA board.", "Standings", [
        { abbr: "LV", name: "Aces", mark: "Top", line: "Wilson" },
        { abbr: "NY", name: "Liberty", mark: "2nd", line: "Stewart and Ionescu" },
        { abbr: "MIN", name: "Lynx", mark: "3rd", line: "Collier" },
        { abbr: "IND", name: "Fever", mark: "4th", line: "Clark" },
        { abbr: "PHX", name: "Mercury", mark: "5th", line: "Thomas" },
        { abbr: "SEA", name: "Storm", mark: "6th", line: "Nneka" },
      ], hoopsSlots, players(`
A'ja Wilson | LV | C | pts=26.4 reb=11.8 ast=2.4 stl=1.6 blk=2.4 tov=1.8 fg=52.0
Breanna Stewart | NY | PF | pts=20.8 reb=8.4 ast=3.6 stl=1.4 blk=1.4 tov=2.0 fg=47.5
Napheesa Collier | MIN | PF | pts=22.2 reb=8.8 ast=3.4 stl=1.6 blk=1.2 tov=2.2 fg=49.0
Caitlin Clark | IND | PG | pts=19.2 reb=5.6 ast=8.8 stl=1.3 blk=0.6 tov=5.4 fg=42.8
Sabrina Ionescu | NY | PG | pts=18.4 reb=4.6 ast=6.2 stl=1.0 blk=0.3 tov=2.6 fg=44.2
Aliyah Boston | IND | C | pts=15.6 reb=9.4 ast=3.2 stl=1.0 blk=1.4 tov=1.8 fg=54.0
Jackie Young | LV | SG | pts=16.8 reb=4.0 ast=4.8 stl=1.2 blk=0.3 tov=1.6 fg=48.5
Alyssa Thomas | PHX | SF | pts=14.2 reb=8.6 ast=7.8 stl=1.6 blk=0.4 tov=2.8 fg=48.8
Arike Ogunbowale | DAL | SG | pts=21.4 reb=2.8 ast=4.4 stl=1.2 blk=0.2 tov=2.6 fg=40.5
Kelsey Mitchell | IND | SG | pts=16.2 reb=2.2 ast=2.4 stl=0.7 blk=0.1 tov=1.6 fg=45.0
Dearica Hamby | LA | PF | pts=14.8 reb=8.2 ast=2.6 stl=1.0 blk=0.4 tov=2.0 fg=50.2
Nneka Ogwumike | SEA | PF | pts=13.4 reb=6.8 ast=2.2 stl=1.1 blk=0.4 tov=1.4 fg=52.4
Crystal Dangerfield | CON | PG | pts=6.4 reb=1.8 ast=2.6 stl=0.5 blk=0.1 tov=1.4 fg=38.0
NaLyssa Smith | LA | PF | pts=8.8 reb=5.4 ast=1.2 stl=0.6 blk=0.4 tov=1.4 fg=46.0
`, anyRole, (pos) => {
        if (pos === "PG") return ["PG", "G"];
        if (pos === "SG") return ["SG", "G"];
        if (pos === "SF") return ["SF", "F"];
        if (pos === "PF") return ["PF", "F"];
        return ["C"];
      }), [
        "Caitlin Clark", "Jackie Young", "Alyssa Thomas", "Breanna Stewart", "A'ja Wilson", "Sabrina Ionescu", "Napheesa Collier", "Aliyah Boston",
      ], [
        "Crystal Dangerfield", "Kelsey Mitchell", "NaLyssa Smith", "Dearica Hamby", "Aliyah Boston", "A'ja Wilson",
      ]),
    ],
  },
  {
    id: "tennis",
    name: "Tennis",
    accent: "#d2b4ff",
    deck: "The ATP and the WTA. A club is five players.",
    views: [
      { id: "all", label: "Board", columns: [
        { key: "rank", label: "RANK" },
        { key: "win", label: "WIN%" },
        { key: "aces", label: "ACES" },
        { key: "titles", label: "TITLES" },
      ] },
    ],
    scoring: [
      { key: "rank", weight: -0.7 },
      { key: "win", weight: 0.9 },
      { key: "aces", weight: 0.08 },
      { key: "titles", weight: 7 },
    ],
    categories: [
      { id: "rank", label: "Ranking", keys: ["rank"], higher: false },
      { id: "win", label: "Win rate", keys: ["win"], higher: true },
      { id: "aces", label: "Serve", keys: ["aces"], higher: true },
      { id: "titles", label: "Titles", keys: ["titles"], higher: true },
    ],
    leagues: [
      league("atp", "men", "ATP Tour", "ATP", "Five-player stable. Ranking is read so that No. 1 beats No. 40.", "Race", [
        { abbr: "1", name: "Jannik Sinner", mark: "No. 1", line: "Sample race" },
        { abbr: "2", name: "Carlos Alcaraz", mark: "No. 2", line: "Sample race" },
        { abbr: "3", name: "Novak Djokovic", mark: "No. 4", line: "Sample race" },
        { abbr: "4", name: "Alexander Zverev", mark: "No. 3", line: "Sample race" },
      ], tourSlots, players(`
Jannik Sinner | ATP | P | rank=1 win=86 aces=420 titles=5
Carlos Alcaraz | ATP | P | rank=2 win=82 aces=310 titles=4
Alexander Zverev | ATP | P | rank=3 win=74 aces=680 titles=2
Novak Djokovic | ATP | P | rank=4 win=78 aces=280 titles=2
Taylor Fritz | ATP | P | rank=5 win=70 aces=640 titles=1
Daniil Medvedev | ATP | P | rank=6 win=68 aces=390 titles=1
Jack Draper | ATP | P | rank=8 win=66 aces=360 titles=1
Alex de Minaur | ATP | P | rank=12 win=64 aces=180 titles=1
Arthur Fils | ATP | P | rank=18 win=60 aces=240 titles=0
Alexandre Muller | ATP | P | rank=42 win=52 aces=160 titles=0
`, anyRole, golfTags), [
        "Jannik Sinner", "Carlos Alcaraz", "Alexander Zverev", "Novak Djokovic", "Taylor Fritz",
      ], [
        "Alexandre Muller", "Arthur Fils", "Alex de Minaur", "Jannik Sinner",
      ]),
      league("wta", "women", "WTA Tour", "WTA", "Five-player stable, graded inside the women's tour.", "Race", [
        { abbr: "1", name: "Aryna Sabalenka", mark: "No. 1", line: "Sample race" },
        { abbr: "2", name: "Iga Swiatek", mark: "No. 2", line: "Sample race" },
        { abbr: "3", name: "Coco Gauff", mark: "No. 3", line: "Sample race" },
        { abbr: "4", name: "Jasmine Paolini", mark: "Top 8", line: "Sample race" },
      ], tourSlots, players(`
Aryna Sabalenka | WTA | P | rank=1 win=84 aces=380 titles=4
Iga Swiatek | WTA | P | rank=2 win=82 aces=140 titles=4
Coco Gauff | WTA | P | rank=3 win=76 aces=280 titles=2
Jessica Pegula | WTA | P | rank=6 win=70 aces=160 titles=1
Qinwen Zheng | WTA | P | rank=5 win=72 aces=300 titles=1
Jasmine Paolini | WTA | P | rank=8 win=68 aces=90 titles=1
Elena Rybakina | WTA | P | rank=7 win=71 aces=420 titles=1
Madison Keys | WTA | P | rank=10 win=66 aces=260 titles=1
Sofia Kenin | WTA | P | rank=28 win=55 aces=80 titles=0
Katie Volynets | WTA | P | rank=48 win=50 aces=70 titles=0
`, anyRole, golfTags), [
        "Aryna Sabalenka", "Iga Swiatek", "Coco Gauff", "Qinwen Zheng", "Elena Rybakina",
      ], [
        "Katie Volynets", "Sofia Kenin", "Madison Keys", "Aryna Sabalenka",
      ]),
    ],
  },
  {
    id: "volleyball",
    name: "Volleyball",
    accent: "#ff8fb1",
    deck: "An international men's board beside LOVB Pro.",
    views: [
      { id: "all", label: "Players", columns: [
        { key: "kills", label: "K" },
        { key: "aces", label: "A" },
        { key: "blocks", label: "BLK" },
        { key: "digs", label: "DIG" },
        { key: "errors", label: "E" },
      ] },
    ],
    scoring: [
      { key: "kills", weight: 0.35 },
      { key: "aces", weight: 1.6 },
      { key: "blocks", weight: 1.4 },
      { key: "digs", weight: 0.28 },
      { key: "errors", weight: -0.45 },
    ],
    categories: [
      { id: "kills", label: "Killing", keys: ["kills"], higher: true },
      { id: "aces", label: "Serving", keys: ["aces"], higher: true },
      { id: "blocks", label: "Blocking", keys: ["blocks"], higher: true },
      { id: "digs", label: "Defense", keys: ["digs"], higher: true },
      { id: "errors", label: "Errors", keys: ["errors"], higher: false },
    ],
    leagues: [
      league("vnl", "men", "International men", "International", "Setter, two outsides, a middle, an opposite, and a libero. Club marks are national teams.", "Sample field", [
        { abbr: "FRA", name: "France", mark: "Gold tier", line: "Ngapeth" },
        { abbr: "POL", name: "Poland", mark: "Gold tier", line: "Leon" },
        { abbr: "USA", name: "United States", mark: "Medal tier", line: "Christenson" },
        { abbr: "BRA", name: "Brazil", mark: "Medal tier", line: "Lucarelli" },
      ], volleySlots, players(`
Earvin Ngapeth | FRA | OH | kills=248 aces=32 blocks=28 digs=140 errors=70
Wilfredo Leon | POL | OH | kills=260 aces=28 blocks=22 digs=90 errors=74
Micah Christenson | USA | S | kills=28 aces=18 blocks=8 digs=160 errors=8
Bruno Rezende | BRA | S | kills=22 aces=12 blocks=6 digs=140 errors=10
Matt Anderson | USA | OPP | kills=210 aces=16 blocks=24 digs=70 errors=58
Bartosz Kurek | POL | OPP | kills=180 aces=10 blocks=18 digs=50 errors=48
Ricardo Lucarelli | BRA | OH | kills=190 aces=14 blocks=16 digs=80 errors=60
Trevor Clevenot | FRA | L | digs=280 aces=4 kills=0 blocks=0 errors=6
Erik Shoji | USA | L | digs=240 aces=2 kills=0 blocks=0 errors=8
Yacine Louati | FRA | OH | kills=120 aces=8 blocks=10 digs=60 errors=55
Graham McIlvaine | USA | MB | kills=90 aces=6 blocks=48 digs=30 errors=22
Lucas Saatkamp | BRA | MB | kills=70 aces=4 blocks=28 digs=20 errors=24
`, anyRole, volleyTags), [
        "Micah Christenson", "Earvin Ngapeth", "Wilfredo Leon", "Graham McIlvaine", "Matt Anderson", "Trevor Clevenot",
      ], [
        "Bruno Rezende", "Yacine Louati", "Lucas Saatkamp", "Bartosz Kurek", "Erik Shoji",
      ]),
      league("lovb", "women", "LOVB Pro", "LOVB", "The inaugural LOVB shape: setter, two outsides, middle, opposite, libero.", "Standings", [
        { abbr: "AUS", name: "Austin", mark: "Champions", line: "2025 finals" },
        { abbr: "OMA", name: "Omaha", mark: "Finalist", line: "Larson" },
        { abbr: "MAD", name: "Madison", mark: "Playoff", line: "Carlini" },
        { abbr: "ATL", name: "Atlanta", mark: "Playoff", line: "Cook" },
        { abbr: "HOU", name: "Houston", mark: "Field", line: "Mruzik" },
        { abbr: "SLC", name: "Salt Lake", mark: "Field", line: "Poulter" },
      ], volleySlots, players(`
Lauren Carlini | MAD | S | kills=30 aces=16 blocks=10 digs=180 errors=8
Jordyn Poulter | SLC | S | kills=18 aces=10 blocks=6 digs=150 errors=12
Kelsey Cook | ATL | OH | kills=220 aces=22 blocks=24 digs=130 errors=62
Jess Mruzik | HOU | OH | kills=200 aces=18 blocks=16 digs=110 errors=58
Jordan Larson | OMA | OH | kills=160 aces=12 blocks=18 digs=100 errors=48
Chiaka Ogbogu | AUS | MB | kills=80 aces=8 blocks=52 digs=28 errors=18
Amber Igiede | HOU | MB | kills=60 aces=4 blocks=30 digs=20 errors=16
Annie Drews Schumacher | MAD | OPP | kills=170 aces=14 blocks=20 digs=40 errors=50
Kimberly Drewniok | OMA | OPP | kills=140 aces=8 blocks=16 digs=36 errors=48
Lexi Rodriguez | OMA | L | digs=260 aces=6 kills=0 blocks=0 errors=4
Justine Wong-Orantes | OMA | L | digs=180 aces=3 kills=0 blocks=0 errors=6
`, anyRole, volleyTags), [
        "Lauren Carlini", "Kelsey Cook", "Jess Mruzik", "Chiaka Ogbogu", "Annie Drews Schumacher", "Lexi Rodriguez",
      ], [
        "Jordyn Poulter", "Jordan Larson", "Amber Igiede", "Kimberly Drewniok", "Justine Wong-Orantes",
      ]),
    ],
  },
  {
    id: "lacrosse",
    name: "Lacrosse",
    accent: "#7ef0c3",
    deck: "The Premier Lacrosse League and the Women's Lacrosse League.",
    views: [
      { id: "all", label: "Players", columns: [
        { key: "g", label: "G" },
        { key: "a", label: "A" },
        { key: "gb", label: "GB" },
        { key: "ct", label: "CT" },
        { key: "sv", label: "SV" },
      ] },
    ],
    scoring: [
      { key: "g", weight: 3 },
      { key: "a", weight: 2 },
      { key: "gb", weight: 0.45 },
      { key: "ct", weight: 0.7 },
      { key: "sv", weight: 0.35 },
    ],
    categories: [
      { id: "g", label: "Goals", keys: ["g"], higher: true },
      { id: "a", label: "Assists", keys: ["a"], higher: true },
      { id: "gb", label: "Ground balls", keys: ["gb"], higher: true },
      { id: "ct", label: "Caused turnovers", keys: ["ct"], higher: true },
      { id: "sv", label: "Saves", keys: ["sv"], higher: true },
    ],
    leagues: [
      league("pll", "men", "Premier Lacrosse League", "PLL", "Two attack, two midfield, a defender, and a goalie.", "Board", [
        { abbr: "CHA", name: "Chaos", mark: "Contender", line: "Thompson" },
        { abbr: "ARC", name: "Archers", mark: "Contender", line: "Schreiber" },
        { abbr: "WHP", name: "Whipsnakes", mark: "Contender", line: "Rambo" },
        { abbr: "WAT", name: "Waterdogs", mark: "Field", line: "Teat" },
        { abbr: "RED", name: "Redwoods", mark: "Field", line: "O'Neill" },
        { abbr: "ATL", name: "Atlas", mark: "Field", line: "Baptiste" },
      ], laxSlots, players(`
Lyle Thompson | CHA | A | g=32 a=28 gb=40 ct=6 sv=0
Jeff Teat | WAT | A | g=36 a=22 gb=28 ct=4 sv=0
Brennan O'Neill | RED | A | g=30 a=14 gb=22 ct=3 sv=0
Matt Rambo | WHP | A | g=22 a=18 gb=24 ct=4 sv=0
Tom Schreiber | ARC | M | g=16 a=24 gb=36 ct=10 sv=0
Connor Fields | CAN | M | g=8 a=6 gb=18 ct=4 sv=0
Trevor Baptiste | ATL | M | g=2 a=4 gb=80 ct=8 sv=0
Jake Bernhardt | ARC | M | g=4 a=3 gb=14 ct=3 sv=0
Matt Dunn | WHP | D | g=0 a=2 gb=30 ct=18 sv=0
Jack Rowlett | CHA | D | g=1 a=1 gb=22 ct=12 sv=0
Blaze Riorden | CHA | G | g=0 a=1 gb=18 ct=2 sv=140
Brett Dobson | WAT | G | g=0 a=0 gb=8 ct=1 sv=70
`, anyRole, volleyTags), [
        "Lyle Thompson", "Jeff Teat", "Tom Schreiber", "Trevor Baptiste", "Matt Dunn", "Blaze Riorden",
      ], [
        "Matt Rambo", "Connor Fields", "Jake Bernhardt", "Jack Rowlett", "Brett Dobson",
      ]),
      league("wll", "women", "Women's Lacrosse League", "WLL", "Boston, New York, Maryland, and California. Same six-spot build.", "Board", [
        { abbr: "BOS", name: "Guard", mark: "2025 champs", line: "North" },
        { abbr: "NY", name: "Charging", mark: "Finalist path", line: "Scane" },
        { abbr: "CAL", name: "Palms", mark: "Field", line: "Mastroianni" },
        { abbr: "MD", name: "Charm", mark: "Field", line: "Holman" },
      ], laxSlots, players(`
Charlotte North | BOS | A | g=22 a=8 gb=14 ct=2 sv=0
Izzy Scane | NY | A | g=20 a=10 gb=16 ct=3 sv=0
Kylie Ohlmiller | NY | A | g=12 a=14 gb=12 ct=2 sv=0
Jackie Wolak | BOS | A | g=8 a=4 gb=8 ct=1 sv=0
Ally Mastroianni | CAL | M | g=14 a=8 gb=20 ct=6 sv=0
Cassidy Weeks | BOS | M | g=10 a=6 gb=14 ct=4 sv=0
Emily Hawryschuk | NY | M | g=9 a=3 gb=8 ct=2 sv=0
Madison Ahern | BOS | M | g=4 a=3 gb=10 ct=3 sv=0
Alex Aust Holman | MD | D | g=1 a=2 gb=16 ct=10 sv=0
Courtney Taylor | BOS | D | g=0 a=1 gb=12 ct=8 sv=0
Kady Glynn | BOS | G | g=0 a=0 gb=6 ct=1 sv=48
Rachel Hall | BOS | G | g=0 a=0 gb=3 ct=0 sv=22
`, anyRole, volleyTags), [
        "Charlotte North", "Izzy Scane", "Ally Mastroianni", "Cassidy Weeks", "Alex Aust Holman", "Kady Glynn",
      ], [
        "Jackie Wolak", "Emily Hawryschuk", "Madison Ahern", "Courtney Taylor", "Rachel Hall",
      ]),
    ],
  },
  {
    id: "rugby",
    name: "Rugby",
    accent: "#f0c14d",
    deck: "International men's and women's boards, for the sport that did not fit the first six.",
    views: [
      { id: "all", label: "Players", columns: [
        { key: "tries", label: "TRIES" },
        { key: "assists", label: "TA" },
        { key: "meters", label: "METERS" },
        { key: "tackles", label: "TACK" },
      ] },
    ],
    scoring: [
      { key: "tries", weight: 6 },
      { key: "assists", weight: 4 },
      { key: "meters", weight: 0.03 },
      { key: "tackles", weight: 0.28 },
    ],
    categories: [
      { id: "tries", label: "Tries", keys: ["tries"], higher: true },
      { id: "assists", label: "Try assists", keys: ["assists"], higher: true },
      { id: "meters", label: "Meters", keys: ["meters"], higher: true },
      { id: "tackles", label: "Tackles", keys: ["tackles"], higher: true },
    ],
    leagues: [
      league("rugby-m", "men", "Men's internationals", "Men", "Fly-half, two backs, two forwards, and a utility.", "Sample", [
        { abbr: "FRA", name: "France", mark: "Tier 1", line: "Dupont" },
        { abbr: "NZL", name: "New Zealand", mark: "Tier 1", line: "Savea" },
        { abbr: "RSA", name: "South Africa", mark: "Tier 1", line: "Kolbe" },
        { abbr: "IRL", name: "Ireland", mark: "Tier 1", line: "Aki" },
        { abbr: "ENG", name: "England", mark: "Tier 1", line: "Itoje" },
      ], rugbySlots, players(`
Antoine Dupont | FRA | FH | tries=6 assists=10 meters=620 tackles=70
Romain Ntamack | FRA | FH | tries=3 assists=6 meters=380 tackles=40
Cheslin Kolbe | RSA | BK | tries=8 assists=4 meters=540 tackles=28
Will Jordan | NZL | BK | tries=9 assists=3 meters=480 tackles=22
Damian Penaud | FRA | BK | tries=7 assists=2 meters=420 tackles=18
Bundee Aki | IRL | BK | tries=3 assists=2 meters=360 tackles=60
Ardie Savea | NZL | FW | tries=4 assists=3 meters=390 tackles=90
Siya Kolisi | RSA | FW | tries=2 assists=2 meters=280 tackles=80
Maro Itoje | ENG | FW | tries=1 assists=1 meters=220 tackles=95
Eben Etzebeth | RSA | FW | tries=1 assists=0 meters=180 tackles=70
Mack Hansen | IRL | BK | tries=2 assists=1 meters=160 tackles=14
`, anyRole, (pos) => (pos === "FH" ? ["FH", "BK"] : [pos])), [
        "Antoine Dupont", "Cheslin Kolbe", "Will Jordan", "Ardie Savea", "Siya Kolisi", "Damian Penaud",
      ], [
        "Romain Ntamack", "Mack Hansen", "Eben Etzebeth", "Bundee Aki",
      ]),
      league("rugby-w", "women", "Women's internationals", "Women", "Same six-spot build on the women's board.", "Sample", [
        { abbr: "ENG", name: "England", mark: "Tier 1", line: "Kildunne" },
        { abbr: "NZL", name: "New Zealand", mark: "Tier 1", line: "Demant" },
        { abbr: "CAN", name: "Canada", mark: "Tier 1", line: "de Goede" },
        { abbr: "FRA", name: "France", mark: "Tier 1", line: "Menager" },
      ], rugbySlots, players(`
Ellie Kildunne | ENG | BK | tries=9 assists=4 meters=620 tackles=24
Ruahei Demant | NZL | FH | tries=4 assists=8 meters=410 tackles=55
Emily Scarratt | ENG | BK | tries=5 assists=3 meters=300 tackles=30
Jess Breach | ENG | BK | tries=7 assists=2 meters=480 tackles=16
Stacey Waaka | NZL | BK | tries=6 assists=2 meters=400 tackles=18
Portia Woodman-Wickliffe | NZL | BK | tries=8 assists=1 meters=360 tackles=12
Sophie de Goede | CAN | FW | tries=3 assists=4 meters=340 tackles=85
Zoe Aldcroft | ENG | FW | tries=2 assists=1 meters=260 tackles=90
Marlie Packer | ENG | FW | tries=2 assists=2 meters=240 tackles=80
Romane Menager | FRA | FW | tries=1 assists=1 meters=180 tackles=50
Alex Tessier | CAN | FH | tries=1 assists=3 meters=160 tackles=28
`, anyRole, (pos) => (pos === "FH" ? ["FH", "BK"] : [pos])), [
        "Ruahei Demant", "Ellie Kildunne", "Portia Woodman-Wickliffe", "Sophie de Goede", "Marlie Packer", "Jess Breach",
      ], [
        "Alex Tessier", "Emily Scarratt", "Romane Menager", "Marlie Packer",
      ]),
    ],
  },
];

for (const sport of sports) {
  for (const board of sport.leagues) {
    const names = new Set(board.players.map((player) => player.name));
    for (const name of [...board.contender, ...board.retool]) {
      if (!names.has(name)) throw new Error(`${board.id} is missing preset player ${name}`);
    }
    const ids = new Set<string>();
    for (const slot of board.slots) {
      if (ids.has(slot.id)) throw new Error(`${board.id} repeats slot ${slot.id}`);
      ids.add(slot.id);
    }
    const playerIds = new Set<string>();
    for (const player of board.players) {
      if (playerIds.has(player.id)) throw new Error(`${board.id} repeats player id ${player.id}`);
      playerIds.add(player.id);
    }
  }
}

export function sportById(id: string | undefined): Sport | undefined {
  return sports.find((sport) => sport.id === id);
}

export function leagueById(sport: Sport, id: string | null): League {
  return sport.leagues.find((entry) => entry.id === id) ?? sport.leagues[0];
}

export const sampleNote =
  "Leagues marked live read season stats and standings from ESPN's public feeds, so numbers can lag by minutes and are not official statistics. Every other league runs on a sample season: player and club names are real, and the counting lines are rounded illustrations.";
