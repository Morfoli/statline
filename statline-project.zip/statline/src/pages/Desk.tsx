import { Fragment, useMemo, useState } from "react";
import { Missing, SportChrome, useBoard } from "../chrome";
import type { FeedView } from "../live/LiveProvider";
import { AdSlot, PromoSlot } from "../site/Monetization";
import { formatStat, lowerIsBetter, points, scoutLine } from "../engine";
import type { League, Player, Sport, View } from "../types";

// Sort key for the computed desk-points column. It must never match a stat key
// (hockey and basketball both have a real "pts" stat).
const DESK_KEY = "__desk";

type SortDir = "asc" | "desc";
type SortState = { key: string; dir: SortDir };

export function Desk() {
  const { sport, league, setLeague, feed } = useBoard();
  if (!sport || !league) return <Missing />;
  return <DeskBoard key={`${sport.id}:${league.id}`} sport={sport} league={league} feed={feed} setLeague={setLeague} />;
}

function DeskBoard({
  sport,
  league,
  feed,
  setLeague,
}: {
  sport: Sport;
  league: League;
  feed: FeedView;
  setLeague: (id: string) => void;
}) {
  const [viewId, setViewId] = useState(sport.views[0]?.id ?? "");
  const [query, setQuery] = useState("");
  const [openId, setOpenId] = useState<string | null>(null);
  const [sort, setSort] = useState<SortState>({ key: DESK_KEY, dir: "desc" });

  const chosen = sport.views.find((entry) => entry.id === viewId) ?? sport.views[0];

  // Live feeds do not carry every stat (ESPN has no blocked shots for hockey, say), so a column
  // only shows when somebody in this view actually has the number.
  const view = useMemo(() => {
    if (!chosen) return undefined;
    const columns = chosen.columns.filter((column) =>
      league.players.some((player) => (!chosen.role || player.role === chosen.role) && player.stats[column.key] !== undefined),
    );
    return { ...chosen, columns };
  }, [chosen, league.players]);

  const rows = useMemo(() => {
    if (!view) return [];
    const needle = query.trim().toLowerCase();
    const pool = league.players.filter((player) => {
      if (view.role && player.role !== view.role) return false;
      if (!needle) return true;
      return (
        player.name.toLowerCase().includes(needle) ||
        player.team.toLowerCase().includes(needle) ||
        player.pos.toLowerCase().includes(needle)
      );
    });
    const copy = [...pool];
    copy.sort((a, b) => comparePlayers(sport, a, b, sort));
    return copy;
  }, [league.players, query, sort, sport, view]);

  function chooseSort(key: string) {
    setSort((current) => {
      if (current.key === key) return { key, dir: current.dir === "asc" ? "desc" : "asc" };
      const startLow = key === "name" || key === "team" || key === "pos" || lowerIsBetter(key, view?.role);
      return { key, dir: startLow ? "asc" : "desc" };
    });
  }

  const quiet = view?.columns.filter((column) => lowerIsBetter(column.key, view.role)) ?? [];

  return (
    <SportChrome mode="desk" sport={sport} league={league} feed={feed} setLeague={setLeague}>
      {league.board.length > 0 ? (
        <section className="board" aria-label={league.boardLabel}>
          <h2>{league.boardLabel}</h2>
          <ol>
            {league.board.map((row) => (
              <li key={`${row.abbr}-${row.name}`}>
                <span className="abbr">{row.abbr}</span>
                <span className="club">{row.name}</span>
                <span className="mark">{row.mark}</span>
                <span className="line">{row.line}</span>
              </li>
            ))}
          </ol>
        </section>
      ) : null}

      <AdSlot name="inline" />

      {view ? (
        <section className="sheet" aria-label="Player stats">
          <div className="tools">
            <div className="views" role="tablist" aria-label="Stat tables">
              {sport.views.map((entry) => (
                <button
                  key={entry.id}
                  type="button"
                  role="tab"
                  aria-selected={entry.id === view.id}
                  className={entry.id === view.id ? "on" : ""}
                  onClick={() => {
                    setViewId(entry.id);
                    setOpenId(null);
                    setSort({ key: DESK_KEY, dir: "desc" });
                  }}
                >
                  {entry.label}
                </button>
              ))}
            </div>
            <label className="finder">
              Find a player
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Name, team, or position"
              />
            </label>
          </div>
          <p className="count">
            {rows.length} {rows.length === 1 ? "player" : "players"}
            {quiet.length > 0 ? ` · Lower is better for ${quiet.map((column) => column.label).join(", ")}.` : "."}
          </p>
          <StatTable
            view={view}
            rows={rows}
            sort={sort}
            onSort={chooseSort}
            openId={openId}
            onToggle={(id) => setOpenId((current) => (current === id ? null : id))}
            sport={sport}
            league={league}
          />
        </section>
      ) : null}

      <PromoSlot placement="desk" sportId={sport.id} />
    </SportChrome>
  );
}

function StatTable({
  view,
  rows,
  sort,
  onSort,
  openId,
  onToggle,
  sport,
  league,
}: {
  view: View;
  rows: Player[];
  sort: SortState;
  onSort: (key: string) => void;
  openId: string | null;
  onToggle: (id: string) => void;
  sport: NonNullable<ReturnType<typeof useBoard>["sport"]>;
  league: NonNullable<ReturnType<typeof useBoard>["league"]>;
}) {
  const span = 4 + view.columns.length;
  return (
    <div className="table-wrap" tabIndex={0} role="region" aria-label="Player stats table, scrolls sideways">
      <table>
        <thead>
          <tr>
            <SortHead label="Player" sortKey="name" sort={sort} onSort={onSort} align="left" />
            <SortHead label="Team" sortKey="team" sort={sort} onSort={onSort} align="left" />
            <SortHead label="Pos" sortKey="pos" sort={sort} onSort={onSort} align="left" />
            {view.columns.map((column) => (
              <SortHead key={column.key} label={column.label} sortKey={column.key} sort={sort} onSort={onSort} />
            ))}
            <SortHead label="Desk pts" sortKey={DESK_KEY} sort={sort} onSort={onSort} title="Desk points from this sport's scoring" />
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr>
              <td className="empty" colSpan={span}>
                Nobody on this board matches that search.
              </td>
            </tr>
          ) : (
            rows.map((player) => {
              const open = openId === player.id;
              return (
                <Fragment key={player.id}>
                  <tr className={open ? "open" : ""}>
                    <th scope="row">
                      <button type="button" className="player-btn" aria-expanded={open} onClick={() => onToggle(player.id)}>
                        {player.name}
                      </button>
                    </th>
                    <td className="left">{player.team}</td>
                    <td className="left pos">{player.pos}</td>
                    {view.columns.map((column) => (
                      <td key={column.key} className="num">
                        {formatStat(player.stats[column.key], column.digits ?? 0)}
                      </td>
                    ))}
                    <td className="num pts">{formatStat(points(sport, player), 1)}</td>
                  </tr>
                  {open ? (
                    <tr className="scout">
                      <td colSpan={span}>{scoutLine(league, player, view.columns)}</td>
                    </tr>
                  ) : null}
                </Fragment>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );
}

function SortHead({
  label,
  sortKey,
  sort,
  onSort,
  align,
  title,
}: {
  label: string;
  sortKey: string;
  sort: SortState;
  onSort: (key: string) => void;
  align?: "left";
  title?: string;
}) {
  const active = sort.key === sortKey;
  return (
    <th className={align === "left" ? "left" : undefined} aria-sort={active ? (sort.dir === "asc" ? "ascending" : "descending") : "none"}>
      <button type="button" className={active ? "sort on" : "sort"} title={title} onClick={() => onSort(sortKey)}>
        {label}
        {active ? <span aria-hidden="true">{sort.dir === "asc" ? " ↑" : " ↓"}</span> : null}
      </button>
    </th>
  );
}

function comparePlayers(sport: Sport, a: Player, b: Player, sort: SortState): number {
  const left = sortValue(sport, a, sort.key);
  const right = sortValue(sport, b, sort.key);
  if (left === null && right === null) return a.name.localeCompare(b.name);
  if (left === null) return 1;
  if (right === null) return -1;
  const base =
    typeof left === "string" && typeof right === "string" ? left.localeCompare(right) : Number(left) - Number(right);
  return sort.dir === "asc" ? base : -base;
}

function sortValue(sport: Sport, player: Player, key: string): string | number | null {
  if (key === "name") return player.name;
  if (key === "team") return player.team;
  if (key === "pos") return player.pos;
  if (key === DESK_KEY) return points(sport, player);
  const stat = player.stats[key];
  return stat === undefined ? null : stat;
}
