import { useEffect, useMemo, useRef, useState, type RefObject } from "react";
import { Missing, SportChrome, useBoard } from "../chrome";
import type { FeedView } from "../live/LiveProvider";
import { AdSlot, PromoSlot } from "../site/Monetization";
import { analyze, ordinal, parseImport, type Report } from "../engine";
import type { League, Sport } from "../types";

export function Lab() {
  const { sport, league, setLeague, feed } = useBoard();
  if (!sport || !league) return <Missing />;
  return <LabBoard key={league.id} sport={sport} league={league} feed={feed} setLeague={setLeague} />;
}

function LabBoard({
  sport,
  league,
  feed,
  setLeague,
}: {
  sport: Sport;
  league: League;
  feed: FeedView;
  setLeague: (id: string) => void;
}) {
  const storageKey = `statline-lab:${league.id}`;
  const [saved] = useState(() => readSaved(storageKey));
  const [text, setText] = useState(saved);
  const [active, setActive] = useState(saved);
  const [notice, setNotice] = useState("");
  const reviewRef = useRef<HTMLElement>(null);
  const pendingScroll = useRef(false);
  const fileRef = useRef<HTMLInputElement>(null);

  function remember(value: string) {
    setText(value);
    try {
      sessionStorage.setItem(storageKey, value);
    } catch {
      /* the review still runs if storage is blocked */
    }
  }

  const report = useMemo(() => {
    if (parseImport(active).length === 0) return null;
    return analyze(sport, league, parseImport(active));
  }, [active, league, sport]);

  function scrollToReview() {
    const behavior = window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth";
    reviewRef.current?.scrollIntoView({ behavior, block: "start" });
  }

  useEffect(() => {
    if (!pendingScroll.current || !report) return;
    pendingScroll.current = false;
    scrollToReview();
  }, [report]);

  function review(source: string) {
    if (parseImport(source).length === 0) {
      setActive("");
      setNotice("Add at least one player. One name per line, or a CSV with the name in any column.");
      return;
    }
    setNotice("");
    if (source === active && report) {
      // Same club as the review already on screen: nothing re-renders, so just bring it into view.
      scrollToReview();
      return;
    }
    pendingScroll.current = true;
    setActive(source);
  }

  function loadPreset(names: string[]) {
    const next = names.join("\n");
    remember(next);
    review(next);
  }

  const named = parseImport(text).length;
  const dirty = active.length > 0 && text !== active;

  return (
    <SportChrome mode="lab" sport={sport} league={league} feed={feed} setLeague={setLeague}>
      <section className="import">
        <div className="import-copy">
          <p className="kicker">Fantasy lab</p>
          <h2>Import the club. Read the verdict.</h2>
          <p>
            Paste a roster, drop in a text or CSV file, or load one of the sample clubs. The review stays inside the{" "}
            {league.short} board and splits the club into what is good, what is bad, and what needs to change.
          </p>
        </div>
        <form
          onSubmit={(event) => {
            event.preventDefault();
            review(text);
          }}
        >
          <label className="paste">
            Players
            <textarea
              value={text}
              onChange={(event) => remember(event.target.value)}
              placeholder={league.players
                .slice(0, 5)
                .map((player) => player.name)
                .join("\n")}
              spellCheck={false}
              rows={10}
            />
          </label>
          <div className="import-actions">
            <button type="submit" className="primary">
              Review this club
            </button>
            <button type="button" className="ghost" onClick={() => loadPreset(league.contender)}>
              Load a strong club
            </button>
            <button type="button" className="ghost" onClick={() => loadPreset(league.retool)}>
              Load a club that needs work
            </button>
            <button type="button" className="ghost" onClick={() => fileRef.current?.click()}>
              Import a file
            </button>
            <input
              ref={fileRef}
              className="file"
              aria-label="Upload a roster file (text or CSV)"
              type="file"
              accept=".csv,.txt,text/plain,text/csv"
              onChange={(event) => {
                const file = event.target.files?.[0];
                event.target.value = "";
                if (!file) return;
                const reader = new FileReader();
                reader.onload = () => {
                  const next = String(reader.result ?? "");
                  remember(next);
                  review(next);
                };
                reader.readAsText(file);
              }}
            />
          </div>
          <p className="hint" role="status">
            {named === 0 ? "No names in the box yet." : `${named} ${named === 1 ? "name" : "names"} ready to review.`}
            {dirty ? " The box has edits that are not in the review yet." : ""}
            {notice ? ` ${notice}` : ""}
          </p>
        </form>
      </section>

      <AdSlot name="inline" />

      {report ? <Review report={report} node={reviewRef} /> : null}

      {report ? <PromoSlot placement="lab" sportId={sport.id} limit={1} /> : null}
    </SportChrome>
  );
}

function Review({ report, node }: { report: Report; node: RefObject<HTMLElement | null> }) {
  const matched = report.roster.filter((row) => row.player).length + report.bench.length;
  return (
    <section className="review" ref={node} aria-live="polite">
      <header className={`verdict ${gradeTone(report.grade)}`}>
        <p className="grade-letter">{report.grade}</p>
        <div>
          <p className="kicker">
            {report.score} / 100 · {report.totalPoints} desk points
          </p>
          <h2>{report.summary}</h2>
          <p className="matched">
            {matched} {matched === 1 ? "player" : "players"} lined up from this board.
            {report.unmatched.length > 0
              ? ` ${report.unmatched.length} ${report.unmatched.length === 1 ? "name was" : "names were"} not used.`
              : ""}
          </p>
        </div>
      </header>

      {report.unmatched.length > 0 ? (
        <div className="unmatched">
          <h3>Not on this board</h3>
          <ul>
            {report.unmatched.map((name, index) => (
              <li key={`${name}-${index}`}>{name}</li>
            ))}
          </ul>
        </div>
      ) : null}

      <div className="memos">
        <Memo title="Good" tone="good" items={report.strengths} empty="Nothing on this club is strong enough to protect." />
        <Memo title="Bad" tone="bad" items={report.changes} empty="No starter is weak enough to force a move." />
        <Memo title="Needs a change" tone="fix" items={report.needs} empty="No hole or missing category is loud enough to demand a move." />
      </div>

      <section className="lineup-block">
        <h3>How this club lines up</h3>
        <ol className="lineup">
          {report.roster.map((row) => (
            <li key={row.slotId} className={row.verdict}>
              <span className="slot">{row.slotLabel}</span>
              <span className="who">
                <strong>{row.player ? row.player.name : "Empty"}</strong>
                <small>{row.player ? `${row.player.team} · ${row.player.pos}` : "No eligible player imported"}</small>
              </span>
              <span className="num pts">{row.points === null ? "—" : row.points.toFixed(1)}</span>
              <span className="pill">
                {row.verdict === "keep" ? "Good" : row.verdict === "upgrade" ? "Bad" : "Open"}
                {row.percentile !== null ? ` · ${ordinal(row.percentile)}` : ""}
              </span>
              <span className="meter" aria-hidden="true">
                <span style={{ width: `${row.percentile ?? 0}%` }} />
              </span>
            </li>
          ))}
        </ol>
      </section>

      <section className="cats">
        <h3>Categories</h3>
        <ul>
          {report.categories.map((category) => (
            <li key={category.id}>
              <div className="cat-top">
                <span>{category.label}</span>
                <span className="num">{category.index === null ? "—" : category.index}</span>
              </div>
              <div className="track" aria-hidden="true">
                <span
                  className={category.index === null ? "na" : category.index >= 72 ? "hot" : category.index < 45 ? "cold" : "mid"}
                  style={{ width: `${category.index ?? 0}%` }}
                />
              </div>
              <p>{category.note}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="bench-block">
        <h3>On the club, not starting</h3>
        {report.bench.length === 0 ? (
          <p className="empty-copy">Everyone you imported is in the lineup.</p>
        ) : (
          <ul className="bench">
            {report.bench.map((row) => (
              <li key={row.player.id}>
                <strong>{row.player.name}</strong>
                <span>
                  {row.player.pos} · {row.player.team}
                </span>
                <span className="num">{row.points.toFixed(1)}</span>
                <p>{row.note}</p>
              </li>
            ))}
          </ul>
        )}
      </section>
    </section>
  );
}

function Memo({
  title,
  tone,
  items,
  empty,
}: {
  title: string;
  tone: "good" | "bad" | "fix";
  items: { title: string; detail: string }[];
  empty: string;
}) {
  return (
    <article className={`memo ${tone}`}>
      <h3>{title}</h3>
      {items.length === 0 ? (
        <p className="empty-copy">{empty}</p>
      ) : (
        <ul>
          {items.map((item, index) => (
            <li key={`${item.title}-${index}`}>
              <h4>{item.title}</h4>
              <p>{item.detail}</p>
            </li>
          ))}
        </ul>
      )}
    </article>
  );
}

function readSaved(key: string): string {
  try {
    return sessionStorage.getItem(key) ?? "";
  } catch {
    return "";
  }
}

function gradeTone(grade: string): string {
  if (grade.startsWith("A")) return "tone-a";
  if (grade.startsWith("B")) return "tone-b";
  if (grade.startsWith("C")) return "tone-c";
  return "tone-d";
}
