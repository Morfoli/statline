import { useEffect, type CSSProperties } from "react";
import { Link } from "react-router-dom";
import { sports } from "../data";
import { hasLiveFeed } from "../live/espn";
import { AdSlot, PromoSlot } from "../site/Monetization";

export function Home() {
  useEffect(() => {
    document.title = "Statline";
  }, []);

  return (
    <main className="wrap home">
      <section className="mast">
        <p className="kicker">Vol. 01 · Live where a free feed exists</p>
        <h1>
          Every board on the desk,
          <em> men and women.</em>
        </h1>
        <p className="lede">
          Statline is a scouting desk for the sports already in the book: baseball, hockey, football, soccer, golf,
          basketball, tennis, volleyball, lacrosse, and rugby. Read the stat line, or import a fantasy club and get a
          straight review of what is good, what is bad, and what needs to change.
        </p>
        <p className="live-note">
          <span className="dot" aria-hidden="true" />
          <span>
            Live from ESPN: MLB, NHL, NFL, NBA, and WNBA. Every other league runs on a sample season until a free feed is
            connected. <Link to="/status">See the data sources</Link>
          </span>
        </p>
      </section>

      <AdSlot name="header" />

      <ol className="sport-list">
        {sports.map((sport, index) => (
          <li key={sport.id} className="sport-row" style={{ "--accent": sport.accent } as CSSProperties}>
            <div className="sport-copy">
              <span className="idx">{String(index + 1).padStart(2, "0")}</span>
              <div>
                <h2>{sport.name}</h2>
                <p>{sport.deck}</p>
              </div>
            </div>
            <div className="sport-actions">
              {sport.leagues.map((league) => (
                <Link key={league.id} to={`/${sport.id}?league=${league.id}`}>
                  {league.gender === "men" ? "Men" : "Women"}
                  <small>{hasLiveFeed(league.id) ? `${league.short} · live` : league.short}</small>
                </Link>
              ))}
              <Link className="lab" to={`/${sport.id}/lab?league=${sport.leagues[0].id}`}>
                Fantasy lab
                <small>Import a club</small>
              </Link>
            </div>
          </li>
        ))}
      </ol>

      <PromoSlot placement="home" />
    </main>
  );
}
