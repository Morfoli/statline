import { useEffect, useState, type FormEvent } from "react";
import { Link } from "react-router-dom";
import { useSite } from "../site/SiteProvider";

export function Plus() {
  const { config, reload } = useSite();
  const [code, setCode] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "error">("idle");
  const [message, setMessage] = useState("");
  const plus = config.plus;

  useEffect(() => {
    document.title = `${plus.name} · Statline`;
  }, [plus.name]);

  if (!config.server || !plus.enabled) {
    return (
      <main className="wrap prose">
        <p className="kicker">Plus</p>
        <h1>Not available right now.</h1>
        <Link to="/" className="text-link">
          Back to the sports
        </Link>
      </main>
    );
  }

  async function redeem(event: FormEvent) {
    event.preventDefault();
    setState("sending");
    try {
      const res = await fetch("/api/plus/redeem", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ code }),
      });
      const json = (await res.json()) as { error?: string };
      if (!res.ok) throw new Error(json.error || "That code did not work.");
      setCode("");
      setState("idle");
      reload();
    } catch (error) {
      setState("error");
      setMessage(error instanceof Error ? error.message : "That code did not work.");
    }
  }

  async function leave() {
    await fetch("/api/plus/leave", { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    reload();
  }

  return (
    <main className="wrap prose">
      <p className="kicker">{plus.name}</p>
      <h1>{config.entitled ? `You are on ${plus.name}.` : `Go ad-free with ${plus.name}.`}</h1>
      <p className="lede">{config.entitled ? "No ads and no sponsored cards on this browser. Thank you for backing the site." : plus.pitch}</p>

      {config.entitled ? (
        <button type="button" className="ghost" onClick={() => void leave()}>
          Remove {plus.name} from this browser
        </button>
      ) : (
        <>
          {plus.buyUrl ? (
            <p className="buy">
              <a className="primary-link" href={plus.buyUrl} target="_blank" rel="noopener noreferrer">
                Get {plus.name}
                {plus.price ? ` · ${plus.price}` : ""}
              </a>
            </p>
          ) : null}
          <form className="redeem" onSubmit={(event) => void redeem(event)}>
            <label>
              <span>Already have an access code?</span>
              <input value={code} onChange={(e) => setCode(e.target.value)} placeholder="ABCD-EFGH-JKLM" autoComplete="off" spellCheck={false} />
            </label>
            <button type="submit" className="primary" disabled={state === "sending" || code.trim() === ""}>
              Unlock
            </button>
            {state === "error" ? (
              <p className="form-msg bad" role="alert">
                {message}
              </p>
            ) : null}
          </form>
        </>
      )}
    </main>
  );
}
