import { useEffect } from "react";
import { Link } from "react-router-dom";
import { useSite } from "../site/SiteProvider";

export function Privacy() {
  const { config } = useSite();
  useEffect(() => {
    document.title = "Privacy · Statline";
  }, []);
  const legal = config.legal;
  return (
    <main className="wrap prose">
      <p className="kicker">Privacy</p>
      <h1>How this site handles your data.</h1>
      {legal.privacyText ? <div className="legal-text">{legal.privacyText}</div> : <p className="lede">No policy has been published for this site yet.</p>}
      {legal.affiliateNote ? <p className="legal-note">{legal.affiliateNote}</p> : null}
      {legal.contactEmail ? (
        <p className="legal-note">
          Questions or removal requests: <a href={`mailto:${legal.contactEmail}`}>{legal.contactEmail}</a>
        </p>
      ) : null}
      <Link to="/" className="text-link">
        Back to the sports
      </Link>
    </main>
  );
}
