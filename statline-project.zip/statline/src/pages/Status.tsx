import { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { sports } from "../data";
import { FEEDS, describeError, hasLiveFeed, loadLeague } from "../live/espn";
import { clearLiveCache } from "../live/LiveProvider";

type Row = {
  id: string;
  state: "waiting" | "running" | "ok" | "fail";
  ms?: number;
  players?: number;
  board?: number;
  season?: string;
  detail?: string;
};

const liveIds = Object.keys(FEEDS);

function leagueLabel(id: string): string {
  for (const sport of sports) {
    const league = sport.leagues.find((entry) => entry.id === id);
    if (league) return `${league.short} (${sport.name}, ${league.gender === "men" ? "men" : "women"})`;
  }
  return id;
}

export function Status() {
  const [rows, setRows] = useState<Row[]>(() => liveIds.map((id) => ({ id, state: "waiting" })));
  const [running, setRunning] = useState(false);
  const alive = useRef(true);

  const patch = useCallback((id: string, change: Partial<Row>) => {
    if (alive.current) setRows((current) => current.map((row) => (row.id === id ? { ...row, ...change } : row)));
  }, []);

  const check = useCallback(async () => {
    setRunning(true);
    for (const id of liveIds) {
      patch(id, { state: "running", detail: undefined });
      const started = performance.now();
      try {
        const data = await loadLeague(FEEDS[id]);
        patch(id, {
          state: "ok",
          ms: Math.round(performance.now() - started),
          players: data.players.length,
          board: data.board.length,
          season: data.season,
          detail: data.notes.join(" · "),
        });
      } catch (error) {
        patch(id, { state: "fail", ms: Math.round(performance.now() - started), detail: describeError(error) });
      }
    }
    if (alive.current) setRunning(false);
  }, [patch]);

  useEffect(() => {
    alive.current = true;
    document.title = "Data sources · Statline";
    void check();
    return () => {
      alive.current = false;
    };
  }, [check]);

  const sampleOnly = sports.flatMap((sport) =>
    sport.leagues.filter((league) => !hasLiveFeed(league.id)).map((league) => ({ sport: sport.name, league })),
  );
  const allNetwork = rows.length > 0 && rows.every((row) => row.state === "fail" && /reach ESPN/.test(row.detail ?? ""));

  return (
    <main className="wrap status">
      <p className="kicker">Data sources</p>
      <h1>Where the numbers come from.</h1>
      <p className="lede">
        Leagues marked live read season stats and standings from ESPN's public data feeds. No account or key is
        involved. ESPN does not publish these as an official product, so they can change without notice, and the
        numbers are not official statistics. If a feed ever fails, the page falls back to the sample season and says so.
      </p>

      <section aria-label="Live feed check">
        <div className="status-head">
          <h2>Live feed check</h2>
          <div className="status-actions">
            <button type="button" className="ghost" onClick={() => void check()} disabled={running}>
              {running ? "Checking…" : "Run the check again"}
            </button>
            <button
              type="button"
              className="ghost"
              onClick={() => {
                clearLiveCache();
                void check();
              }}
              disabled={running}
            >
              Clear saved copies
            </button>
          </div>
        </div>
        <div className="table-wrap" tabIndex={0} role="region" aria-label="Live feed results">
          <table className="status-table">
            <thead>
              <tr>
                <th className="left">League</th>
                <th className="left">Result</th>
                <th>Players</th>
                <th>Standings</th>
                <th className="left">Season</th>
                <th>Time</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <th scope="row" className="plain">
                    <Link to={`/${sports.find((s) => s.leagues.some((l) => l.id === row.id))?.id ?? ""}?league=${row.id}`}>
                      {leagueLabel(row.id)}
                    </Link>
                    {row.detail ? <span className="detail">{row.detail}</span> : null}
                  </th>
                  <td className={`left result ${row.state}`}>
                    {row.state === "waiting" ? "Waiting" : row.state === "running" ? "Checking…" : row.state === "ok" ? "Working" : "Failed"}
                  </td>
                  <td className="num">{row.players ?? "—"}</td>
                  <td className="num">{row.board ?? "—"}</td>
                  <td className="left">{row.season ?? "—"}</td>
                  <td className="num">{row.ms !== undefined ? `${(row.ms / 1000).toFixed(1)}s` : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {allNetwork ? (
          <p className="hint-plain">
            Every league failed to reach ESPN. That usually means this device is offline, or the network blocks ESPN's
            domains (some school filters do). The site is fine: it keeps working on the sample season.
          </p>
        ) : null}
      </section>

      <section aria-label="Sample-only leagues">
        <h2>Still on the sample season</h2>
        <p className="lede">
          These leagues have no free, key-less stats feed connected yet. Player and club names are real. Counting lines
          are rounded illustrations, so the boards and the fantasy lab can run without a live feed.
        </p>
        <ul className="sample-list">
          {sampleOnly.map(({ sport, league }) => (
            <li key={league.id}>
              <span>{league.name}</span>
              <small>
                {sport}, {league.gender === "men" ? "men" : "women"}
                {sport === "Soccer" ? ". ESPN keeps no player leaderboard for soccer." : ""}
              </small>
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}
