export type Gender = "men" | "women";

export type Column = { key: string; label: string; digits?: number };

export type View = {
  id: string;
  label: string;
  role?: string;
  columns: Column[];
};

export type Slot = { id: string; label: string; accepts: string[] };

export type Scoring = { key: string; weight: number; roles?: string[] };

export type Category = {
  id: string;
  label: string;
  keys: string[];
  higher: boolean;
  role?: string;
  require?: string;
};

export type BoardRow = { abbr: string; name: string; mark: string; line: string };

export type Player = {
  id: string;
  name: string;
  team: string;
  pos: string;
  role: string;
  tags: string[];
  stats: Record<string, number>;
};

export type LiveMeta = {
  source: string;
  season: string;
  fetchedAt: number;
  count: number;
};

export type League = {
  id: string;
  gender: Gender;
  name: string;
  short: string;
  blurb: string;
  boardLabel: string;
  board: BoardRow[];
  slots: Slot[];
  players: Player[];
  contender: string[];
  retool: string[];
  live?: LiveMeta;
};

export type Sport = {
  id: string;
  name: string;
  accent: string;
  deck: string;
  views: View[];
  scoring: Scoring[];
  categories: Category[];
  leagues: League[];
};
