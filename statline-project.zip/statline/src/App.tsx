import { useEffect } from "react";
import { HashRouter, Route, Routes, useLocation } from "react-router-dom";
import { sampleNote } from "./data";
import { Missing, TopBar } from "./chrome";
import { Admin } from "./admin/Admin";
import { Plus } from "./pages/Plus";
import { Privacy } from "./pages/Privacy";
import { AnnouncementBar, ConsentBanner, SiteFooter } from "./site/Monetization";
import { PageViews, SiteProvider } from "./site/SiteProvider";
import { Desk } from "./pages/Desk";
import { Home } from "./pages/Home";
import { Lab } from "./pages/Lab";
import { Status } from "./pages/Status";
import { LiveProvider } from "./live/LiveProvider";

// Jump back to the top when the page changes (not when only ?league= changes).
function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

// HashRouter keeps every route working from file:// and from any static host,
// because the route lives after the # and never needs server rewrites.
export function App() {
  return (
    <HashRouter>
      <ScrollToTop />
      <SiteProvider>
      <PageViews />
      <LiveProvider>
        <div className="app">
          <AnnouncementBar />
          <TopBar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/status" element={<Status />} />
            <Route path="/plus" element={<Plus />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="/:sportId/lab" element={<Lab />} />
            <Route path="/:sportId" element={<Desk />} />
            <Route path="*" element={<Missing />} />
          </Routes>
          <SiteFooter note={sampleNote} />
        </div>
        <ConsentBanner />
      </LiveProvider>
      </SiteProvider>
    </HashRouter>
  );
}
