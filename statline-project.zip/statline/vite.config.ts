import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { viteSingleFile } from "vite-plugin-singlefile";

// base "./" + a single-file build means dist/index.html opens by double-click
// (file://) with no server. `npm run dev` still works the normal way.
export default defineConfig({
  base: "./",
  plugins: [react(), viteSingleFile()],
  server: {
    port: 5173,
    strictPort: false,
    // In development the Statline server (npm run serve) answers the admin and money endpoints.
    proxy: { "/api": "http://127.0.0.1:8787", "/go": "http://127.0.0.1:8787", "/ads.txt": "http://127.0.0.1:8787" },
  },
});
